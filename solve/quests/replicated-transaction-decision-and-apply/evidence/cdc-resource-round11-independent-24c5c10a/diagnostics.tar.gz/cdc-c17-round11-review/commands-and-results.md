# Round-eleven independent scheduler diagnostic

Working directory:
`/mnt/data/peter/projects/.worktrees/rs-raft-candidate-20261011/test-output/continuation-20261011/cdc-c17-round11-review`

Exact executed command:

```sh
/mnt/data/peter/projects/.worktrees/tx1-cdc-20261011/test-output/cdc-adrop-layout-20261011/node-22.22.0-production immediate-unwind-probe.cjs . > immediate-unwind-probe.log 2>&1
```

Exit 0. Script uses public immediates and await, with one ordinary companion
immediate in the same second-check list. It marks the second Immediate record
without retaining its handle in a local/global variable. No timers monkey patch.
The snapshot marker changes the diagnostic object shape; observed 136-byte
self size is not a production coefficient.

Observed event order:
first-check, second-check, shutdown-continuation, companion-check, following-check.
The awaited continuation stack includes runNextTicks and processImmediate at
internal/timers:453. Its snapshot contains the marked Immediate and an
_idleNext edge to the companion Immediate; _onImmediate is cleared. The marked
object is absent from the following-check snapshot.

Snapshots were decoded using their own node_fields, edge_fields, node_types,
edge_types and associated strides. The parser selects the Immediate whose
reviewMarker property points to cdc_round11_second_immediate_custody, then
records its self_size and all outgoing edges. Raw snapshots and extracted
immediate-unwind-result.json are retained.

Official Node v22.22.0 timers source was read via web and independently retained
with urllib.request from:
https://raw.githubusercontent.com/nodejs/node/v22.22.0/lib/internal/timers.js
SHA-256 c0cb11238d8f10aba653926c9c0ee28aa7f49593100de7f013ffd61b9fa45c42.

Python hashlib checks verify ce9e subject, exact 166864-byte predecessor prefix,
256-line 7aef delta, prior 8188 report, all 18 entries of prior 576b diagnostic
manifest, all 34 application/deployment paths and four profile-owner paths.
Full results are in navigation.json. The actual diagnostic executable is the
same 1bec56ef production-image copy as round ten; it remains measurement only.

This is a bounded scheduler-custody counterexample and following-check control.
It is not an adapter acceptance test, executed resource overflow, broad runtime
certification, new source regression, full startup proof or cluster test.
