'use strict';
// Isolated native scheduler diagnostic; no application or timers monkey patch.
const fs = require('node:fs');
const path = require('node:path');
const v8 = require('node:v8');
const output = process.argv[2];
const events = [];
const marker = 'cdc_round11_second_immediate_custody';
function snapshot(name) {
  v8.writeHeapSnapshot(path.join(output, name + '.heapsnapshot'));
}
async function owner() {
  await new Promise((resolve) => {
    setImmediate(() => {
      events.push('first-check');
      setImmediate(() => {
        events.push('second-check');
        resolve();
      }).reviewMarker = marker;
      // A normal independent immediate in the same second-check queue.
      setImmediate(() => { events.push('companion-check'); });
    });
  });
  events.push('shutdown-continuation');
  const stack = new Error('continuation phase').stack;
  snapshot('await-continuation');
  setImmediate(() => {
    events.push('following-check');
    snapshot('following-check');
    fs.writeFileSync(path.join(output, 'immediate-unwind-events.json'),
      JSON.stringify({executable: process.execPath, versions: process.versions,
        events, stack}, null, 2) + '\n');
  });
}
owner().catch((error) => { process.stderr.write(String(error.stack)); process.exitCode = 1; });
