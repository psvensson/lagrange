
## D22-D23 effective shutdown terminal and supported-profile correction

The exact D21 subject is retained by the round-ten review as
`subject-0d725dc4.md`, SHA-256
`0d725dc43b55eaaa4af10fe1b3eae809f96bbfabfeebef0d25e053be5cf06399`.
The complete independent report has SHA-256
`81881308e0b4fc2ac4161cf3ae051d94591fc5a636a05d6e0750d7b705d5310e`.
Its diagnostic directory is
`test-output/continuation-20261011/cdc-c17-round10-review` in the retained
rs-raft candidate worktree. `diagnostic-sha256.txt` has SHA-256
`576baff8ee80da5bc83cde5bf351cd2d18a859eb34fdab5a3c86df631a81a2f6`,
`navigation.json` has SHA-256
`94ecff53f842f1c23c994733f078c77d73bd8a4b6eac8ca8e6c2b691b4b397f4`,
`commands-and-results.md` has SHA-256
`0689546e204c62da873751756439d67d2841ee1152f0e8fcb75c0aefc26024c9`,
and the official Node-source `native/manifest.json` has SHA-256
`481b017d885a77e51898096a72ebe5c4ee651c0f7c019683cd4bbf1fbb6f8271`.

This section supersedes only two D21 clauses:

1. The single `setImmediate` after a server `close` projection is withdrawn.
   The shutdown owner uses the two-check terminal below and retains all native,
   destroy and barrier custody through its real handoff and unwind.
2. A release/platform profile may not declare an existing required recovery
   workflow optional. The profile inventory and mismatch policy below replace
   D21's unconstrained required/optional choice.

The standing 48-root Adrop population, its 480 KiB maximum inside the unchanged
512 KiB reservation, the 4,792/6,080 KiB fixed banks, complete lower-then-upper
pair, ACK/result interaction, D19 receive phases, ordinary/snapshot isolation,
128 MiB/eight-root limits and supported row cases remain operative. Future
adapter coefficients remain later source gates. The caller source at
`2de419483c9b4ce9e3fabc87bb54d93e4afb8817` remains closed.

### D22: final native custody through every shutdown entry phase

The round-ten diagnostic uses the exact measured Node 22.22.0 executable and a
separate client. When shutdown is requested from the drop callback's microtask,
the observed order is:

```text
drop -> shutdown-request -> server-close -> first-immediate -> second-immediate
```

At the first immediate, the heap still has one 432-byte
`Node / TCPSocketWrap` and one 432-byte `Node / TCPServerWrap`. At the nested
second immediate it has neither. This follows the pinned loop: JavaScript check
callbacks run before `uv__run_closing_handles`; a new immediate scheduled by
the first immediate cannot run in that same check phase. The closing-handle
phase therefore occurs before the nested immediate. Native async-destroy
immediates created by that close run before the later JavaScript immediate in
the selected Node profile. Server `close`, `_connections == 0`, Socket `close`
and async-hooks destroy notification remain projections rather than release
authority.

MessageRouter's existing idempotent shutdown operation owns one coverage drain
record keyed by boot and listener generation. Later shutdown calls await that
same record. It has these states; they are phases of the existing operation,
not a second lifecycle framework:

```text
accepting -> quiescing -> draining -> first-check -> second-check
          -> shutdown-owner handoff -> released
```

The phase rules are:

1. `quiescing` synchronously withdraws the coverage capability, prevents new
   dial/admission, sets the public max-connections gate to zero when a server
   exists, and requests listener close. A startup error, partial bind or normal
   shutdown all enter this same operation once Wbase has been withheld.
2. `draining` waits for both sides of the actual ownership graph: the listener
   has produced its close/error terminal, and every A, Iout, Iin, receiver,
   HTTP head/write, pending/late ledger, send callback, deferred emitter and
   connection-generation close reference is at zero or has transferred to its
   named downstream owner. A shutdown timeout may report pressure but cannot
   release Wbase or authorize a successor.
3. After those conditions hold, the owner schedules a refed first public
   immediate. It retains Wbase and performs no release. Its only transition is
   to schedule the refed nested second immediate for the same generation.
4. The nested second immediate executes after at least one closing-handle phase
   following the first callback. The selected runtime profile also proves that
   native async-destroy bookkeeping from that phase runs before this JavaScript
   callback. The callback verifies the unchanged generation and drain counts;
   it does not itself return Wbase.
5. The second callback signals the existing shutdown continuation and returns.
   Its `Immediate` record, callback closure and stack aliases are still owned
   until that return. Only the existing MessageRouter shutdown continuation,
   reached after the callback unwind, may perform the once-only Wbase release.
   The small completion record and any terminal scheduler bookkeeping transfer
   atomically from Adrop's terminal term to the already existing MessageRouter
   shutdown-operation and Node Environment scheduler custody for that final
   continuation; neither can be used for traffic or admission. On continuation
   return, MessageRouter releases its record. Node Environment releases its
   numeric async-destroy entry through its existing native-immediate owner.

The certified Node timers implementation is part of that terminal premise.
The reviewed Node v22.22.0 source is
`https://raw.githubusercontent.com/nodejs/node/v22.22.0/lib/internal/timers.js`,
SHA-256
`c0cb11238d8f10aba653926c9c0ee28aa7f49593100de7f013ffd61b9fa45c42`;
the selected artifact profile must bind its equivalent executable source.
`processImmediate` removes the running list from the public queue, marks the
Immediate destroyed, and in its `finally` clears `_onImmediate`, emits only the
numeric async-destroy identity when hooks exist, and advances the outstanding
queue. The awaited shutdown continuation cannot resume until the second
callback and `processImmediate` have returned to the microtask checkpoint.
Therefore the callback closure and Immediate queue link are gone before Wbase
release; a possible remaining destroy identity has already transferred to the
Node Environment native-immediate owner. The selected profile must bind these
exact timer/native-immediate semantics. A runtime with different ordering is
`COVERAGE_RUNTIME_UNCERTIFIED` before listen.

The unchanged Adrop arithmetic explicitly includes the terminal mechanism:

```text
48 Droot values                                             <= 384 KiB
one synchronous drop graph                                 <=  16 KiB
native poll/close/async-destroy shared bookkeeping          <=  64 KiB
two Immediate records/closures + completion handoff record <=  16 KiB
---------------------------------------------------------------------
standing maximum                                           <= 480 KiB
reservation                                                  512 KiB
margin                                                        32 KiB
```

The 16 KiB terminal term includes both scheduled Immediate objects, both
callbacks, the generation/drain state, the completion promise/record and the
exact handoffs into the existing shutdown continuation and Node Environment
destroy queue. Nothing in that term is called free at second-callback entry.
The handoffs are required because an executing callback cannot prove its own
return. MessageRouter's handoff is bounded to one record per shutdown and has
no queue; Node's handoff is one bounded numeric destroy entry per terminal
Immediate under the profile's 64 KiB shared cap. The MessageRouter record
cannot overlap a successor listener generation because restart/listen is
forbidden until that record reaches `released`. The Node-owned scalar may
outlive that point, but it has no Wbase backing and carries no transfer release,
admission or generation authority; its overlap cannot duplicate transfer
capacity.

All entry phases converge on the same terminal:

| Shutdown entry | Custody before the first check |
| --- | --- |
| Wbase withheld, listen never invoked | No listener/native root exists; cancel construction and use the same two-check operation before releasing the standing reservation |
| bind/listen pending | Retain Wbase through bind callback or error, close any constructed handle, then drain and cross both checks |
| listening with no A/I | Close listener; dropped/server native roots and destroy bookkeeping remain Adrop through both checks |
| listening with live or retired A/I | Close listener, drain every exact A/I/send/receive/HTTP generation first, then cross both checks |
| startup failure after coverage bind | Withdraw the unpublished capability, close coverage and any later-started server under their existing owners, then run this coverage terminal |
| repeated shutdown or restart request | Await the same generation record; no duplicate checks, release or successor claim is created |

If scheduling either refed immediate throws or the certified phase ordering is
not present, Wbase remains owned and shutdown reports a hard runtime-profile
failure. Process termination may let the operating system reclaim memory, but
is not an in-process release or capacity wake. No A/I/E/root admission waiter
is notified until the post-unwind continuation has completed the once-only
release.

The future native witness must retain the diagnostic's positive distinction:
one dropped and server wrapper at the first immediate, zero at the second. It
also covers shutdown before listen, during bind, with empty A/I, with held
HTTP/ws/send/deferred callbacks, repeated shutdown and restart. Each case must
show the two Immediate records and completion handoff, pending native destroy
bookkeeping, one release and no successor using the old generation. This is a
later source witness, not a demand for an unimplemented adapter before design
approval.

### D23: profiles preserve every existing required recovery workflow

`coverage-runtime-profile/1` remains owned by the existing release/platform
and boot-provenance surfaces. Its inventory is based on existing product and
deployment promises, never on a MessageRouter choice:

| Existing delivery surface | Required profile treatment |
| --- | --- |
| published npm/source node service | Each platform/runtime combination that the existing platform owner supports for node startup, restart and CDC/cache recovery must have an exact executable/source/dependency profile before release acceptance |
| published SEA node executable | Each supported SEA artifact/platform digest must carry a matching profile in the existing build/release receipt |
| Docker image deployed by Helm | The final immutable OCI digest and embedded manifest must be certified together; the chart cannot qualify a different or mutable image for the required recovery workflow |
| canonical lab/release candidate | The exact executable, source, dependencies and platform receipt must match a certified profile; lab evidence certifies only that exact candidate and does not widen public platform support |
| existing non-server tool or explicitly non-recovery mode | It needs no coverage profile only when the current platform owner already excludes node recovery from that mode |

The package `engines.node >=22.12.0` field remains an installation/runtime
floor. It is not evidence that every future Node patch, libc, operating system
or architecture satisfies the native allocation profile. The release/platform
owner selects and records the concrete supported profile matrix. That owner
may make a separate explicit support-contract change through its own authority,
but this transport design cannot narrow the matrix, convert an existing
recovery-capable mode to ordinary-only, or call an uncertified required
workflow acceptable.

For every currently advertised delivery form whose node may start without
current debt and later restart with durable CDC/cache coverage work, coverage
certification is required before that form's rs-raft release/readiness
acceptance. If any required form lacks a selected profile, the candidate
release is stopped for that form. It is not published as a partially capable
replacement and is not made to pass by marking recovery optional. The v0.2.5
image remains measurement evidence only; it cannot satisfy a future candidate
profile. No new feature flag or deployment value may disable an advertised
required recovery workflow to qualify this candidate.

At boot the existing provenance owner returns one typed local result before
Wbase/listen. A required-profile mismatch remains
`COVERAGE_RUNTIME_UNCERTIFIED`: the coverage capability is absent, the durable
obligation remains owed and the existing startup/recovery owner applies its
existing HOLD/readiness rule. MessageRouter neither decides whether the form
is required nor publishes a weaker ready state. Ordinary or snapshot startup
without coverage is permitted only when the preexisting platform contract
already permits that exact non-recovery mode. This correction creates no new
optional mode, global readiness owner or dependency on the CDC cache to verify
local runtime bytes.

The release/platform decision required before implementation is concrete:

1. enumerate the current supported node delivery forms and platform/runtime
   combinations that promise startup, restart and CDC/cache recovery;
2. select an exact artifact-bound profile for every such combination, or stop
   that form's rs-raft candidate release until the existing support-contract
   owner explicitly changes the promise;
3. bind npm/source, SEA and OCI/Helm receipts as D21 specifies, and distinguish
   exact lab certification from public release support;
4. make the existing boot-provenance result carry the selected profile identity
   and required-workflow disposition to existing startup/recovery consumers;
5. preserve typed HOLD and durable debt on mismatch without primary/snapshot
   fallback, force-readiness or MessageRouter policy inference.

This is a release/platform owner choice about concrete profiles, not permission
to downgrade a required recovery workflow. The fixed Adrop/profile facts close
before transport implementation; Aactive/Mlane/Gc/Bsend/Frecv/Fmeta/S/H/C/K
measurements still close against their fixed ceilings on the future adapter.

### D22-D23 complete allocation and final-release timeline

| Phase | Complete ownership | Transition or terminal |
| --- | --- | --- |
| release/profile | Existing release owner binds every required delivery form to an exact candidate profile; boot provenance verifies local bytes | Unsupported required form stops release; local mismatch returns typed HOLD before Wbase/listen |
| Wbase/listen | Transfer owner withholds all 16 MiB, including standing Adrop and both terminal checks, before listener construction | Bind failure enters the same shutdown record; no partial release |
| accept/transfer | Adrop owns up to 48 pre-Socket roots; A/I and complete E banks own their disjoint live/retired HTTP/ws/send/receive/semantic copies | Existing D15-D21 acquisition, ACK/result and physical-credit rules apply |
| quiesce/drain | Capability is withdrawn; listener close is requested; all old A/I/E/send/receive/native identities remain charged | Server/Socket close projections and timeout release nothing; exact downstream transfers and drains finish first |
| first check | Wbase owns native wrappers and destroy bookkeeping; its terminal term preowns both barrier records, with the first record executing | First callback allocates the second record from that preowned term for the same generation and returns without release |
| native terminal | Pinned close phase deletes detached native wrappers; pinned native-immediate phase drains their destroy bookkeeping | These phases occur before the nested JavaScript immediate for the certified profile |
| second check | Wbase still owns the second callback and completion record; generation and zero-drain facts are revalidated | Callback signals completion and returns; it cannot release its own executing references |
| final handoff/release | After `processImmediate` returns, the exact completion record is in existing MessageRouter shutdown-operation custody and any scalar destroy ID is in Node Environment native-immediate custody | Existing shutdown continuation releases Wbase once and then its completion record; Node drains its scalar under the certified scheduler. The scalar is outside transfer ownership and carries no release capability; restart may allocate a new generation only after the once-only Wbase release |

### D22-D23 correction mapping and HOLD

| Finding | Effective correction | Remaining source gate |
| --- | --- | --- |
| D22 first immediate precedes native close | two nested public immediates after listener and A/I drain; second callback only signals, and post-unwind shutdown continuation performs once release | exact profile attests close/native-immediate order and future witness covers every entry phase and terminal reference |
| D23 optional label could remove required recovery | every currently supported recovery-capable delivery form requires a concrete certified profile before its release/readiness acceptance | release/platform owner records the exact supported matrix and future candidate receipts; arbitrary Node floor is not certification |
| accepted D21 population | 48-root standing Adrop and 4,792/6,080 KiB fixed banks remain unchanged | conservative native caps close preimplementation; adapter coefficients close on implemented source |
| accepted prior scope | complete pair, both node orders, colocation, old fragments, actual callback release, ordinary/snapshot isolation and caller 2de remain | cumulative source, startup/recovery and merge witnesses remain HOLD |

Product transport, runtime policy, release/deployment source, tests, metadata,
publication and merge remain unapproved. This section changes no pool, row,
deadline, retry, caller or transaction semantics.
