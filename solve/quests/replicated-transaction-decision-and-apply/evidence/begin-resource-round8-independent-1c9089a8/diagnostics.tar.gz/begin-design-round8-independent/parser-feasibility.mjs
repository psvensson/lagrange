import {pathToFileURL,fileURLToPath} from 'node:url';import{readFileSync}from'node:fs';import{dirname}from'node:path';
const root=process.argv[2],d=dirname(fileURLToPath(import.meta.url));const{SQLParser}=await import(pathToFileURL(root+'/src/query/sql-parser.js'));
const sql=readFileSync(d+'/specified-predicate-instantiation.sql','utf8').replace(/@[a-z_]+/g,'?');let result;try{const ast=new SQLParser(sql).parse();result={success:true,type:ast.type,columnCount:ast.columns?.length};}catch(e){result={success:false,message:e.message};}console.log(JSON.stringify({sql,result},null,2));
