from pathlib import Path
import json
p=Path(__file__).resolve().parent
x=json.loads((p/'classification-feasibility.json').read_text());r={a['name']:a for a in x['results']};bytecode=json.loads((p/'classification-explain.json').read_text())
assert r['valid-initial']['flags'][0]['initial_match']==1
assert r['valid-foreign']['priorCanonicalInitial'] and r['valid-foreign']['flags'][0]['immutable_match']==0
assert r['embedded-nul-exact']['flags'][0]['initial_match']==1 and r['embedded-nul-different']['flags'][0]['initial_match']==0
assert r['valid-multibyte']['flags'][0]['initial_match']==1
print('PASS valid initial, valid foreign, exact/different embedded NUL and multibyte positive controls')
for name in ['malformed-negative-epoch','malformed-mode','malformed-blob-session']:
 a=r[name];assert not a['priorCanonicalInitial'];assert a['flags'][0]['immutable_match']==a['flags'][0]['initial_match']==0
print('FAIL D8-1 specified producer emits FOREIGN flags for malformed immutable rows')
assert all(m['resultJsonBytes']==120 for m in x['memory']) and x['memory'][-1]['storedBytes']==8388608
assert any(o['opcode']=='Column' and o['p1']==0 and o['p2']==1 and o['p5']==0 for o in bytecode)
print('FAIL D8-2 fixed120-byte result coexists with unguarded OP_Column full-value load; native allocation proven by pinned VDBE source, not zero memory counters')
assert x['parameterMaterialization'][1]['singleFlightKeyBytes']>x['parameterMaterialization'][0]['singleFlightKeyBytes']
print('FAIL D8-2 variable request parameter/key/native binding representations are absent from the claimed fixed-only query phase census')
assert x['localCdcMerge']==[]
print('FAIL D8-3 existing CDC local authoritative merge drops valid three-column classification')
a=r['replacement-vs-unpaired-surrogate'];assert a['expectedCanonical'] and not a['jsImmutableMatch'] and a['boundUtf8BlobSessionMatch']==1
b=r['unpaired-surrogate-self'];assert not b['jsImmutableMatch'] and b['flags'][0]['initial_match']==1
print('FAIL D8-4 UTF8-blob and native-text binding variants do not preserve existing JS identity equality over accepted strings')
print('DESIGN feasibility findings only; no future implementation test or source approval claimed')
