#include <sqlite3ext.h>
SQLITE_EXTENSION_INIT1
static void used(sqlite3_context *c,int n,sqlite3_value **v){sqlite3_result_int64(c,sqlite3_memory_used());}
static void high(sqlite3_context *c,int n,sqlite3_value **v){sqlite3_result_int64(c,sqlite3_memory_highwater(0));}
static void reset(sqlite3_context *c,int n,sqlite3_value **v){sqlite3_memory_highwater(1);sqlite3_result_int64(c,sqlite3_memory_used());}
int sqlite3_nativecensus_init(sqlite3 *db,char **err,const sqlite3_api_routines *api){SQLITE_EXTENSION_INIT2(api);sqlite3_create_function(db,"diag_native_used",0,SQLITE_UTF8,0,used,0,0);sqlite3_create_function(db,"diag_native_high",0,SQLITE_UTF8,0,high,0,0);return sqlite3_create_function(db,"diag_native_reset",0,SQLITE_UTF8,0,reset,0,0);}
