import {pathToFileURL,fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {writeFileSync} from 'node:fs';
import {dirname} from 'node:path';
const root=process.argv[2],here=dirname(fileURLToPath(import.meta.url)),require=createRequire(root+'/package.json');
const Database=require('better-sqlite3');
const imp=p=>import(pathToFileURL(root+'/'+p));
const {SQL_TRANSACTIONS_SCHEMA}=await imp('src/bootstrap/system-table-workflow-schema-definitions.js');
const {generateCreateTableSQL}=await imp('src/bootstrap/system-table-schema-sql.js');
const {collectBoundedSqliteRows}=await imp('src/query/query-result-budget.js');
const {isCanonicalInitialRow}=await imp('src/query/distributed/distributed-transaction-creation-contract.js');
const {mergeAuthoritativeSystemTableRowSets}=await imp('src/cdc/cdc-integration-service-authoritative-read-flow.js');
const {stableSerialize}=await imp('src/control-plane/control-plane-system-table-gateway-normalizers.js');
const db=new Database(':memory:');db.loadExtension(here+'/native_census.so');
const schemaSql=generateCreateTableSQL(SQL_TRANSACTIONS_SCHEMA);db.exec(schemaSql);
const row={transaction_id:'a'.repeat(32),session_id:'ordinary-session',status:'ACTIVE',transaction_epoch:1,timeout_deadline:1000000,transaction_mode:'EXPLICIT',participant_set_state:'OPEN',participant_set_text:'[]',commit_mode:'NOT_SELECTED',frozen_participant_count:0,updated_at:0,decision:null,decision_text:null,decision_digest:null,created_at:0};
const immutable=['transaction_id','session_id','transaction_epoch','timeout_deadline','transaction_mode','created_at'];
const fields=Object.keys(row),pred=k=>row[k]===null?`${k} IS NULL`:typeof row[k]==='string'?`(typeof(${k}) = 'text' AND CAST(${k} AS BLOB) = CAST(@${k} AS BLOB))`:`(typeof(${k}) = 'integer' AND ${k} = @${k})`;
const immutablePred=immutable.map(pred).join(' AND '),initialPred=fields.map(pred).join(' AND ');
const sql=`SELECT @attempt_key AS attempt_key, CASE WHEN ${immutablePred} THEN 1 ELSE 0 END AS immutable_match, CASE WHEN ${initialPred} THEN 1 ELSE 0 END AS initial_match FROM sql_transactions WHERE transaction_id=@transaction_id`;
writeFileSync(here+'/specified-predicate-instantiation.sql',sql+'\n');
const stmt=db.prepare(sql);const params=r=>Object.fromEntries([...Object.entries(r).filter(([k,v])=>v!==null),['attempt_key','b'.repeat(64)]]);
const insert=db.prepare('INSERT INTO sql_transactions ('+fields.join(',')+') VALUES ('+fields.map(k=>'@'+k).join(',')+')');
const store=r=>{db.exec('DELETE FROM sql_transactions');insert.run(r);};
const classify=(expected=row)=>collectBoundedSqliteRows(stmt,[params(expected)],{maxRows:1,maxBytes:128,deadlineMs:Date.now()+10000});
const results=[];
for(const [name,stored,expected]of[
 ['valid-initial',row,row],
 ['valid-foreign',{...row,session_id:'different-session'},row],
 ['malformed-negative-epoch',{...row,transaction_epoch:-1},row],
 ['malformed-mode',{...row,transaction_mode:'UNRECOGNIZED'},row],
 ['malformed-blob-session',{...row,session_id:Buffer.from('ordinary-session')},row],
 ['embedded-nul-exact',{...row,session_id:'a\0b'},{...row,session_id:'a\0b'}],
 ['embedded-nul-different',{...row,session_id:'a\0b'},{...row,session_id:'a\0c'}],
 ['replacement-vs-unpaired-surrogate',{...row,session_id:'\ufffd'},{...row,session_id:'\ud800'}],
 ['unpaired-surrogate-self',{...row,session_id:'\ud800'},{...row,session_id:'\ud800'}],
 ['valid-multibyte',{...row,session_id:'💾'},{...row,session_id:'💾'}]
]){store(stored);const observed=db.prepare('SELECT * FROM sql_transactions').get();results.push({name,expectedSessionCodeUnits:[...expected.session_id].map(c=>c.charCodeAt(0)),storedType:db.prepare('SELECT typeof(session_id) AS sessionType,typeof(transaction_epoch) AS epochType FROM sql_transactions').get(),storedSessionCodeUnits:typeof observed.session_id==='string'?[...observed.session_id].map(c=>c.charCodeAt(0)):null,nativeHex:db.prepare('SELECT hex(CAST(session_id AS BLOB)) AS stored, hex(CAST(@value AS BLOB)) AS parameter FROM sql_transactions').get({value:expected.session_id}),nodeUtf8Hex:Buffer.from(expected.session_id,'utf8').toString('hex'),boundUtf8BlobSessionMatch:db.prepare("SELECT typeof(session_id)='text' AND CAST(session_id AS BLOB)=@bytes AS matches FROM sql_transactions").get({bytes:Buffer.from(expected.session_id,'utf8')}).matches,priorCanonicalInitial:isCanonicalInitialRow(observed),expectedCanonical:isCanonicalInitialRow(expected),jsImmutableMatch:immutable.every(k=>observed[k]===expected[k]),flags:classify(expected)});}
const memory=[];
for(const bytes of [1024,1024*1024,8*1024*1024]){
 store({...row,session_id:'x'.repeat(bytes)});
 const baseline=db.prepare('SELECT diag_native_reset() AS n').get().n;
 const flags=classify();
 const stats=db.prepare('SELECT diag_native_used() AS used,diag_native_high() AS high').get();
 memory.push({kind:'foreign-session',storedBytes:bytes,resultJsonBytes:Buffer.byteLength(JSON.stringify(flags[0])),baseline,...stats,peakDelta:stats.high-baseline,flags});
}
store(row);
const explain=db.prepare('EXPLAIN '+sql).all(params(row));writeFileSync(here+'/classification-explain.json',JSON.stringify(explain,null,2)+'\n');
const result={root,sqlite:db.prepare('SELECT sqlite_version() AS version,sqlite_source_id() AS source').get(),schemaSql,sql,results,memory,localCdcMerge:mergeAuthoritativeSystemTableRowSets({getPrimaryKeyField:()=> 'transaction_id'},'sql_transactions',[[{attempt_key:'b'.repeat(64),immutable_match:1,initial_match:1}]]),parameterMaterialization:[16,20000].map(n=>{const p=params({...row,session_id:'s'.repeat(n)});return {sessionBytes:n,parameterTextBytes:Object.values(p).filter(v=>typeof v==='string').reduce((a,v)=>a+Buffer.byteLength(v),0),singleFlightKeyBytes:Buffer.byteLength(stableSerialize({kind:'control-plane-read',tableName:'sql_transactions',sql,params:p}))};})};
db.close();console.log(JSON.stringify(result,null,2));
