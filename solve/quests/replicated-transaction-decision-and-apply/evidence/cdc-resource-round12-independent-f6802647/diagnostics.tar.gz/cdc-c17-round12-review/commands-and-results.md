# Round-twelve independent native successor diagnostic

Working directory:
`/mnt/data/peter/projects/.worktrees/rs-raft-candidate-20261011/test-output/continuation-20261011/cdc-c17-round12-review`

Exact executed command:

```sh
/mnt/data/peter/projects/.worktrees/tx1-cdc-20261011/test-output/cdc-adrop-layout-20261011/node-22.22.0-production successor-record-probe.cjs . > successor-record-probe.log 2>&1
```

Exit 0. Three sequential generations use the real two-check scheduler boundary.
Each second callback has an ordinary companion. Its awaited continuation
synchronously starts and schedules shutdown of the successor, representing the
native schedule reachable through a synchronous release wake. It does not
simulate or certify the future transfer-owner capacity/CAS implementation.
No scheduler or prototype is monkey-patched. Immediate records receive a marker
but their handles are not stored after scheduling.

Heap snapshot results:
- generation1 first: 1:first
- generation1 successor queued: 1:second and2:first
- generation2 first: 2:first
- generation2 successor queued: 2:second and3:first
- generation3 first: 3:first
- final control: no marked records

Snapshots were decoded using their own node_fields/edge_fields/types and
associated strides. Only objects with the cdcRound12 property were selected;
marker, object name and self_size are retained in successor-record-results.json.
Instrumentation self sizes104/136 bytes are not source coefficients. This is
native schedule feasibility, not proof of arbitrary future captures, actual
pool mutation, application recovery or a resource overflow.

Python hashlib checks independently verified the3004-line/197829-byte b4b subject,
full184960-byte ce9e predecessor prefix,197-line e4e delta, actual24c5...0797d7
prior report, all11 a2d diagnostic entries, and all34 pinned application/deployment
paths. Five additional lifecycle/scheduler consumer sources were captured with
hashes under source/. Complete results and exact arithmetic are in navigation.json.

The prior report citation in D:2815 is63 hex digits, omitting the true hash's last7.
This typo is reported without mutating the frozen design. No current product,
source test, Quest, index, stage, commit or remote was changed.
