
## D24 effective scheduler-record custody correction

The exact D22-D23 subject is retained by the round-eleven review as
`subject-ce9e463c.md`, SHA-256
`ce9e463cdfa829c1e5fd83ec49bde87fca0258d615b87b72582b46048ce23201`.
The complete independent report has SHA-256
`24c5c10ad6a0cd4ef9f39b8637b9e1777a6b9a70f0b24d40d1d4fe370c0797d`.
Its diagnostic directory is
`test-output/continuation-20261011/cdc-c17-round11-review` in the retained
rs-raft candidate worktree. `diagnostic-sha256.txt` has SHA-256
`a2d93b3c6a7b22467974445ac2d559b7d1fc6f02b276dbf167cf46d5ac029585`
and `navigation.json` has SHA-256
`ff182302edce4df95a66f44d39f88b98658882da8accfbd424196d68113c25e7`.

This section supersedes only D22's claim that the awaited shutdown continuation
necessarily runs after `processImmediate` has returned, its scalar-only final
handoff, and the corresponding final timeline row. Every earlier per-listener
reference to returning or releasing all of Wbase now means the once-only
`Wlistener` return below; `Rterminal` is continuously retained. The two public
checks remain the native close boundary. D23 remains closed at design scope.
The standing 48-root population, fixed subordinate banks, complete-pair order,
ACK/result interaction, receive phases, original pool and supported row
equations remain unchanged. The caller source at
`2de419483c9b4ce9e3fabc87bb54d93e4afb8817` remains closed.

### Actual residual graph and its existing owners

The selected Node source detaches the current Immediate list from the public
queue, then invokes `runNextTicks` between callbacks. If the second coverage
callback settles the shutdown promise and an ordinary companion Immediate
follows it, the shutdown continuation can run inside that checkpoint while
`processImmediate` is still on the stack. At that point the second callback is
cleared, but these references can coexist:

1. Node's `prevImmediate` stack slot retains the executed second coverage
   `Immediate`; that object retains its already allocated `_idleNext` pointer
   to the ordinary companion;
2. Node's current-list and `immediate` stack slots retain the companion and the
   rest of the detached ordinary list;
3. the MessageRouter shutdown continuation retains its completion Promise/
   reaction, generation/drain record and the transfer release capability; and
4. when async destroy hooks exist, Node's destroy queue retains the coverage
   Immediate's scalar async ID.

The round-eleven diagnostic observes exactly the first item at the continuation:
one marked 136-byte instrumented `Immediate` with `_onImmediate` cleared and
`_idleNext` pointing to the companion. Its stack contains `runNextTicks` and
`processImmediate`. The marked record is absent at the later control. The
136-byte value identifies the mechanism and is not a production coefficient.

Physical and semantic ownership stay with existing owners. Node Environment
owns the detached-list nodes, scheduler stack slots and destroy queue.
MessageRouter owns one shutdown generation and its completion reaction.
`CdcCoverageTransferOwner` owns the bytes and the only capacity-release token.
The ordinary companion and later ordinary-list nodes remain charged to their
existing scheduler/caller contracts: the coverage-attributed byte is the
pointer field in its own Immediate record. At the observed checkpoint Node's
current `immediate` slot independently retains the companion, so the coverage
link does not make the ordinary list a second CDC allocation.

### Standing terminal subreserve

D22's already preowned 16 KiB terminal term becomes `Rterminal`, a node-lifetime
subreserve of the existing 16 MiB Wbase claim. This is a lifecycle split in the
existing transfer owner, not a new pool, session, store, scheduler or root
token:

```text
Wbase while a listener generation is active
  = Wlistener (16 MiB - 16 KiB) + Rterminal (16 KiB)

retained base ownership after that generation returns listener capacity
  = Rterminal (16 KiB), still retained by the same node-pool owner
```

The first coverage activation withholds the complete 16 MiB atomically.
`Rterminal` is never placed on a free list and never produces a wake between
listener generations. A successor reserves only `Wlistener`; together its
listener claim and the standing `Rterminal` are the same 16 MiB Wbase already
used by every whole-pool equation. `Rterminal` is infrastructure and consumes
neither one of the eight root-session identities nor a subordinate wire token.
It cannot be borrowed by row data, ordinary traffic or snapshot transfer. It is
never returned to the transfer pool during the Node Environment's lifetime,
even when no endpoint or wake is currently registered: absence of a current
waiter does not prove that a later in-process successor cannot start. The Node
Environment/process teardown reclaims it with the rest of the process and emits
no pool wake.

The selected runtime profile and future implementation must prove this complete
maximum inside the existing 16 KiB term:

| Terminal population that can coexist | Count bound | Byte ceiling |
| --- | ---: | ---: |
| coverage `Immediate` records, including callback/cleared-callback fields, async symbols and their own list links | 2 | 4 KiB |
| MessageRouter shutdown generation/completion Promise/reaction records | 2 | 8 KiB |
| coverage-attributed `processImmediate`/`runNextTicks` stack and list alias slots, at most two scalar destroy IDs, and the fixed transfer handoff descriptor | one active alias set | 4 KiB |
| **Total** | finite population above | **16 KiB** |

The two-Immediate maximum covers the worst real overlap: the old second record
can remain on the executing list while a synchronous release wake queues the
successor generation's first check. The successor cannot execute that first
check or create its nested second check until the old `processImmediate` has
finished. At first-check entry the old executed record and its stack/list aliases
are therefore terminal; the bank changes generations before the new callback
allocates its nested second record. Repeated shutdown calls share one generation
record. A third shutdown generation cannot reach a check while the successor
still owns `Wlistener`. Thus two coverage Immediate records and two completion
records are conservative simultaneous maxima, independent of the number of
ordinary companion callbacks.

The 4/8/4 KiB subdivisions are hard design ceilings, not values inferred from
the 136-byte diagnostic. Exact shallow objects, retained coverage closures,
Promise reactions and coverage-attributable aliases must be measured on the
selected artifact and must fit both their subdivision and aggregate ceiling.
An overrun is a source STOP requiring a real-copy reduction or owner decision;
it cannot increase the pool, Wbase or the terminal term.

### Atomic terminal transfer before the synchronous wake

The second check still only validates the generation/drain facts and settles
the existing completion. Its awaited continuation may run either after
`processImmediate` or at the demonstrated between-callback checkpoint. It uses
one compare-and-transfer operation on the existing Wbase claim. Under the
`CdcCoverageTransferOwner` mutation that operation, in this order:

1. matches the exact boot, listener generation, Wbase claim and shutdown record,
   and refuses a stale or already transferred call;
2. writes the MessageRouter record as `terminal-transferred`, consumes its sole
   Wlistener release capability, and replaces every transport/resource pointer
   exposed to later callers with a fixed terminal result;
3. records in `Rterminal` the old generation plus the actual occupied
   Immediate/list/stack/completion/destroy categories and count, while Node and
   MessageRouter retain the physical references named above;
4. reduces the pool's retained byte count by exactly `Wlistener`, leaving the
   16 KiB `Rterminal` continuously held; and only then
5. invokes the existing transfer-owner wake callbacks synchronously.

There is no free interval between steps 3 and 4. A wake that immediately starts
or stops a successor sees the old generation terminal, cannot acquire its
release token, and reserves only the new `Wlistener`. It may queue one new first
check into the unused second Immediate slot. The old continuation performs no
pool or generation mutation after the wake; it returns through Node's actual
list and Promise machinery. External callers may retain the settled shutdown
Promise under the ordinary call contract, but the fixed terminal result contains
no Wbase token, transport graph or successor authority.

No callback is added to discover the old callback's return. If no successor
ever runs a first check, the conservative old descriptor can remain in the
standing bank without growing or withholding another root session. If a
successor later reaches its existing first check, that entry itself proves that
the prior `processImmediate` invocation and old stack/list aliases have ended;
MessageRouter supplies that phase fact to the existing transfer owner, which
replaces the old fixed descriptor with the current generation's descriptor
without returning capacity or firing a wake. Node independently drains its
scalar async ID under its certified scheduler contract.

If the exact transfer fails, its identity has changed, or any count/byte ceiling
would be exceeded, Wlistener remains owned, no wake runs and restart remains
blocked. A shutdown timeout, callback settlement, cleared `_onImmediate`,
server/Socket close or async-destroy notification cannot bypass this operation.

### Corrected whole release and successor timeline

| Phase | Complete custody | Capacity/restart effect |
| --- | --- | --- |
| active generation | Existing owner holds `Wlistener + Rterminal = 16 MiB`; A/I/E/native and terminal slots retain their exact identities | No successor listener generation can acquire Wlistener |
| drain and first check | MessageRouter drains all A/I/HTTP/ws/ledger/send/emitter references; Wbase still holds native and terminal capacity | Timeout or close projection releases nothing |
| native boundary | First check queues the nested second; the intervening native close and native-immediate phases retire the detached TCP roots | Second check may run only after this boundary; D22 remains operative |
| second callback | `Rterminal` owns capacity for the executing second record and completion; callback settles once and returns | No capacity changes and no wake runs |
| continuation checkpoint | Old second Immediate/list/stack aliases, completion reaction and possible destroy ID remain physically owned as above | Exact compare-and-transfer installs `terminal-transferred` and its bounded descriptor before release |
| Wlistener return | Transfer owner retains `Rterminal`, consumes the old release token, subtracts only Wlistener, then synchronously calls existing wakes | A successor may reserve Wlistener immediately, but cannot mutate or release the old generation |
| successor overlap | At most the old second record and a queued new first record, plus their two completion records, occupy the standing 16 KiB | New first-check entry proves the old scheduler aliases ended before it can allocate new second check; no third barrier or recursive callback |
| process owner teardown | Standing bank has no traffic authority and no population growth; it remains reserved across listener generations and endpoint-free intervals | It is never returned to an in-process waiter; Node Environment/process teardown reclaims it with the remaining scheduler state |

The whole supported equations remain `85 MiB` for the 8 MiB row and
`125 MiB + 5 B` for one 16 MiB-plus-one-byte event: active
`Wlistener + Rterminal` is exactly the existing 16 MiB Wbase, never an added
16 KiB. The 48-root 480 KiB Adrop maximum remains inside 512 KiB, and the remote
4,792 KiB and colocated 6,080 KiB subordinate banks remain inside the same
8 MiB fixed term.

### D24 source gate and retained scope

The future source witness must run the round-eleven ordinary-companion schedule
and show: the residual record at the continuation; exact category/count/byte
occupancy; terminal state and consumed old token before the transfer owner's
synchronous wake; a wake that starts and immediately stops a successor; at most
the declared two/two population; one Wlistener return; no stale release of the
successor; and unchanged pool arithmetic. It must also retain D22's positive
first/second native-wrapper distinction and every shutdown entry phase.

This is a design correction only. Product transport, runtime policy,
release/deployment source, tests, metadata, publication and merge remain HOLD.
It introduces no scheduler, ledger, retry owner, timing barrier, global cap,
pool increase, ordinary/snapshot borrowing or support downgrade. D23 and caller
2de remain closed.
