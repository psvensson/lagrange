'use strict';
// Native scheduling feasibility only. This is not the future transfer-owner CAS.
const fs = require('node:fs');
const path = require('node:path');
const v8 = require('node:v8');
const output = process.argv[2];
const events = [];
function capture(label) {
  v8.writeHeapSnapshot(path.join(output, label + '.heapsnapshot'));
}
function mark(handle, generation, check) {
  handle.cdcRound12 = generation + ':' + check;
}
async function shutdown(generation) {
  await new Promise((resolve) => {
    mark(setImmediate(() => {
      events.push(generation + ':first');
      capture(generation + '-first');
      mark(setImmediate(() => {
        events.push(generation + ':second');
        resolve();
      }), generation, 'second');
      setImmediate(() => events.push(generation + ':ordinary-companion'));
    }), generation, 'first');
  });
  events.push(generation + ':continuation');
  if (generation < 3) {
    // Native schedule corresponding to a synchronous release wake which starts
    // and immediately shuts down the successor. No simulated capacity verdict.
    shutdown(generation + 1).catch(fail);
    capture(generation + '-successor-queued');
  } else {
    setImmediate(() => {
      capture('final-control');
      fs.writeFileSync(path.join(output, 'successor-events.json'),
        JSON.stringify({versions: process.versions, events}, null, 2) + '\n');
    });
  }
}
function fail(error) {
  process.stderr.write(String(error.stack));
  process.exitCode = 1;
}
shutdown(1).catch(fail);
