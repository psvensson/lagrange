import json,hashlib
from pathlib import Path
D=Path(__file__).parent
r=json.loads((D/'independent-feasibility.json').read_text())
a=json.loads((D/'author-feasibility-rerun.json').read_text())
t=json.loads((D/'inbound-retention.json').read_text())
checks={
 'original-author-feasibility-byte-identical':hashlib.sha256((D/'author-feasibility-rerun.json').read_bytes()).hexdigest()=='d152760498062037c344df8f14b3be297624595f2618ac28df990d3e9c6f4f88',
 'metadata-refuses-before-private-predicate':next(x for x in a['cases'] if x['name']=='oversized-metadata-only')['predicateCalls']==0,
 'upgrade-invokes-predicate-with-full-input':next(x for x in a['cases'] if x['name']=='oversized-after-upgrade')['predicateInputBytes']==8388640,
 'valid-foreign-separated':next(x for x in a['cases'] if x['name']=='valid-foreign')['result'][0]['identity_state']==2,
 'malformed-epoch-invalid':next(x for x in a['cases'] if x['name']=='malformed-negative-epoch')['result'][0]['identity_state']==0,
 'same-length-invalid-mode-refused':r['invalidSameLengthEnum']['result'][0]['identity_state']==0,
 'advanced-marker-fixed-no-manifest-returned':r['largeAdvanced']['result'][0]['initial_match']==0 and r['largeAdvanced']['predicateInputBytes']==48,
 'ordinary-nul-inside-supplementary-positive':all(x['result'][0]['identity_state']==1 for x in r['controls'] if x['valueHex'] in ['6f7264696e6172792d73657373696f6e','610062','f09f92be']),
 'bom-canonical-but-invalid-counterexample':next(x for x in r['controls'] if x['valueHex']=='efbbbf')['scalar'] and next(x for x in r['controls'] if x['valueHex']=='efbbbf')['result'][0]['identity_state']==0,
 'leading-nul-producer-counterexample':all(x['scalar'] and not x['success'] and x['message']=='transaction_initial_row_refused' and x['durableRows']==0 for x in r['producer']['rows'] if x['sessionHex'] in ['00','0061']),
 'cohort-affordable-individually-stalled-together':r['upgrade']['eachRecordAloneWithUpgradeFits'] and all(not x['admitted'] and x['tokenRetained'] for x in r['upgrade']['rotation']),
 'inbound-ack-does-not-retire-handler':t['peak']['requests']==4 and t['peak']['acknowledgedBeforeHandlerCompletion']==4 and t['peak']['aggregateParsedSessionBytes']==65536,
 'with-source-needs-explicit-owner-tag':r['route']['implicitWithSource'] is None and r['route']['explicitReadSource']=='control-plane:read:sql_transactions',
 'ordinary-function-needs-new-admission-gate':r['route']['ordinaryPrivateFunctionCurrentlyAdmitted'] is True,
}
for name,ok in checks.items():print(('CONFIRMED' if ok else 'UNEXPECTED')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} expected observations confirmed; this is not a source or design acceptance count.')
raise SystemExit(0 if all(checks.values()) else 1)
