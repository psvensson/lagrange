import fs from 'node:fs';
import Database from '/mnt/data/peter/projects/.worktrees/rs-raft-startup-integration-20261011/node_modules/better-sqlite3/lib/index.js';
import {TextDecoder} from 'node:util';

const fatalUtf8 = new TextDecoder('utf-8', {fatal: true});
const TX = 'a'.repeat(32);
const KEY = 'b'.repeat(64);
const MAX_SAFE = Number.MAX_SAFE_INTEGER;
const IDENTITY = Object.freeze({INVALID: 0, SAME: 1, FOREIGN: 2, INPUT_RESERVATION_REQUIRED: 3});
let predicateCalls = 0;
let predicateInputBytes = 0;
function scalarString(value) {
  if (typeof value !== 'string' || value.length === 0) return false;
  for (let i = 0; i < value.length; i += 1) {
    const unit = value.charCodeAt(i);
    if (unit >= 0xd800 && unit <= 0xdbff) {
      if (i + 1 >= value.length) return false;
      const next = value.charCodeAt(++i);
      if (next < 0xdc00 || next > 0xdfff) return false;
    } else if (unit >= 0xdc00 && unit <= 0xdfff) return false;
  }
  return true;
}
function decodeCanonical(buffer) {
  try { return fatalUtf8.decode(buffer); } catch { return null; }
}
function identityState(storedSession, storedEpoch, storedDeadline, storedMode,
  storedCreated, expectedSession, expectedEpoch, expectedDeadline,
  expectedMode, expectedCreated) {
  predicateCalls += 1;
  predicateInputBytes += storedSession.length + expectedSession.length +
    storedMode.length + expectedMode.length;
  const storedSessionText = decodeCanonical(storedSession);
  const expectedSessionText = decodeCanonical(expectedSession);
  const storedModeText = decodeCanonical(storedMode);
  const expectedModeText = decodeCanonical(expectedMode);
  if (!scalarString(storedSessionText) || !scalarString(expectedSessionText) ||
      !['AUTOCOMMIT', 'EXPLICIT'].includes(storedModeText) ||
      !['AUTOCOMMIT', 'EXPLICIT'].includes(expectedModeText) ||
      !Number.isSafeInteger(storedEpoch) || storedEpoch < 0 ||
      !Number.isSafeInteger(storedDeadline) || storedDeadline < storedCreated ||
      !Number.isSafeInteger(storedCreated) || storedCreated < 0) {
    return IDENTITY.INVALID;
  }
  return storedSession.equals(expectedSession) &&
    storedEpoch === expectedEpoch && storedDeadline === expectedDeadline &&
    storedMode.equals(expectedMode) && storedCreated === expectedCreated ?
    IDENTITY.SAME : IDENTITY.FOREIGN;
}
const db = new Database(':memory:');
db.function('lagrange_creation_identity_state', {deterministic: true}, identityState);
db.exec(`CREATE TABLE sql_transactions (
 transaction_id TEXT PRIMARY KEY, session_id TEXT NOT NULL, status TEXT NOT NULL,
 transaction_epoch INTEGER, timeout_deadline INTEGER, transaction_mode TEXT NOT NULL,
 participant_set_state TEXT NOT NULL, participant_set_text TEXT,
 commit_mode TEXT NOT NULL, frozen_participant_count INTEGER NOT NULL,
 decision TEXT, decision_text TEXT, decision_digest TEXT,
 created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)`);
const sql = `WITH classified AS MATERIALIZED (
 SELECT CASE
   WHEN typeof(transaction_id) <> 'text' OR octet_length(transaction_id) <> 32
     OR transaction_id GLOB '*[^0-9a-f]*' THEN 0
   WHEN typeof(session_id) <> 'text' OR octet_length(session_id) = 0 THEN 0
   WHEN typeof(transaction_epoch) <> 'integer' OR transaction_epoch < 0
     OR transaction_epoch > 9007199254740991 THEN 0
   WHEN typeof(timeout_deadline) <> 'integer' OR timeout_deadline < 0
     OR timeout_deadline > 9007199254740991 THEN 0
   WHEN typeof(created_at) <> 'integer' OR created_at < 0
     OR created_at > 9007199254740991 OR timeout_deadline < created_at THEN 0
   WHEN typeof(transaction_mode) <> 'text'
     OR octet_length(transaction_mode) NOT IN (8,10) THEN 0
   WHEN octet_length(session_id) > @input_cap THEN 3
   ELSE lagrange_creation_identity_state(
     CAST(session_id AS BLOB), transaction_epoch, timeout_deadline,
     CAST(transaction_mode AS BLOB), created_at, CAST(@session_id AS BLOB),
     @transaction_epoch, @timeout_deadline, CAST(@transaction_mode AS BLOB),
     @created_at)
   END AS identity_state,
   CASE
    WHEN typeof(status) <> 'text' OR octet_length(status) <> 6 THEN 0
    WHEN CAST(status AS BLOB) <> x'414354495645' THEN 0
    WHEN typeof(participant_set_state) <> 'text'
      OR octet_length(participant_set_state) <> 4 THEN 0
    WHEN CAST(participant_set_state AS BLOB) <> x'4f50454e' THEN 0
    WHEN typeof(participant_set_text) <> 'text'
      OR octet_length(participant_set_text) <> 2 THEN 0
    WHEN CAST(participant_set_text AS BLOB) <> x'5b5d' THEN 0
    WHEN typeof(commit_mode) <> 'text' OR octet_length(commit_mode) <> 12 THEN 0
    WHEN CAST(commit_mode AS BLOB) <> x'4e4f545f53454c4543544544' THEN 0
    WHEN typeof(frozen_participant_count) <> 'integer'
      OR frozen_participant_count <> 0 THEN 0
    WHEN typeof(updated_at) <> 'integer' OR updated_at <> created_at THEN 0
    WHEN decision IS NOT NULL OR decision_text IS NOT NULL
      OR decision_digest IS NOT NULL THEN 0
    ELSE 1 END AS initial_candidate,
   octet_length(session_id) AS stored_input_bytes
 FROM sql_transactions WHERE transaction_id=@transaction_id)
SELECT @transaction_id AS transaction_id, @attempt_key AS attempt_key,
 identity_state,
 CASE WHEN identity_state=1 THEN initial_candidate ELSE 0 END AS initial_match,
 CASE WHEN identity_state=3 THEN stored_input_bytes ELSE 0 END AS required_input_bytes
FROM classified`;
const insert = db.prepare(`INSERT INTO sql_transactions VALUES
 (@transaction_id,@session_id,@status,@transaction_epoch,@timeout_deadline,
  @transaction_mode,@participant_set_state,@participant_set_text,@commit_mode,
  @frozen_participant_count,@decision,@decision_text,@decision_digest,
  @created_at,@updated_at)`);
function row(session='ordinary-session') { return {
 transaction_id: TX, session_id: session, status:'ACTIVE', transaction_epoch:7,
 timeout_deadline:5000, transaction_mode:'EXPLICIT', participant_set_state:'OPEN',
 participant_set_text:'[]', commit_mode:'NOT_SELECTED', frozen_participant_count:0,
 decision:null, decision_text:null, decision_digest:null, created_at:1000, updated_at:1000}; }
function params(expected='ordinary-session', cap=1048576) { return {
 transaction_id:TX, attempt_key:KEY, input_cap:cap, session_id:expected,
 transaction_epoch:7, timeout_deadline:5000, transaction_mode:'EXPLICIT', created_at:1000}; }
function reset(r, rawSql=null) { db.exec('DELETE FROM sql_transactions'); rawSql ? db.exec(rawSql) : insert.run(r); }
function classify(name, r, expected='ordinary-session', cap=1048576, rawSql=null) {
 reset(r, rawSql); predicateCalls=0; predicateInputBytes=0;
 const result=db.prepare(sql).all(params(expected,cap));
 return {name,result,predicateCalls,predicateInputBytes,resultJsonBytes:Buffer.byteLength(JSON.stringify(result))};
}

import {installTransactionSchemaEnforcement} from './navigation/src/query/distributed/distributed-transaction-schema-enforcement.js';
import {initializeCreationResources, reserveCreationRecordEnvelope, totalPendingBytes} from './navigation/src/query/distributed/distributed-transaction-creation-resources.js';
import {admitPartitionStatement} from './navigation/src/partition/partition-statement-admission.js';
import {resolveControlPlaneSystemTableDeliverySource} from './navigation/src/control-plane/control-plane-system-table-gateway-normalizers.js';
import {PartitionServiceEntryApplyBase} from './navigation/src/partition/partition-service-entry-apply-base.js';
const controls = ['ordinary-session','a\0b','\0','\0a','\ufeff','\ufeffx','💾'].map(value => ({
  valueHex:Buffer.from(value).toString('hex'), scalar:scalarString(value),
  ...classify('same-canonical-scalar',row(value),value),
}));
const advanced=row(); advanced.status='COMMITTED'; advanced.participant_set_text='x'.repeat(8*1024*1024); advanced.decision='COMMIT';
const largeAdvanced=classify('same-advanced-large-mutable',advanced);
const invalidMode=row(); invalidMode.transaction_mode='BAD_MODE';
const invalidSameLengthEnum=classify('invalid-eight-byte-mode',invalidMode);
const ordinaryFunctionAdmission=admitPartitionStatement({db, tableName:'sql_transactions'},'SELECT lagrange_creation_identity_state(CAST(session_id AS BLOB), transaction_epoch, timeout_deadline, CAST(transaction_mode AS BLOB), created_at, CAST(session_id AS BLOB), transaction_epoch, timeout_deadline, CAST(transaction_mode AS BLOB), created_at) AS identity_state FROM sql_transactions',[]);
db.exec('DELETE FROM sql_transactions');
const enforcer=installTransactionSchemaEnforcement(db);
const producer=[];
for(const session of ['ordinary-session','a\0b','\0','\0a','\ufeff','💾']) {
  db.exec('DELETE FROM sql_transactions');
  try {insert.run(row(session)); producer.push({sessionHex:Buffer.from(session).toString('hex'), scalar:scalarString(session), success:true, durable:db.prepare('SELECT hex(session_id) AS bytes FROM sql_transactions').get()});}
  catch(e){producer.push({sessionHex:Buffer.from(session).toString('hex'), scalar:scalarString(session), success:false, code:e.code, message:e.message, durableRows:db.prepare('SELECT count(*) n FROM sql_transactions').get().n});}
}
const owner={transactionBudgetMs:10000}; initializeCreationResources(owner,{});
const first=reserveCreationRecordEnvelope(owner,256,TX,'session-1','EXPLICIT');
const base=first.bytes;
owner.maxPendingTransactionCreationBytes=2*base+1;
const second=reserveCreationRecordEnvelope(owner,256,TX.replace(/a/g,'c'),'session-2','EXPLICIT');
const upgradeBytes=base;
const rotation=[];
for(let turn=0;turn<8;turn++){const token=turn%2===0?first:second;const admitted=totalPendingBytes(owner)+upgradeBytes<=owner.maxPendingTransactionCreationBytes;rotation.push({turn, record:turn%2, before:totalPendingBytes(owner), need:upgradeBytes, admitted, tokenRetained:token.released===false});}
const removalGate=PartitionServiceEntryApplyBase.prototype.resolveRemovalServingAdmission.call({
 removalServingAdmissionFenced:true,
 isRemovalServingRequestType:()=>true,
 resolveOpenTransactionState:()=>null,
}, {type:'QUERY',sql,params:params()});
fs.writeFileSync(new URL('classification.sql',import.meta.url),sql+'\n');
fs.writeFileSync(new URL('classification-explain.json',import.meta.url),JSON.stringify(db.prepare(`EXPLAIN ${sql}`).all(params()),null,2)+'\n');
const output={
 scope:'Real deployed SQLite and immutable 86af owner methods; pool upgrade is the proposed rule modeled atop existing resource tokens, not implemented source.',
 sqlite:db.prepare('SELECT sqlite_version() version').get(),controls,largeAdvanced,invalidSameLengthEnum,
 producer:{enforcer,rows:producer},
 route:{implicitWithSource:resolveControlPlaneSystemTableDeliverySource({tableName:'sql_transactions',sql}),explicitReadSource:resolveControlPlaneSystemTableDeliverySource({tableName:'sql_transactions',sql,operationKind:'read'}),ordinaryPrivateFunctionCurrentlyAdmitted:ordinaryFunctionAdmission.admitted,removalGate},
 upgrade:{base,recordCount:owner.pendingTransactionCreationRecordCount,pool:owner.maxPendingTransactionCreationBytes,total:totalPendingBytes(owner),free:owner.maxPendingTransactionCreationBytes-totalPendingBytes(owner),eachRecordAloneWithUpgradeFits:base+upgradeBytes<=owner.maxPendingTransactionCreationBytes,rotation,retainedAfter:totalPendingBytes(owner)},
 bomDecoder:{ordinary: fatalUtf8.decode(Buffer.from('\ufeff')),preserving:new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(Buffer.from('\ufeff'))}
};
console.log(JSON.stringify(output,null,2));
