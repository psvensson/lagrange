const FIELD = Object.freeze({
  TYPE: 'type',
  NODE_ID: 'nodeId',
  NODE_ADDRESS: 'nodeAddress',
  STATE: 'state',
  CAPABILITIES: 'capabilities',
  HEARTBEAT_AT: 'heartbeatAt',
  HEARTBEAT_ONLY: 'heartbeatOnly',
  BOOT_INCARNATION: 'bootIncarnation',
  NODE_STATE_PUBLICATION_MODE: 'nodeStatePublicationMode',
  READY_LEASE_EXPIRES_AT: 'readyLeaseExpiresAt',
  NODE_ROW: 'nodeRow',
  OPERATION_ID: 'operationId',
  OPERATION_TYPE: 'operationType',
  OPERATION_ROW: 'operationRow',
  HANDOFF_MODE: 'handoffMode',
  PARTITION_ID: 'partitionId',
  REPLICA_ID: 'replicaId',
  REPLICA_IDS: 'replicaIds',
  PEER_ADDRESSES: 'peerAddresses',
  BOOTSTRAP_TABLE_METADATA: 'bootstrapTableMetadata',
  BOOTSTRAP_PARTITION_METADATA: 'bootstrapPartitionMetadata',
  // The committed-membership stamp a new replica is created from (owner
  // decision O1): the group's committed configuration as its leader answered
  // it, or a genesis founding set. Carried unchanged from creation to the
  // target's port.
  BOOTSTRAP_MEMBERSHIP: 'bootstrapMembership',
  TARGET_NODE_ID: 'targetNodeId',
  FORWARDED_BY: 'forwardedBy',
  SOURCE_NODE_ID: 'sourceNodeId',
  ENTITY_TYPE: 'entityType',
  ENTITY_ID: 'entityId',
  REASON: 'reason',
});

export {FIELD};
