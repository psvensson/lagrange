import {CDC_OPERATION, NUM} from '../constants/index.js';

const CDC_SUBSYSTEM = Object.freeze({
  INTEGRATION: 'cdc-integration',
});

const CDC_EVENT = Object.freeze({
  INSERT: 'insert',
  UPDATE: 'update',
  DELETE: 'delete',
  UPSERT: 'upsert',
  ERROR: 'error',
  READ_MODEL_DIVERGENCE: 'readModelDivergence',
  EPOCH_CHANGE: 'epochChange',
  NODE_STATE_CHANGE: 'nodeStateChange',
  NODE_JOINED: 'nodeJoined',
});

const CDC_CONFIG_KEY = Object.freeze({
  RETRY_MAX_ATTEMPTS: 'cdc.retryMaxAttempts',
  RETRY_DELAY_MS: 'cdc.retryDelayMs',
  CACHE_WAIT_TIMEOUT_MS: 'cdc.cacheWaitTimeoutMs',
});

const CDC_DEFAULTS = Object.freeze({
  // Leader election / system-cache warmup during bootstrap and node join can take a few seconds.
  // Use retries + backoff to make control-plane writes eventually succeed.
  RETRY_MAX_ATTEMPTS: 6,
  RETRY_DELAY_MS: 100,
  // Wait briefly for CDC to apply to the cache after successful writes.
  // ends-on: the routed write appears in the local cache
  CACHE_WAIT_TIMEOUT_MS: 1000,
});

// Config key for the current assignment epoch persisted in the config table.
const CDC_EPOCH_CONFIG_KEY = 'current_epoch';

const CDC_SOURCE = Object.freeze({
  CDC: 'cdc',
});

const CDC_SKIP_REASON = Object.freeze({
  SELF: 'self',
  ALREADY_CONNECTED: 'already_connected',
});

const CDC_RETRY = Object.freeze({
  MIN_ATTEMPTS: 1,
  MIN_DELAY_MS: 0,
  BACKOFF_BASE: 2,
  MAX_EXPONENT: NUM.SIX,
  MAX_DELAY_MS: 2000,
});

const CDC_SQL = Object.freeze({
  PARAM_PLACEHOLDER: '?',
  COMMA_SPACE: ', ',
  WHERE_AND: ' AND ',
  ASSIGNMENT_PLACEHOLDER: ' = ?',
  IS_NULL_PREDICATE: ' IS NULL',
});

const CDC_SESSION = Object.freeze({
  SYSTEM_WRITE_PREFIX: 'cdc-system-write',
});

const CDC_OPERATION_LABEL = Object.freeze({
  INSERT: CDC_OPERATION.INSERT,
  UPDATE_WHERE: 'UPDATE whereClause',
  UPDATE_DATA: 'UPDATE data',
  DELETE_WHERE: 'DELETE whereClause',
  UPSERT: CDC_OPERATION.UPSERT,
});

const CDC_PRIMARY_KEY = Object.freeze({
  FALLBACK: 'id',
});

const CDC_STATS_DEFAULT = Object.freeze({
  inserts: 0,
  updates: 0,
  deletes: 0,
  failures: 0,
  epochChanges: 0,
  nodeStateChanges: 0,
});

const CDC_LOG_MSG = Object.freeze({
  INITIALIZED: 'CDC integration service initialized',
  SQL_ENGINE_SET: 'SQL query engine set for CDC integration',
  TRANSIENT_SQL_RETRY: 'Transient CDC SQL error, retrying',
  TRANSIENT_SQL_EXCEPTION_RETRY: 'Transient CDC SQL exception, retrying',
  INSERTING_ROW: 'Inserting system table row via SQL',
  INSERTED_ROW: 'System table row inserted',
  INSERT_FAILED: 'Failed to insert system table row',
  UPDATING_ROW: 'Updating system table row via SQL',
  UPDATED_ROW: 'System table row updated',
  UPDATE_FAILED: 'Failed to update system table row',
  DELETING_ROW: 'Deleting system table row via SQL',
  DELETED_ROW: 'System table row deleted',
  DELETE_FAILED: 'Failed to delete system table row',
  UPSERTING_ROW: 'Upserting system table row via SQL',
  UPSERTED_ROW: 'System table row upserted',
  UPSERT_FAILED: 'Failed to upsert system table row',
  EPOCH_MANAGER_SET: 'Epoch manager set for CDC integration',
  EPOCH_MANAGER_MISSING: 'Epoch change CDC received but no epoch manager set',
  EPOCH_PARSE_FAILED: 'Failed to parse epoch data from CDC event',
  EPOCH_CREATE_FAILED: 'Failed to create AssignmentEpoch from CDC data',
  EPOCH_APPLIED: 'Epoch change applied from CDC',
  EPOCH_SKIPPED: 'Epoch change not applied (stale or equal epoch)',
  REBALANCER_SET: 'Rebalancer set for CDC integration',
  NODE_STATE_UNCHANGED: 'Node state unchanged, skipping',
  NODE_STATE_DETECTED: 'Node state change detected via CDC',
  REBALANCER_NOTIFIED: 'Rebalancer notified of node state change',
  REBALANCER_NOTIFY_FAILED: 'Failed to notify rebalancer of node state change',
  REBALANCER_NOT_SET: 'No rebalancer set, skipping rebalancer notification',
  MESSAGE_ROUTER_SET: 'Message router set for CDC mesh connectivity',
  METRICS_LOG_FAILED: 'CDC metrics logging failed',
  BOOTSTRAP_MODE_REQUIRES_PARTITION_MAP:
    'Bootstrap mode requires a Map of local partition services',
  BOOTSTRAP_MODE_ENABLED:
    'Bootstrap mode enabled - writes go directly to local partitions',
  BOOTSTRAP_MODE_DISABLED:
    'Bootstrap mode disabled - writes will route through SQL engine',
  BOOTSTRAP_MODE_REQUIRED_FOR_DIRECT_SQL:
    'executeSQLDirectToLocalPartition can only be called in bootstrap mode',
  BOOTSTRAP_RAFT_WRITE_LANE_FELL_BACK:
    'Bootstrap raft write lane unavailable - falling back to direct ' +
    'per-replica write',
  NEW_NODE_DETECTED: 'New node detected via CDC, establishing connection',
  NEW_NODE_CONNECTED: 'Connected to new node via CDC event',
  NEW_NODE_CONNECT_FAILED: 'Failed to connect to new node via CDC event',
  NEW_NODE_SKIP_SELF: 'Skipping connection to self node',
  NEW_NODE_SKIP_CONNECTED: 'Skipping already connected node',
  NEW_NODE_MISSING_ADDRESS: 'New node missing address, cannot connect',
  OVERLAY_RESEED_ON_TABLE_NOT_FOUND:
    'Re-seeding bootstrap routing overlay after table-not-found',
  OVERLAY_RESEED_RETRY_RESULT:
    'Bootstrap overlay re-seed retry completed',
});

const CDC_ERROR_MSG = Object.freeze({
  INVALID_TABLE_PREFIX: 'Invalid system table name: ',
  VALID_TABLES_PREFIX: 'Valid tables are: ',
  DATA_REQUIRED_SUFFIX: ' requires data object',
  SCHEMA_MISSING_PREFIX: 'Schema not found for system table: ',
  INSERT_VALID_COLUMNS_PREFIX: 'INSERT requires data with valid columns for ',
  UPDATE_VALID_COLUMNS_PREFIX: 'UPDATE requires data with valid columns for ',
  UPDATE_PRIMARY_KEY_PREFIX: 'UPDATE requires primary key (',
  UPDATE_PRIMARY_KEY_SUFFIX: ') in whereClause',
  UPDATE_PRIMARY_KEY_REHOME_PREFIX: 'UPDATE data must not re-home primary key (',
  UPDATE_PRIMARY_KEY_REHOME_SUFFIX:
    '): a key-changing system-table UPDATE cannot route; DELETE and ' +
    're-INSERT instead',
  DELETE_PRIMARY_KEY_PREFIX: 'DELETE requires primary key (',
  DELETE_PRIMARY_KEY_SUFFIX: ') in whereClause',
  UPSERT_PRIMARY_KEY_PREFIX: 'UPSERT requires primary key (',
  UPSERT_PRIMARY_KEY_SUFFIX: ') in data',
  UPSERT_VALID_COLUMNS_PREFIX: 'UPSERT requires data with valid columns for ',
  CDC_ENGINE_MISSING_PREFIX: 'CDCIntegrationService not properly initialized: ',
  CDC_ENGINE_MISSING_DETAIL: 'sqlQueryEngine not provided',
  CDC_SHUT_DOWN:
    'CDCIntegrationService shut down before this write was confirmed: its ' +
    'outcome is not known here (see its cause), and no retry through the ' +
    'service can succeed',
  CDC_SHUT_DOWN_NOT_ROUTED:
    'CDCIntegrationService is shut down: this write was not routed and was ' +
    'not applied, and no retry through the service can succeed',
  INSERT_FAILED: 'Insert failed',
  UPDATE_FAILED: 'Update failed',
  DELETE_FAILED: 'Delete failed',
  UPSERT_FAILED: 'Upsert failed',
  CACHE_WAIT_TIMEOUT: (tableName, key, timeoutMs) =>
    `Cache update not observed for ${tableName}:${key} within ${timeoutMs}ms`,
  INVALID_EVENT: 'Invalid CDC event: event must be an object',
  NOT_EPOCH_CHANGE_PREFIX: 'Not an epoch change event: config_key is ',
  EPOCH_MANAGER_REQUIRED: 'epochManager is required',
  EPOCH_MANAGER_NOT_SET: 'Epoch manager not set',
  EPOCH_DATA_INVALID: 'config_value must be a string or object',
  PARSE_EPOCH_PREFIX: 'Failed to parse epoch data: ',
  CREATE_EPOCH_PREFIX: 'Failed to create epoch: ',
  EPOCH_NOT_APPLIED: 'Epoch not applied (stale or equal to current)',
  REBALANCER_REQUIRED: 'rebalancer is required',
  NOT_NODES_TABLE_PREFIX: 'Not a nodes table event: tableName is ',
  NODE_ID_MISSING: 'Missing node_id in CDC event data',
  NODE_STATUS_MISSING: 'Missing status in CDC event data',
  MESSAGE_ROUTER_REQUIRED: 'messageRouter is required',
  NOT_INSERT_OPERATION: 'Not an INSERT operation',
  MESSAGE_ROUTER_NOT_SET: 'Message router not set',
  BOOTSTRAP_REENTRY_FORBIDDEN:
    'Cannot re-enable bootstrap mode after it has been cleared',
});

// The service's typed answers. SHUT_DOWN is the terminal lifecycle answer:
// once the service is marked shutting down, a write it routes or waits on
// answers SHUT_DOWN (its last failure, if any, as the cause) instead of any
// retryable answer, since no engine will arrive. An engine missing before the
// service is wired stays the retryable startup answer.
const CDC_ERROR_CODE = Object.freeze({
  SHUT_DOWN: 'CDC_INTEGRATION_SERVICE_SHUT_DOWN',
});

// What the SHUT_DOWN answer knows of its write: never routed (a write that
// arrived after shutdown: definitely not applied), or not confirmed (in
// flight when shutdown came: its cause says what the write last answered).
const CDC_SHUT_DOWN_WRITE_OUTCOME = Object.freeze({
  NOT_ROUTED: 'not_routed',
  NOT_CONFIRMED: 'not_confirmed',
});

// The stages the owner's terminal gate (refuseIfTerminal) names: each is one
// operation class's choke point, where CDC-owned work is issued.
const CDC_TERMINAL_STAGE = Object.freeze({
  // (a) issuing an authoritative read, at every stage of the read flow.
  LOCAL_READ: 'authoritative_local_read',
  OWNER_RPC_READ: 'authoritative_owner_rpc_read',
  OVERLAY_RESEED: 'authoritative_read_overlay_reseed',
  SQL_FALLBACK_READ: 'authoritative_sql_fallback_read',
  // (b) applying an authoritative cache repair or sweep.
  CACHE_REPAIR: 'authoritative_cache_repair',
  CACHE_SWEEP: 'authoritative_cache_sweep',
  // (c) submitting a routed mutation to a partition or an engine.
  LOCAL_LEADER_WRITE: 'routed_local_leader_write',
  ENGINE_WRITE: 'routed_engine_write',
  BOOTSTRAP_DIRECT: 'routed_bootstrap_direct',
});

export {
  CDC_CONFIG_KEY,
  CDC_TERMINAL_STAGE,
  CDC_DEFAULTS,
  CDC_EPOCH_CONFIG_KEY,
  CDC_EVENT,
  CDC_ERROR_CODE,
  CDC_ERROR_MSG,
  CDC_LOG_MSG,
  CDC_OPERATION_LABEL,
  CDC_PRIMARY_KEY,
  CDC_RETRY,
  CDC_SESSION,
  CDC_SHUT_DOWN_WRITE_OUTCOME,
  CDC_SKIP_REASON,
  CDC_SOURCE,
  CDC_SQL,
  CDC_STATS_DEFAULT,
  CDC_SUBSYSTEM,
};
