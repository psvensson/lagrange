import {COLUMN, STRING} from '../constants/index.js';
import {CONFIG_KEY} from './config-key-constants.js';
import {LATENCY_PROPAGATION_MODE} from './config-latency-constants.js';
import {CONFIG_SCHEMA} from './config-schema-constants.js';
import {
  CONFIG_DEFINITIONS,
  CONFIG_VALUE_TYPE,
  DEFAULT_CONFIG,
} from './config-definitions.js';
import {LISTENER_PORT_ENV} from './listener-port-model.js';

const CONFIG_CATEGORY = Object.freeze({
  RAFT: 'raft',
  MESSAGE_GROUP: 'messageGroup',
  PARTITION: 'partition',
  LOGGING: 'logging',
  NODE: 'node',
  CONTROL_PLANE: 'controlPlane',
  LATENCY: 'latency',
});

const CONFIG_SUBSYSTEM = Object.freeze({
  DYNAMIC_CONFIG: 'dynamic-config',
});

const CONFIG_EVENT = Object.freeze({
  CHANGE: 'change',
  DELETE: 'delete',
});


const CONFIG_SEED_SOURCE = Object.freeze({
  SYSTEM: 'system',
});

const CONFIG_SEPARATOR = Object.freeze({
  COMMA_SPACE: ', ',
  DOT: '.',
  UNDERSCORE: '_',
  COLON_SPACE: ': ',
});

const CONFIG_ENV = Object.freeze({
  UPDATED_BY_SYSTEM: 'system',
  UPDATED_BY_UNKNOWN: 'unknown',
  TRUE: 'true',
  FALSE: 'false',
  ONE: '1',
});

const CONFIG_ENV_REGEX = Object.freeze({
  DOT: /\./g,
  CAMEL_CASE: /([a-z])([A-Z])/g,
});

const CONFIG_ENV_REPLACE = Object.freeze({
  CAMEL_CASE: '$1_$2',
});

const CONFIG_KEY_FRAGMENT = Object.freeze({
  THRESHOLD: 'Threshold',
});

const CONFIG_LOG_LEVELS = Object.freeze({
  VALUES: Object.freeze(['trace', 'debug', 'info', 'warn', 'error', 'fatal']),
});

const CONFIG_LOG_MSG = Object.freeze({
  INITIALIZED: 'Dynamic configuration service initialized',
  SEEDING_COMPLETE: 'Configuration seeding complete',
  UPDATED: 'Configuration updated',
  WATCHER_REGISTERED: 'Configuration watcher registered',
  WATCHER_CALLBACK_FAILED: 'Configuration watcher callback failed',
});

const CONFIG_ERROR_MSG = Object.freeze({
  SYSTEM_TABLE_CACHE_REQUIRED: 'DynamicConfigService requires systemTableCache',
  CDC_UNAVAILABLE: 'CDC integration service not available',
  INVALID_VALUE_PREFIX: 'Invalid configuration value: ',
  EXPECTED_STRING_PREFIX: 'Expected string, got ',
  EXPECTED_NUMBER_PREFIX: 'Expected number, got ',
  EXPECTED_BOOLEAN_PREFIX: 'Expected boolean, got ',
  EXPECTED_OBJECT_PREFIX: 'Expected object, got ',
  NON_NEGATIVE_REQUIRED: 'Value must be non-negative',
  LOG_LEVEL_INVALID_PREFIX: 'Invalid log level. Must be one of: ',
  VALIDATION_FAILED_PREFIX: 'Configuration validation failed: ',
  INVALID_NUMBER_PREFIX: 'Invalid number value for ',
  DEPRECATED_ENV_PREFIX: 'Deprecated environment variable ',
  DEPRECATED_ENV_INFIX: ' — use ',
});

const CONFIG_STATS_DEFAULT = Object.freeze({
  reads: 0,
  writes: 0,
  watcherNotifications: 0,
});

const CONFIG_TABLE_COLUMN = Object.freeze({
  KEY: COLUMN.CONFIG_KEY,
  VALUE: COLUMN.CONFIG_VALUE,
  VALUE_TYPE: COLUMN.VALUE_TYPE,
  REQUIRES_RESTART: COLUMN.REQUIRES_RESTART,
  DESCRIPTION: COLUMN.DESCRIPTION,
  DEFAULT_VALUE: COLUMN.DEFAULT_VALUE,
  UPDATED_BY: COLUMN.UPDATED_BY,
  UPDATED_AT: COLUMN.UPDATED_AT,
  CREATED_AT: COLUMN.CREATED_AT,
});

const CONFIG_VALUE_DEFAULT = Object.freeze({
  EMPTY_OBJECT: Object.freeze({}),
});

/**
 * Default configuration values.
 */

/**
 * Environment variable mappings.
 * Maps environment variable names to configuration paths.
 */
const ENV_MAPPINGS = {
  NODE_ID: CONFIG_KEY.NODE_ID,
  NODE_ADDRESS: CONFIG_KEY.NODE_ADDRESS,
  NODE_ADVERTISED_WS_ADDRESS: CONFIG_KEY.NODE_ADVERTISED_WS_ADDRESS,
  [LISTENER_PORT_ENV.REST_API]: CONFIG_KEY.NODE_REST_API_PORT,
  [LISTENER_PORT_ENV.ADMIN_WEBSOCKET]: CONFIG_KEY.ADMIN_WEBSOCKET_PORT,
  [LISTENER_PORT_ENV.TRANSPORT_WEBSOCKET]: CONFIG_KEY.NODE_WS_PORT,
  LOG_LEVEL: CONFIG_KEY.LOGGING_LEVEL,
  LOG_PRETTY_PRINT: CONFIG_KEY.LOGGING_PRETTY_PRINT,
  LOG_PERSIST_METRICS: CONFIG_KEY.LOGGING_PERSIST_METRICS_LOGS,
  LOG_METRICS_DEFAULT_RESOLUTION_MS:
    CONFIG_KEY.LOGGING_METRICS_DEFAULT_RESOLUTION_MS,
  LOG_METRICS_DETAILED_WINDOW_ENABLED:
    CONFIG_KEY.LOGGING_METRICS_DETAILED_WINDOW_ENABLED,
  LOG_METRICS_DETAILED_WINDOW_TTL_MS:
    CONFIG_KEY.LOGGING_METRICS_DETAILED_WINDOW_TTL_MS,
  SEED_NODE_ADDRESS: CONFIG_KEY.NODE_SEED_NODE_ADDRESS,
  LATENCY_GROUP_ID: CONFIG_KEY.LATENCY_PINNED_GROUP_ID,
  TRANSPORT_WS_HOST: 'transport.wsHost',
  ADMIN_WS_HOST: CONFIG_KEY.ADMIN_WEBSOCKET_HOST,
  ADMIN_ALLOW_INSECURE_EXTERNAL_BIND:
    CONFIG_KEY.ADMIN_ALLOW_INSECURE_EXTERNAL_BIND,
  RAFT_ELECTION_TIMEOUT_MIN_MS: CONFIG_KEY.RAFT_ELECTION_TIMEOUT_MIN_MS,
  RAFT_ELECTION_TIMEOUT_MAX_MS: CONFIG_KEY.RAFT_ELECTION_TIMEOUT_MAX_MS,
  RAFT_HEARTBEAT_INTERVAL_MS: CONFIG_KEY.RAFT_HEARTBEAT_INTERVAL_MS,
  RAFT_TICK_INTERVAL_MS: CONFIG_KEY.RAFT_TICK_INTERVAL_MS,
  // Env-configurable snapshot cadence entry threshold (the leader creates and
  // compacts a checkpoint once this many committed entries sit above the
  // covered index). LAGRANGE_-prefixed so the distributed harness forwards it
  // into node containers for the live rebuild certification.
  LAGRANGE_RAFT_SNAPSHOT_THRESHOLD: CONFIG_KEY.RAFT_SNAPSHOT_THRESHOLD,
  // Per-message transport ACK timeout. LAGRANGE_-prefixed so the distributed
  // harness forwards it into node containers; multi-host (cross-VM) runs raise
  // it above the local-bridge 5s default so WAN latency + a saturated seed
  // does not trigger spurious ACK-timeout connection quarantines (CL-007).
  LAGRANGE_TRANSPORT_MESSAGE_TIMEOUT_MS: 'transport.messageTimeoutMs',
  REBALANCER_PERIODIC_CHECK_INTERVAL_MS: CONFIG_KEY.REBALANCER_PERIODIC_CHECK_INTERVAL_MS,
  REBALANCER_MAX_CONCURRENT_MOVES: CONFIG_KEY.REBALANCER_MAX_CONCURRENT_MOVES,
  REBALANCER_SYSTEM_PARTITION_START_DELAY_MS:
    CONFIG_KEY.REBALANCER_SYSTEM_PARTITION_START_DELAY_MS,
  REBALANCER_USER_PARTITION_START_DELAY_MS:
    CONFIG_KEY.REBALANCER_USER_PARTITION_START_DELAY_MS,
  MESSAGE_GROUP_REPLICA_COUNT: CONFIG_KEY.MESSAGE_GROUP_REPLICA_COUNT,
  PARTITION_DEFAULT_REPLICA_COUNT: CONFIG_KEY.PARTITION_DEFAULT_REPLICA_COUNT,
  PARTITION_SPLIT_THRESHOLD_BYTES: CONFIG_KEY.PARTITION_SPLIT_THRESHOLD_BYTES,
  PARTITION_SPLIT_THRESHOLD_QPM: CONFIG_KEY.PARTITION_SPLIT_THRESHOLD_QPM,
  PARTITION_MERGE_THRESHOLD_BYTES: CONFIG_KEY.PARTITION_MERGE_THRESHOLD_BYTES,
  PARTITION_MERGE_THRESHOLD_QPM: CONFIG_KEY.PARTITION_MERGE_THRESHOLD_QPM,
  PARTITION_EVALUATION_INTERVAL_MS:
    CONFIG_KEY.PARTITION_EVALUATION_INTERVAL_MS,
  PARTITION_TRAFFIC_WINDOW_MS: CONFIG_KEY.PARTITION_TRAFFIC_WINDOW_MS,
  PARTITION_MERGE_MINIMUM_AGE_MS: CONFIG_KEY.PARTITION_MERGE_MINIMUM_AGE_MS,
  WORKER_MIN_THREADS: CONFIG_KEY.WORKER_MIN_THREADS,
  WORKER_MAX_THREADS: CONFIG_KEY.WORKER_MAX_THREADS,
  DATA_DIR: CONFIG_KEY.STORAGE_DATA_DIR,
};

/**
 * Deprecated environment variable names, mapped to their canonical
 * replacements (renamed 2026-07 to give every listener one prefix and the
 * short WS form: transport = TRANSPORT_WS_HOST/TRANSPORT_WS_PORT, admin =
 * ADMIN_WS_HOST/ADMIN_WS_PORT). A legacy name is honored only when its
 * canonical name is unset, and its use logs a startup deprecation warning.
 */
const LEGACY_ENV_ALIASES = Object.freeze({
  ADMIN_WEBSOCKET_HOST: 'ADMIN_WS_HOST',
  ADMIN_WEBSOCKET_PORT: 'ADMIN_WS_PORT',
  NODE_WS_PORT: 'TRANSPORT_WS_PORT',
});


const CONFIG_SQL = Object.freeze({
  SELECT_ALL: 'SELECT * FROM config',
  SELECT_BY_KEY: 'SELECT * FROM config WHERE config_key = ?',
});

export {
  CONFIG_CATEGORY,
  CONFIG_DEFINITIONS,
  CONFIG_ENV,
  CONFIG_ENV_REGEX,
  CONFIG_ENV_REPLACE,
  CONFIG_ERROR_MSG,
  CONFIG_EVENT,
  CONFIG_KEY,
  CONFIG_KEY_FRAGMENT,
  LATENCY_PROPAGATION_MODE,
  CONFIG_LOG_LEVELS,
  CONFIG_LOG_MSG,
  CONFIG_SCHEMA,
  CONFIG_SEED_SOURCE,
  CONFIG_SEPARATOR,
  CONFIG_SQL,
  CONFIG_STATS_DEFAULT,
  CONFIG_SUBSYSTEM,
  CONFIG_TABLE_COLUMN,
  CONFIG_VALUE_DEFAULT,
  CONFIG_VALUE_TYPE,
  DEFAULT_CONFIG,
  ENV_MAPPINGS,
  LEGACY_ENV_ALIASES,
  STRING,
};
