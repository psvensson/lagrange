/**
 * Seed Partitions Phase — handles Phase 3 of seed bootstrap:
 * creating system table partitions with deferred elections,
 * partition leadership wait, epoch manager initialization,
 * and partition replica progress reporting.
 *
 * Extracted from BootstrapService to keep the orchestrator thin.
 * The class receives required dependencies via constructor injection.
 */

import {PartitionService} from '../../partition/partition-service.js';
import {genesisStamp} from '../../raft/raft-committed-membership-stamp.js';
import {seedReplicaIdentityExisted} from
  '../seed-startup-storage-admission.js';
import {assertCritical} from '../../utils/assert.js';
import {AssignmentEpochManager} from '../../rebalancer/assignment-epoch-manager.js';
import {AssignmentEpoch} from '../../rebalancer/assignment-epoch.js';
import {ReplicaStatus} from '../../rebalancer/replica-status.js';
import {EPOCH_CONFIG_KEY} from '../../cdc/cdc-integration-service.js';
import {StartupRecoveryCoordinator} from '../startup-recovery-coordinator.js';
import {classifySystemPartition} from
  '../system-partition-classification.js';
import {resolveCanonicalLeaderService} from
  '../../cache/leader-readiness-gate.js';
import {
  BOOTSTRAP_PHASE,
  BOOTSTRAP_DEFAULT,
  BOOTSTRAP_ERROR,
  BOOTSTRAP_LOG_MSG,
  BOOTSTRAP_PARTITION_LEADERSHIP_DEFAULT,
  BOOTSTRAP_UNIFIED_RECONCILE,
} from '../bootstrap-constants.js';
import {
  SYSTEM_TABLE_NAME,
  SYSTEM_TABLE_SCHEMAS,
  INITIAL_PARTITION_IDS,
  getInitialReplicaIds,
  INITIAL_MESSAGE_GROUP_ID,
  INITIAL_MESSAGE_GROUP_REPLICA_IDS,
} from '../system-table-schemas-constants.js';
import {assignSeedPartitionReplicaProgressMethods} from
  './seed-partition-replica-progress.js';
import {
  ADDRESS,
  COLUMN,
  ENTITY_TYPE,
  SERVICE_DESCRIPTOR_FIELD,
  SERVICE_LIFECYCLE_STATE,
  SERVICE_TYPE,
  STRING,
  UNIFIED_SERVICE_TYPE,
  isPartitionCleanupServiceRow,
} from '../../constants/index.js';
import {resolveHostedNodeClock, resolveHostedReplicaAuthorities} from
  '../shared/hosted-replica-authorities.js';

import {reportWaitBoundSpent} from '../../logging/wait-bound-spent.js';

const LOCAL_STR_STRING = 'string';
const SEED_PARTITION_LEADERSHIP_WAIT = Object.freeze({
  wait: 'leadershipWaitTimeoutMs',
  awaited: 'a live leader for every seed system-table partition',
});
const CLEANUP_IN_PROGRESS_CODE = 'CLEANUP_IN_PROGRESS';
const CREATE_OWNER_DEFERRED_CODE = 'CREATE_OWNER_DEFERRED';
const RESTORABLE_SEED_PARTITION_STATUSES = new Set([
  ReplicaStatus.PENDING,
  ReplicaStatus.CREATING,
  ReplicaStatus.SYNCING,
  ReplicaStatus.ACTIVE,
]);

function isRestorableSeedPartitionRow(row, options, nodeId) {
  const expected = {
    service_type: SERVICE_TYPE.PARTITION,
    partition_id: options.partitionId,
    node_id: nodeId,
  };
  return Object.entries(expected).every(([field, value]) =>
    row?.[field] === value) &&
    typeof row?.status === LOCAL_STR_STRING &&
    RESTORABLE_SEED_PARTITION_STATUSES.has(row.status.toLowerCase());
}

function assertBootstrapPartitionStorageAdmission(options, admission, nodeId) {
  if (admission?.empty === true) return;
  const row = admission?.rows?.find?.(
    (candidate) => candidate?.service_id === options.replicaId,
  );
  if (!isRestorableSeedPartitionRow(row, options, nodeId)) {
    const error = new Error(
      `Seed partition storage admission deferred for ${options.replicaId}`,
    );
    error.code = isPartitionCleanupServiceRow(row) ?
      CLEANUP_IN_PROGRESS_CODE : CREATE_OWNER_DEFERRED_CODE;
    error.deferRetry = true;
    throw error;
  }
}

/**
 * Handles the partitions phase of seed bootstrap.
 */
class SeedPartitionsPhase {
  /**
   * @param {Object} options
   * @param {Object} options.delegates - Callbacks into the bootstrap
   *   service for accessing mutable state.
   */
  constructor(options = {}) {
    this.delegates = options.delegates || {};
    this.satisfiedPartitionLeadershipSetKey = null;
  }

  /**
   * Phase 3: Partition creation for system tables.
   * Elections are deferred until ALL partitions are created.
   * @return {Promise<void>}
   */
  async phasePartitions() {
    const d = this.delegates;
    const logger = d.getLogger();
    const config = d.getConfig();
    const replicaStaggerDelayMs = config.replicaStaggerDelayMs;
    let queuedPartitionReplicaCount = 0;
    d.resetPartitionReplicas();

    for (const schema of SYSTEM_TABLE_SCHEMAS) {
      const tableName = schema.tableName;
      const partitionId = INITIAL_PARTITION_IDS[tableName];
      // No `|| []` fallback: a system table with no declared replica set is
      // a broken bootstrap, and substituting an empty list would seed zero
      // replicas silently instead of failing where it always failed.
      const replicaIds = getInitialReplicaIds(tableName);

      logger.debug(BOOTSTRAP_LOG_MSG.CREATING_SYSTEM_PARTITION, {
        tableName,
        partitionId,
        replicaCount: replicaIds.length,
        nodeId: d.getNodeId(),
      });

      const nodeId = d.getNodeId();
      const peerAddresses = replicaIds.map((replicaId) =>
        `${nodeId}${ADDRESS.SEPARATOR}` +
        `${ENTITY_TYPE.PARTITION}${ADDRESS.SEPARATOR}${replicaId}`,
      );
      for (let index = 0; index < replicaIds.length; index++) {
        const replicaId = replicaIds[index];
        const dbPath = d.resolvePartitionDbPath(
          partitionId, replicaId,
        );

        d.queueBootstrapServiceReplica(
          d.createBootstrapServiceDescriptor(
            UNIFIED_SERVICE_TYPE.PARTITION,
            replicaId,
          ),
          {
            serviceType: UNIFIED_SERVICE_TYPE.PARTITION,
            tableName,
            schema,
            partitionId,
            replicaId,
            replicaIds,
            replicaIndex: index,
            peerAddresses,
            dbPath,
            deferElection: true,
            createDelayMs: index > 0 ?
              index * replicaStaggerDelayMs :
              0,
          },
        );
        queuedPartitionReplicaCount++;
      }
    }

    const firstBatchReplicaCount = Math.min(
      queuedPartitionReplicaCount,
      config.maxConcurrentServiceActions,
    );
    logger.info(BOOTSTRAP_LOG_MSG.PARTITION_CREATION_BATCH_STARTING, {
      nodeId: d.getNodeId(),
      tableCount: SYSTEM_TABLE_SCHEMAS.length,
      queuedReplicaCount: queuedPartitionReplicaCount,
      firstBatchReplicaCount,
      maxConcurrentServiceActions:
        config.maxConcurrentServiceActions,
    });
    await d.triggerBootstrapReconciler(
      BOOTSTRAP_UNIFIED_RECONCILE.PARTITIONS_REASON,
    );
    d.setPartitionsCreated(SYSTEM_TABLE_SCHEMAS.length);

    await this.startDeferredBootstrapReplicaElections();

    const serviceReconciler = d.getServiceReconciler();
    if (serviceReconciler) {
      serviceReconciler.stop();
    }
    await this.initializeEpochManager();

    logger.debug(BOOTSTRAP_LOG_MSG.PARTITIONS_CREATED, {
      partitionsCreated: d.getPartitionsCreated(),
      nodeId: d.getNodeId(),
    });
  }

  /**
   * Unified lifecycle create hook for partition replicas.
   * @param {Object} context
   * @return {Promise<Object>}
   */
  async createBootstrapPartitionReplica(context) {
    const d = this.delegates;
    const logger = d.getLogger();
    const definition = context?.definition || {};
    const serviceId =
      definition[SERVICE_DESCRIPTOR_FIELD.SERVICE_ID];
    const options = d.resolveBootstrapReplicaOptions(
      serviceId,
      UNIFIED_SERVICE_TYPE.PARTITION,
    );
    const startupAdmission = d.getStartupServicesAdmission?.();
    assertBootstrapPartitionStorageAdmission(
      options,
      startupAdmission,
      d.getNodeId(),
    );

    if (d.getPartitionServices().has(options.replicaId)) {
      return {status: SERVICE_LIFECYCLE_STATE.CREATED};
    }

    if (options.createDelayMs > 0) {
      await d.sleep(options.createDelayMs);
    }

    const progress = this.startPartitionReplicaProgress({
      tableName: options.tableName,
      partitionId: options.partitionId,
      replicaId: options.replicaId,
      peerTotal: Math.max(
        0, options.replicaIds.length - 1,
      ),
    });

    try {
      const partition = new PartitionService({
        partitionId: options.partitionId,
        tableId: options.tableName,
        tableName: options.tableName,
        schema: options.schema,
        keyRange: {start: null, end: null},
        replicaId: options.replicaId,
        replicaIds: options.replicaIds,
        // Handler retirement goes through the replica lifecycle owner (N2).
        resolveHandlerRetirementLane: () =>
          d.getReplicaStateMachine?.() || null,
        // The seed founds each system partition from an explicit GENESIS
        // stamp of its founding list, validated by the port like every stamp
        // (verification V1a); a seed that holds a durable record restores
        // from it instead.
        bootstrapMembership: genesisStamp(options.replicaIds),
        // A founder whose durable services row this seed already holds
        // opened before: without its raft record it is refused
        // reseed-required, never re-founded empty (the open-time rule).
        identityExisted: seedReplicaIdentityExisted(
          startupAdmission, options.replicaId, d.getNodeId()),
        peerAddresses: options.peerAddresses,
        nodeId: d.getNodeId(),
        transport: d.getTransport(),
        dbPath: options.dbPath,
        messageGroupService: d.getBootstrapMessageGroupService(),
        messageRouter: d.getMessageRouter(),
        rebalanceCoordinator: d.getRebalanceCoordinator(),
        cdcIntegrationService: d.getCdcIntegrationService(),
        sqlQueryEngine: d.getCdcIntegrationService()?.sqlQueryEngine || null,
        deferElection: Boolean(options.deferElection),
        // The replica is hosted by this node: this node's clock, and this
        // node's runtime for its node-local cache.
        ...resolveHostedReplicaAuthorities(d),
        bootstrapReadinessState:
          typeof d.getBootstrapReadinessState === 'function' ?
            d.getBootstrapReadinessState() :
            null,
        suppressLifecycleLogs: true,
        onInitializationStage: (stageEvent) =>
          this.updatePartitionReplicaProgress(
            progress, stageEvent,
          ),
      });

      await partition.initialize();
      d.getPartitionServices().set(options.replicaId, partition);
      d.pushPartitionReplica(partition);
      d.incrementServicesCreated();
      this.finishPartitionReplicaProgress(progress);

      logger.debug(BOOTSTRAP_LOG_MSG.PARTITION_REPLICA_CREATED, {
        tableName: options.tableName,
        partitionId: options.partitionId,
        replicaId: options.replicaId,
        replicaIndex: options.replicaIndex,
        nodeId: d.getNodeId(),
      });
    } catch (error) {
      this.failPartitionReplicaProgress(progress, error);
      throw error;
    }

    return {status: SERVICE_LIFECYCLE_STATE.CREATED};
  }

  /**
   * Unified lifecycle start hook for partition replicas.
   * @param {Object} replicaHandle
   * @param {Object} _context
   * @return {Promise<Object>}
   */
  async startBootstrapPartitionReplica(replicaHandle, _context) {
    const d = this.delegates;
    const serviceId =
      replicaHandle[SERVICE_DESCRIPTOR_FIELD.SERVICE_ID] ||
      replicaHandle[SERVICE_DESCRIPTOR_FIELD.REPLICA_ID];
    const options = d.resolveBootstrapReplicaOptions(
      serviceId,
      UNIFIED_SERVICE_TYPE.PARTITION,
    );
    const partition =
      d.getPartitionServices().get(options.replicaId);

    assertCritical(
      partition,
      `Partition replica ${options.replicaId} missing at start`,
    );

    if (!options.deferElection) {
      partition.startElection();
    }

    return {
      status: SERVICE_LIFECYCLE_STATE.RUNNING,
      deferred: Boolean(options.deferElection),
    };
  }

  /**
   * Unified lifecycle stop hook for partition replicas.
   * @param {Object} replicaHandle
   * @param {Object} _context
   * @return {Promise<Object>}
   */
  async stopBootstrapPartitionReplica(replicaHandle, _context) {
    const d = this.delegates;
    const serviceId =
      replicaHandle[SERVICE_DESCRIPTOR_FIELD.SERVICE_ID] ||
      replicaHandle[SERVICE_DESCRIPTOR_FIELD.REPLICA_ID];
    const options = d.resolveBootstrapReplicaOptions(
      serviceId,
      UNIFIED_SERVICE_TYPE.PARTITION,
    );
    const partition =
      d.getPartitionServices().get(options.replicaId);
    if (!partition) {
      return {status: SERVICE_LIFECYCLE_STATE.STOPPED};
    }

    // The partition's shutdown retires its own exact transport handler
    // through the replica lifecycle owner (owner decision N2); a raw
    // by-address unregister here could remove a successor's handler.
    if (partition.shutdown) {
      await partition.shutdown();
    }

    d.getPartitionServices().delete(options.replicaId);
    d.filterPartitionReplicas(partition);

    return {status: SERVICE_LIFECYCLE_STATE.STOPPED};
  }

  /**
   * Start deferred elections for message groups then partitions.
   * @return {Promise<void>}
   */
  async startDeferredBootstrapReplicaElections() {
    const d = this.delegates;
    const logger = d.getLogger();
    const messageGroupReplicas = d.getMessageGroupReplicas();

    if (messageGroupReplicas &&
        messageGroupReplicas.length > 0) {
      logger.info(BOOTSTRAP_LOG_MSG.STARTING_MG_ELECTIONS, {
        totalReplicas: messageGroupReplicas.length,
        nodeId: d.getNodeId(),
      });

      for (const messageGroup of messageGroupReplicas) {
        messageGroup.startElection();
      }

      await d.waitForMessageGroupLeadership(
        INITIAL_MESSAGE_GROUP_ID,
        [...INITIAL_MESSAGE_GROUP_REPLICA_IDS],
      );

      // Shutdown may begin while message-group leadership is pending. Cleanup
      // then owns every unstarted replica; do not begin either partition
      // cohort after that lifecycle boundary.
      if (d.isShuttingDown()) {
        return;
      }

      logger.debug(
        BOOTSTRAP_LOG_MSG.MESSAGE_GROUP_LEADERSHIP_READY, {
          groupId: INITIAL_MESSAGE_GROUP_ID,
          nodeId: d.getNodeId(),
        });
    }

    const partitionReplicas = d.getPartitionReplicas();
    logger.info(BOOTSTRAP_LOG_MSG.STARTING_PARTITION_ELECTIONS, {
      totalReplicas: partitionReplicas.length,
      partitionsCreated: d.getPartitionsCreated(),
      nodeId: d.getNodeId(),
    });

    const registrationRequiredPartitionIds = new Set(
      d.getRegistrationRequiredLeaderPartitionIds(),
    );
    const registrationRequiredReplicas = [];
    const remainingReplicas = [];
    for (const partition of partitionReplicas) {
      const cohort = registrationRequiredPartitionIds.has(
        partition.partitionId,
      ) ? registrationRequiredReplicas : remainingReplicas;
      cohort.push(partition);
    }

    for (const partition of registrationRequiredReplicas) {
      partition.startElection();
    }

    try {
      await d.waitForPartitionLeadership({
        partitionIds: [...registrationRequiredPartitionIds],
      });
    } finally {
      // A failed dependency gate must not strand otherwise independent
      // partition groups. During shutdown, cleanup owns every unstarted
      // replica and this scheduler must not restart them.
      if (!d.isShuttingDown()) {
        for (const partition of remainingReplicas) {
          partition.startElection();
        }
      }
    }
  }

  /**
   * Wait for all system table partitions to establish leadership.
   * @return {Promise<void>}
   */
  async waitForPartitionLeadership(options = {}) {
    const d = this.delegates;
    const logger = d.getLogger();
    const config = d.getConfig();
    // A wait this node takes, on this node's clock.
    const now = resolveHostedNodeClock(d);
    const startTime = now();
    const configuredTimeoutMs =
      config.leadershipWaitTimeoutMs ||
      BOOTSTRAP_DEFAULT.leadershipWaitTimeoutMs;
    const timeoutMs = Number.isFinite(configuredTimeoutMs) &&
      configuredTimeoutMs > 0 ?
      Math.floor(configuredTimeoutMs) :
      BOOTSTRAP_PARTITION_LEADERSHIP_DEFAULT.TIMEOUT_CAP_MS;
    let delay = config.leadershipWaitInitialDelayMs ||
      BOOTSTRAP_PARTITION_LEADERSHIP_DEFAULT.INITIAL_DELAY_MS;
    const maxDelay =
      BOOTSTRAP_PARTITION_LEADERSHIP_DEFAULT.MAX_DELAY_MS;
    const backoffMultiplier =
      BOOTSTRAP_PARTITION_LEADERSHIP_DEFAULT.BACKOFF_MULTIPLIER;

    const requestedPartitionIds = Array.isArray(options.partitionIds) ?
      options.partitionIds :
      options.partitionIds instanceof Set ?
        [...options.partitionIds] :
        null;
    const partitionIds = requestedPartitionIds ?
      new Set(requestedPartitionIds.filter((partitionId) =>
        typeof partitionId === 'string' && partitionId.length > 0,
      )) :
      new Set();
    if (!requestedPartitionIds) {
      for (const partition of d.getPartitionServices().values()) {
        partitionIds.add(partition.partitionId);
      }
    }
    const partitionSetKey = this.buildPartitionLeadershipSetKey(partitionIds);

    logger.debug(BOOTSTRAP_LOG_MSG.WAITING_PARTITION_LEADERS, {
      partitionCount: partitionIds.size,
      timeoutMs,
      nodeId: d.getNodeId(),
    });

    if (this.satisfiedPartitionLeadershipSetKey === partitionSetKey) {
      logger.debug(BOOTSTRAP_LOG_MSG.PARTITION_LEADERS_IMMEDIATE, {
        partitionCount: partitionIds.size,
        elapsedMs: 0,
        cached: true,
      });
      return;
    }

    const leadersFound = this.checkPartitionLeaders(partitionIds);
    if (leadersFound.size === partitionIds.size) {
      this.satisfiedPartitionLeadershipSetKey = partitionSetKey;
      logger.debug(
        BOOTSTRAP_LOG_MSG.PARTITION_LEADERS_IMMEDIATE, {
          partitionCount: partitionIds.size,
          elapsedMs: 0,
        });
      return;
    }

    while (now() - startTime < timeoutMs) {
      await d.sleep(delay);
      delay = Math.min(delay * backoffMultiplier, maxDelay);

      const leaders = this.checkPartitionLeaders(partitionIds);
      if (leaders.size === partitionIds.size) {
        this.satisfiedPartitionLeadershipSetKey = partitionSetKey;
        logger.debug(BOOTSTRAP_LOG_MSG.PARTITION_LEADERS_FOUND, {
          partitionCount: partitionIds.size,
          elapsedMs: now() - startTime,
        });
        return;
      }
    }

    const leaders = this.checkPartitionLeaders(partitionIds);
    const missing = [...partitionIds].filter(
      (id) => !leaders.has(id),
    );
    reportWaitBoundSpent(logger, {
      ...SEED_PARTITION_LEADERSHIP_WAIT,
      boundMs: timeoutMs,
      elapsedMs: now() - startTime,
      lastObserved: {
        totalPartitions: partitionIds.size,
        leadersFound: leaders.size,
        missingLeaders: missing,
        lastDelayMs: delay,
      },
      scope: () => ({nodeId: d.getNodeId()}),
    });

    const error = new Error(
      BOOTSTRAP_ERROR.partitionLeadershipTimeout(
        missing, timeoutMs,
      ),
    );
    error.missingLeaders = missing;
    error.timeoutMs = timeoutMs;
    throw error;
  }

  /**
   * Check which partitions have leaders.
   * @param {Set<string>} partitionIds
   * @return {Set<string>}
   */
  checkPartitionLeaders(partitionIds) {
    const d = this.delegates;
    const leadersFound = new Set();
    for (const partition of d.getPartitionServices().values()) {
      if (!partitionIds.has(partition.partitionId)) {
        continue;
      }

      if (partition.isLeader ||
          this.canBypassCanonicalPartitionLeadership(
            partition.partitionId,
          ) ||
          this.canBypassLocalPriorityPartitionLeadership(
            partition.partitionId,
          )) {
        leadersFound.add(partition.partitionId);
      }
    }
    return leadersFound;
  }

  buildPartitionLeadershipSetKey(partitionIds) {
    return [...partitionIds].sort().join(STRING.COMMA);
  }

  canBypassLocalPriorityPartitionLeadership(partitionId) {
    const d = this.delegates;
    if (!this.hasInitializedLocalPartitionReplica(partitionId)) {
      return false;
    }
    if (this.canBypassDirectBootstrapPriorityPartitionLeadership(partitionId)) {
      return true;
    }

    const readinessState =
      typeof d.getBootstrapReadinessState === 'function' ?
        d.getBootstrapReadinessState() :
        null;
    if (!readinessState) {
      return false;
    }

    const startupRecoveryCoordinator =
      new StartupRecoveryCoordinator({readinessState});
    return startupRecoveryCoordinator.evaluate({
      partitionId,
      allowBootstrapInitPriorityBypass: true,
    })
      .shouldBypassLocalPriorityControlPlaneStartupReadiness === true;
  }

  canBypassDirectBootstrapPriorityPartitionLeadership(partitionId) {
    const d = this.delegates;
    if (!classifySystemPartition({partitionId}).priorityControlPlane) {
      return false;
    }
    const phase = typeof d.getPhase === 'function' ?
      d.getPhase() :
      null;
    if (phase !== BOOTSTRAP_PHASE.PARTITIONS &&
        phase !== BOOTSTRAP_PHASE.REGISTRATION) {
      return false;
    }
    const cdcIntegrationService =
      typeof d.getCdcIntegrationService === 'function' ?
        d.getCdcIntegrationService() :
        null;
    return cdcIntegrationService?.sqlQueryEngine == null;
  }

  canBypassCanonicalPartitionLeadership(partitionId) {
    if (!this.hasInitializedLocalPartitionReplica(partitionId)) {
      return false;
    }

    const d = this.delegates;
    const systemTableCache =
      typeof d.getSystemTableCacheRef === 'function' ?
        d.getSystemTableCacheRef() :
        typeof d.getSystemTableCacheSafe === 'function' ?
          d.getSystemTableCacheSafe() :
          null;
    if (!systemTableCache) {
      return false;
    }

    return Boolean(resolveCanonicalLeaderService(
      systemTableCache,
      SERVICE_TYPE.PARTITION,
      partitionId,
      {requireAddress: true},
    ).leaderService);
  }

  hasInitializedLocalPartitionReplica(partitionId) {
    const d = this.delegates;
    for (const partition of d.getPartitionServices().values()) {
      if (partition?.partitionId !== partitionId) {
        continue;
      }
      if (partition?.initialized === false) {
        continue;
      }
      return true;
    }

    return false;
  }

  /**
   * Initialize the AssignmentEpochManager with the initial epoch.
   * @return {Promise<void>}
   */
  async initializeEpochManager() {
    const d = this.delegates;
    const logger = d.getLogger();
    const initialAssignments = {};
    const partitionNodes = new Map();

    for (const [_replicaId, partition] of d.getPartitionServices()) {
      const partitionId = partition.partitionId;
      if (!partitionNodes.has(partitionId)) {
        partitionNodes.set(partitionId, []);
      }
      if (!partitionNodes.get(partitionId).includes(d.getNodeId())) {
        partitionNodes.get(partitionId).push(d.getNodeId());
      }
    }

    for (const [partitionId, nodes] of partitionNodes) {
      initialAssignments[partitionId] = nodes;
    }

    const epochManager = new AssignmentEpochManager({
      nodeId: d.getNodeId(),
      timestampProvider: () => new Date().toISOString(),
    });

    const persistedEpoch =
      await this.loadPersistedEpochFromLocalConfigPartition();
    if (persistedEpoch) {
      epochManager.initialize(persistedEpoch);
    } else {
      const initialEpoch = new AssignmentEpoch({
        epoch: 0,
        assignments: initialAssignments,
        timestamp: new Date().toISOString(),
        proposedBy: d.getNodeId(),
      });
      epochManager.initialize(initialEpoch);
    }

    d.setEpochManager(epochManager);

    logger.info(BOOTSTRAP_LOG_MSG.EPOCH_MANAGER_READY, {
      nodeId: d.getNodeId(),
      epoch: epochManager.getCurrentEpoch().epoch,
      partitionCount: Object.keys(initialAssignments).length,
      assignments: initialAssignments,
    });
  }

  /**
   * Load persisted assignment epoch from the local config partition.
   * @return {Promise<AssignmentEpoch|null>}
   */
  async loadPersistedEpochFromLocalConfigPartition() {
    const d = this.delegates;
    const logger = d.getLogger();
    const configReplicaIds =
      getInitialReplicaIds(SYSTEM_TABLE_NAME.CONFIG) || [];
    for (const replicaId of configReplicaIds) {
      const configPartition =
        d.getPartitionServices().get(replicaId);
      if (!configPartition) {
        continue;
      }

      try {
        const result = await configPartition.executeLocalQuery(
          'SELECT config_value FROM config WHERE config_key = ?',
          [EPOCH_CONFIG_KEY],
        );
        const hasRow = result?.success &&
          Array.isArray(result.rows) &&
          result.rows.length > 0;
        if (!hasRow) {
          continue;
        }

        const configValue =
          result.rows[0]?.[COLUMN.CONFIG_VALUE];
        if (typeof configValue !== LOCAL_STR_STRING ||
            configValue.length === 0) {
          continue;
        }

        return AssignmentEpoch.fromJSON(configValue);
      } catch (error) {
        logger.warn(BOOTSTRAP_LOG_MSG.CONFIG_CHECK_FAILED, {
          nodeId: d.getNodeId(),
          replicaId,
          error: error.message,
        });
      }
    }

    return null;
  }

  /**
   * Get the AssignmentEpochManager instance.
   * @return {AssignmentEpochManager|null}
   */
  getEpochManager() {
    return this.delegates.getEpochManager();
  }
}

assignSeedPartitionReplicaProgressMethods(SeedPartitionsPhase);

export {SeedPartitionsPhase};
