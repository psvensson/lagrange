import {HOST, NUM, STRING} from '../constants/index.js';
import {BOOTSTRAP_LOG_PREFIX, BOOTSTRAP_SUBSYSTEM} from './bootstrap-constants.js';

const BOOTSTRAP_API_SUBSYSTEM = BOOTSTRAP_SUBSYSTEM.API;

const BOOTSTRAP_API_ROUTE = Object.freeze({
  HEALTH: '/health',
  LIVEZ: '/livez',
  STARTUPZ: '/startupz',
  READYZ: '/readyz',
  BOOTSTRAP_READY: '/bootstrap/ready',
  BOOTSTRAP: '/bootstrap',
  REGISTER_SERVICE: '/register-service',
  CLUSTER_STATE: '/cluster/state',
});

const BOOTSTRAP_API_HEALTH_STATUS = 'healthy';
const BOOTSTRAP_API_HEALTH_STATUS_INITIALIZING = 'initializing';
const BOOTSTRAP_API_MESSAGE_GROUP_PREFIX = 'mg-';
const BOOTSTRAP_REQUEST_EXECUTION_BUDGET_MS = NUM.EIGHT * NUM.THOUSAND;

const BOOTSTRAP_API_DEFAULT = Object.freeze({
  MG_ID_LENGTH: NUM.EIGHT,
  WS_HOST: HOST.LOCALHOST,
  MAX_CONCURRENT_BOOTSTRAP_REQUESTS: 1,
  BOOTSTRAP_ADMISSION_RETRY_AFTER_MS: 1000,
  BOOTSTRAP_ADMISSION_LEASE_MS: NUM.FIVE_THOUSAND,
  BOOTSTRAP_REQUEST_EXECUTION_BUDGET_MS,
  MOVE_REPLICA_ASSIGNMENT_LEASE_MS: NUM.THIRTY_THOUSAND,
  MOVE_REPLICA_ASSIGNMENT_SWEEP_INTERVAL_MS: NUM.THOUSAND,
  // ends-on: the services-row control-plane write is accepted
  SERVICE_REGISTRATION_WRITE_RETRY_TIMEOUT_MS: 2 * NUM.THOUSAND,
  // ends-on: the registered service row becomes visible in the services cache
  SERVICE_REGISTRATION_CACHE_VISIBILITY_TIMEOUT_MS: NUM.FIVE_THOUSAND,
  SERVICE_REGISTRATION_CACHE_VISIBILITY_POLL_INTERVAL_MS: NUM.TEN,
});

const BOOTSTRAP_API_CACHE_VISIBILITY = Object.freeze({
  REASON_CACHE_UNAVAILABLE: 'cache_unavailable',
  REASON_SERVICE_ROW_MISSING: 'service_row_missing',
  REASON_FIELD_MISMATCH: 'field_mismatch',
  REASON_STORAGE_ROW_VISIBLE_CACHE_STALE: 'storage_row_visible_cache_stale',
  REASON_STORAGE_ROW_MISSING: 'storage_row_missing',
  REASON_STORAGE_LOOKUP_FAILED: 'storage_lookup_failed',
  REASON_VISIBLE: 'visible',
});

const BOOTSTRAP_API_LOG_MSG = Object.freeze({
  SQL_ENGINE_SET: 'SQL query engine set for bootstrap API',
  STARTED: 'Bootstrap API started',
  BOOTSTRAP_JOIN_READINESS_BLOCKED:
    'Bootstrap join-readiness projection remains blocked',
  RECEIVED_BOOTSTRAP_REQUEST: 'Received bootstrap request',
  VALIDATION_FAILED: 'Bootstrap request validation failed',
  CONFLICT_DETECTED: 'Bootstrap request conflict detected',
  RESPONSE_PREPARED: 'Bootstrap response prepared',
  BOOTSTRAP_FAILED: 'Bootstrap request failed',
  REGISTER_NODE_UNSUPPORTED: 'register-node endpoint is not supported',
  RECEIVED_REGISTER_SERVICE: 'Received register-service request',
  SQL_ENGINE_MISSING: 'SQL query engine not available for service registration',
  MOVE_REPLICA_SOURCE_REMOVAL_START:
    'Removing local source replica before MOVE_REPLICA ownership commit',
  MOVE_REPLICA_SOURCE_REMOVED: 'Removed local source replica for MOVE_REPLICA handoff',
  MOVE_REPLICA_SOURCE_REMOVAL_FAILED:
    'Failed to remove local source replica during MOVE_REPLICA handoff',
  MOVE_REPLICA_HANDOFF_STARTED:
    'Started MOVE_REPLICA handoff operation tracking',
  MOVE_REPLICA_HANDOFF_PHASE_APPLIED:
    'Applied MOVE_REPLICA handoff phase',
  MOVE_REPLICA_HANDOFF_COMPLETED:
    'Completed MOVE_REPLICA handoff operation',
  MOVE_REPLICA_HANDOFF_FAILED:
    'MOVE_REPLICA handoff operation failed',
  MOVE_REPLICA_ASSIGNMENT_RESERVED:
    'Reserved MOVE_REPLICA assignment for joining node',
  MOVE_REPLICA_ASSIGNMENT_RENEWED:
    'Renewed MOVE_REPLICA assignment reservation for original target node',
  MOVE_REPLICA_ASSIGNMENT_RESERVATION_WRITE_FAILED:
    'Best-effort MOVE_REPLICA assignment reservation write failed' +
    ' (in-memory reservation remains authoritative)',
  MOVE_REPLICA_ASSIGNMENT_RENEWAL_WRITE_FAILED:
    'Best-effort MOVE_REPLICA assignment lease renewal write failed' +
    ' (in-memory reservation remains authoritative)',
  MOVE_REPLICA_HANDOFF_INITIATION_WRITE_FAILED:
    'Best-effort MOVE_REPLICA handoff initiation write failed' +
    ' (in-memory reservation remains authoritative)',
  MOVE_REPLICA_ASSIGNMENT_RECONCILED:
    'Reconciled observed MOVE_REPLICA assignment to committed state',
  MOVE_REPLICA_ASSIGNMENT_EXPIRED:
    'Expired stale MOVE_REPLICA assignment reservation',
  MOVE_REPLICA_ASSIGNMENT_SWEEP_FAILED:
    'Failed to sweep MOVE_REPLICA assignment reservations',
  MOVE_REPLICA_ASSIGNMENT_CONFLICT:
    'MOVE_REPLICA assignment reservation conflict detected',
  MOVE_REPLICA_ASSIGNMENT_VALIDATION_FAILED:
    'MOVE_REPLICA assignment token validation failed',
  MOVE_REPLICA_HANDOFF_REFUSED:
    'MOVE_REPLICA handoff refused at register-service',
  SERVICE_REGISTRATION_DEFERRED:
    'Register-service metadata publication deferred',
  SERVICE_REGISTRATION_WRITE_RETRY:
    'Retrying register-service metadata write after retryable failure',
  SERVICE_REGISTRATION_CACHE_VISIBILITY_TIMEOUT:
    'Service registration cache visibility timeout diagnostics',
  SERVICE_REGISTERED: 'Service registered in services table',
  REGISTER_SERVICE_FAILED: 'Failed to register service',
  CACHE_UNAVAILABLE_LEADER: 'System table cache not available for leader lookup',
  CACHE_UNAVAILABLE_GROUPS: 'System table cache not available for message group lookup',
  CACHE_UNAVAILABLE_PARTITIONS: 'System table cache not available for partition leader lookup',
  JOIN_ASSIGNMENT: `${BOOTSTRAP_LOG_PREFIX.JOIN_DEBUG} Determining message group assignment`,
  LEADERS_NOT_READY: 'Bootstrap blocked - missing raft group leaders',
  UPDATE_NODE_STATUS_UNSUPPORTED:
    'updateNodeStatus is not supported - use CDC integration service',
  SHUTDOWN: 'Bootstrap API shutdown',
  SERVER_CLOSE_ERROR: 'Bootstrap server close error',
  READY_NODES_FOR_BOOTSTRAP: 'Ready nodes for bootstrap response',
  IDEMPOTENT_NODE_REJOIN_ALLOWED:
    'Allowing idempotent re-registration of node with unchanged address',
  STALE_NODE_REJOIN_ALLOWED:
    'Allowing re-registration of dead node',
  LEASE_WINDOW_REJOIN_DEFERRED:
    'Deferring changed-address rejoin until the conflicting ready lease expires',
  BOOTSTRAP_ADMISSION_EXPIRED:
    'Expired stale bootstrap admission lease',
  BOOTSTRAP_ADMISSION_DEFERRED:
    'Deferred bootstrap request due to bounded join admission',
  BOOTSTRAP_REQUEST_DEFERRED:
    'Deferred bootstrap request before admitted join work completed',
});

const BOOTSTRAP_API_ERROR = Object.freeze({
  SYSTEM_TABLE_CACHE_REQUIRED: 'BootstrapAPI requires systemTableCache',
  CLUSTER_ID_MISMATCH:
    'Bootstrap request cluster identity does not match this cluster',
  NODE_ID_REQUIRED: 'nodeId is required',
  NODE_ID_INVALID: 'nodeId must be a valid UUID',
  NODE_ADDRESS_REQUIRED: 'nodeAddress is required',
  NODE_ADDRESS_INVALID: 'nodeAddress must be a non-empty string',
  SEED_NODE_ID_CONFLICT: 'Cannot bootstrap with seed node ID',
  SEED_NODE_ADDRESS_CONFLICT: 'Cannot use seed node address',
  NODE_ID_ALREADY_REGISTERED: (nodeId) => `Node ID ${nodeId} is already registered`,
  NODE_ADDRESS_IN_USE: (nodeAddress) => `Node address ${nodeAddress} is already in use`,
  NODE_REJOIN_LEASE_WINDOW:
    'Node rejoin conflicts with a live ready lease; retry after lease expiry',
  INTERNAL_BOOTSTRAP_ERROR: 'Internal server error during bootstrap',
  BOOTSTRAP_NOT_READY: 'Bootstrap not ready',
  RAFT_LEADERS_NOT_READY:
    'Bootstrap unavailable until all raft group leaders are elected',
  REGISTER_NODE_UNSUPPORTED:
    'register-node is not supported; use WebSocket IDENTIFY + NODE_STATE_UPDATE',
  SERVICE_ID_REQUIRED: 'service_id is required',
  SERVICE_TYPE_REQUIRED: 'service_type is required',
  SERVICE_NODE_ID_REQUIRED: 'node_id is required',
  SQL_ENGINE_UNAVAILABLE: 'SQL query engine not available',
  SERVICE_REGISTRATION_FAILED: 'Failed to register service',
  ASSIGNMENT_TOKEN_REQUIRED:
    'assignment_id is required for MOVE_REPLICA register-service',
  ASSIGNMENT_TOKEN_UNKNOWN:
    'assignment_id does not reference an active MOVE_REPLICA assignment',
  ASSIGNMENT_TOKEN_EXPIRED:
    'assignment_id lease has expired for MOVE_REPLICA handoff',
  ASSIGNMENT_TOKEN_MISMATCH:
    'assignment_id does not match requested node_id/replica_id',
  ASSIGNMENT_TOKEN_LOOKUP_UNAVAILABLE:
    'assignment_id lookup is temporarily unavailable',
  REPLICA_OWNER_CONFLICT:
    'active replica owner conflict for message-group replica',
  MOVE_REPLICA_HANDOFF_UNSUPPORTED:
    'MOVE_REPLICA handoff is refused: a message-group replica is never ' +
    'moved onto another node (its replica identity would be reused); ' +
    'the joiner self-hosts its own message group',
  SERVICE_REGISTRATION_CACHE_VISIBILITY_TIMEOUT: (serviceId, nodeId, timeoutMs) =>
    `Timed out waiting for services cache visibility for service ${serviceId} ` +
    `on node ${nodeId} after ${timeoutMs}ms`,
  UPDATE_NODE_STATUS_UNSUPPORTED:
    'updateNodeStatus is not supported; use CDC integration service',
});

const BOOTSTRAP_API_REGISTER_SERVICE_ERROR_CODE = Object.freeze({
  ASSIGNMENT_TOKEN_REQUIRED: 'ASSIGNMENT_TOKEN_REQUIRED',
  ASSIGNMENT_TOKEN_UNKNOWN: 'ASSIGNMENT_TOKEN_UNKNOWN',
  ASSIGNMENT_TOKEN_EXPIRED: 'ASSIGNMENT_TOKEN_EXPIRED',
  ASSIGNMENT_TOKEN_MISMATCH: 'ASSIGNMENT_TOKEN_MISMATCH',
  ASSIGNMENT_TOKEN_LOOKUP_UNAVAILABLE:
    'ASSIGNMENT_TOKEN_LOOKUP_UNAVAILABLE',
  REPLICA_OWNER_CONFLICT: 'REPLICA_OWNER_CONFLICT',
  // Owner decision 2026-10-04 (raft-rs full cutover): every MOVE_REPLICA
  // handoff at /register-service is refused, unconditionally and before the
  // assignment reservation is read (its expired lease would otherwise be
  // force-renewed for a pre-upgrade joiner).
  MOVE_REPLICA_HANDOFF_UNSUPPORTED: 'MOVE_REPLICA_HANDOFF_UNSUPPORTED',
});

const BOOTSTRAP_API_MOVE_REPLICA_ASSIGNMENT_INVALIDATION_REASON =
  Object.freeze({
    INACTIVE_STATUS: 'inactive_status',
    INVALID_RESERVATION: 'invalid_reservation',
    LEASE_EXPIRED: 'lease_expired',
    MISSING_ASSIGNMENT_FIELDS: 'missing_assignment_fields',
    MISSING_LEASE: 'missing_lease',
    SOURCE_OWNER_UNAVAILABLE: 'source_owner_unavailable',
    TERMINAL: 'terminal',
  });

const BOOTSTRAP_API_MOVE_REPLICA_ASSIGNMENT_HISTORY_PHASE = Object.freeze({
  LEASE_RENEWED: 'lease_renewed',
  RESERVED: 'reserved',
  VALIDATED: 'validated',
});

const BOOTSTRAP_API_MOVE_REPLICA_ASSIGNMENT_ERROR = Object.freeze({
  ASSIGNMENT_TOKEN_EXPIRED:
    'assignment token expired',
  RESERVATION_REPLICA_TO_MOVE_REQUIRED:
    'MOVE_REPLICA reservation requires replicaToMove',
  RESERVATION_CONFLICT:
    'MOVE_REPLICA reservation conflict',
  RESERVATION_INVALID:
    'assignment reservation invalid',
  SOURCE_OWNER_UNAVAILABLE:
    'assignment source owner unavailable',
});

const BOOTSTRAP_API_SQL = Object.freeze({
  SELECT_REPLICA_OPERATION_BY_ID: `SELECT *
      FROM replica_operations
      WHERE operation_id = ?`,
  SELECT_MOVE_ASSIGNMENT_RESERVATIONS: `SELECT *
      FROM replica_operations
      WHERE type = ?`,
  SELECT_REGISTERED_SERVICE_BY_ID: `SELECT
        service_id, service_type, node_id, group_id, replica_id,
        raft_role, status, address, created_at, updated_at
      FROM services
      WHERE service_id = ?
      LIMIT 1`,
});

const BOOTSTRAP_API_HANDOFF_PHASE = Object.freeze({
  PREPARE_TARGET: 'prepare_target',
  VERIFY_TARGET: 'verify_target',
  REMOVE_SOURCE: 'remove_source',
  COMMIT_METADATA: 'commit_metadata',
  FAILED: 'failed',
});

const BOOTSTRAP_API_HANDOFF_STATUS = Object.freeze({
  PREPARING: 'creating',
  VERIFYING: 'syncing',
  REMOVING: 'removing',
  COMMITTED: 'active',
  FAILED: 'failed',
});

const BOOTSTRAP_API_HANDOFF_OPERATION = Object.freeze({
  TYPE: 'ADD',
});

const BOOTSTRAP_API_ASSIGNMENT = Object.freeze({
  FIELD_ID: 'assignment_id',
  OPERATION_TYPE: 'MOVE_ASSIGNMENT',
  ACTIVE_RESERVATION_STATUSES: Object.freeze([
    'creating',
    'syncing',
    'removing',
  ]),
  TERMINAL_STATUSES: Object.freeze([
    'active',
    'failed',
    'removed',
  ]),
});

const BOOTSTRAP_API_CLOSE_ERROR_CODE = 'ERR_SERVER_NOT_RUNNING';

const BOOTSTRAP_API_CLUSTER_STATE = Object.freeze({
  HEALTHY: BOOTSTRAP_API_HEALTH_STATUS,
  UNKNOWN: STRING.UNKNOWN,
});

const BOOTSTRAP_API_PROBE_SCOPE = Object.freeze({
  BOOTSTRAP_JOIN: 'bootstrap_join',
});

const BOOTSTRAP_API_READINESS_FIELD = Object.freeze({
  BOOTSTRAP_JOIN_PROJECTION: 'bootstrapJoinProjection',
  SEED_CONTACT: 'seedContact',
  STARTUP_RUNTIME_HANDOFF: 'startupRuntimeHandoff',
});

const BOOTSTRAP_API_REQUEST_FIELD = Object.freeze({
  CLIENT_ATTEMPT_DEADLINE_MS: 'clientAttemptDeadlineMs',
});

const BOOTSTRAP_API_RESPONSE_FIELD = Object.freeze({
  STARTUP_AUTHORITY: 'startupAuthority',
});

const BOOTSTRAP_API_PROBE_REASON = Object.freeze({
  BOOTSTRAP_PHASE_INCOMPLETE: 'BOOTSTRAP_PHASE_INCOMPLETE',
  JOIN_ADMISSION_BACKPRESSURED: 'JOIN_ADMISSION_BACKPRESSURED',
  MOVE_REPLICA_HANDOFF_STABILIZING:
    'MOVE_REPLICA_HANDOFF_STABILIZING',
  CONTROL_PLANE_DEPENDENCY_UNAVAILABLE:
    'CONTROL_PLANE_DEPENDENCY_UNAVAILABLE',
  CLIENT_ATTEMPT_DEADLINE_EXHAUSTED:
    'CLIENT_ATTEMPT_DEADLINE_EXHAUSTED',
  BOOTSTRAP_REQUEST_EXECUTION_BUDGET_EXHAUSTED:
    'BOOTSTRAP_REQUEST_EXECUTION_BUDGET_EXHAUSTED',
});

const BOOTSTRAP_API_LIVENESS = Object.freeze({
  ALIVE: true,
  STATE_RUNNING: 'running',
});

export {
  BOOTSTRAP_API_CACHE_VISIBILITY,
  BOOTSTRAP_API_CLUSTER_STATE,
  BOOTSTRAP_API_DEFAULT,
  BOOTSTRAP_API_CLOSE_ERROR_CODE,
  BOOTSTRAP_API_ERROR,
  BOOTSTRAP_API_HEALTH_STATUS,
  BOOTSTRAP_API_HEALTH_STATUS_INITIALIZING,
  BOOTSTRAP_API_HANDOFF_PHASE,
  BOOTSTRAP_API_HANDOFF_OPERATION,
  BOOTSTRAP_API_HANDOFF_STATUS,
  BOOTSTRAP_API_ASSIGNMENT,
  BOOTSTRAP_API_LIVENESS,
  BOOTSTRAP_API_LOG_MSG,
  BOOTSTRAP_API_MESSAGE_GROUP_PREFIX,
  BOOTSTRAP_API_MOVE_REPLICA_ASSIGNMENT_ERROR,
  BOOTSTRAP_API_MOVE_REPLICA_ASSIGNMENT_HISTORY_PHASE,
  BOOTSTRAP_API_MOVE_REPLICA_ASSIGNMENT_INVALIDATION_REASON,
  BOOTSTRAP_API_PROBE_REASON,
  BOOTSTRAP_API_PROBE_SCOPE,
  BOOTSTRAP_API_READINESS_FIELD,
  BOOTSTRAP_API_REQUEST_FIELD,
  BOOTSTRAP_API_RESPONSE_FIELD,
  BOOTSTRAP_API_ROUTE,
  BOOTSTRAP_API_REGISTER_SERVICE_ERROR_CODE,
  BOOTSTRAP_API_SQL,
  BOOTSTRAP_API_SUBSYSTEM,
};
