/**
 * Seed Registration Phase — handles Phase 4 of seed bootstrap:
 * registering all services, tables, partitions, and configuration
 * in system tables using bootstrap-mode direct writes.
 *
 * Extracted from BootstrapService to keep the orchestrator thin.
 * The class receives required dependencies via constructor injection.
 */

import {
  DECLARED_MESSAGE_GROUP_REPLICA_COUNT_DEFAULT,
  DECLARED_REPLICA_COUNT_DEFAULT,
} from '../replication-target-authority.js';
import {randomUUID} from 'node:crypto';
import {DynamicConfigService} from '../../config/dynamic-config-service.js';
import {
  CONFIG_SEED_SOURCE,
  CONFIG_VALUE_TYPE,
} from '../../config/config-constants.js';
import {EPOCH_CONFIG_KEY} from '../../cdc/cdc-integration-service.js';
import {
  CLUSTER_ID_CONFIG_KEY,
} from '../cluster-identity-constants.js';
import {
  BootstrapSystemTableWriter,
  RoutedSqlSystemTableWriter,
} from '../system-table-writer.js';
import {MessageGroupServiceRowOwner} from
  '../../message-group/message-group-service-row-owner.js';
import {PartitionServiceRowOwner} from
  '../../partition/partition-service-row-owner.js';
import {activatePartitionServiceRows} from
  '../shared/partition-service-activation.js';
import {
  registerBuiltInMetaServiceDefinitions,
  registerBuiltInMetaServiceEndpoints,
} from '../shared/meta-service-definition-registration.js';
import {
  BOOTSTRAP_EPOCH,
  BOOTSTRAP_LOG_MSG,
  BOOTSTRAP_MESSAGE_GROUP,
  BOOTSTRAP_SQL,
} from '../bootstrap-constants.js';
import {
  SYSTEM_TABLE_NAME,
  SYSTEM_TABLE_SCHEMAS,
  INITIAL_MESSAGE_GROUP_ID,
  INITIAL_PARTITION_IDS,
} from '../system-table-schemas-constants.js';
import {PARTITION_STATE} from '../../partition/partition-constants.js';
import {
  COLUMN,
  SERVICE_STATUS,
  SERVICE_TYPE,
} from '../../constants/index.js';
import {
  SeedRegistrationRuntimeOwner,
} from '../owners/seed-registration-runtime-owner.js';
import {createBootstrapCacheHydrationApplier} from
  '../bootstrap-cache-hydration-applier.js';

const LOCAL_STR_FUNCTION = 'function';
const LOCAL_STR_DEFERRING_SEED_PARTITION_SERVICE_ROW_ACT = 'Deferring seed partition service row activation during startup';
const LOCAL_STR_INSERT = 'INSERT';
const LOCAL_STR_DIRECT_BOOTSTRAP_SEED = 'direct_bootstrap_seed';

const EPOCH_EXISTS_SQL = BOOTSTRAP_SQL.EPOCH_EXISTS;
const CLUSTER_ID_EXISTS_SQL = BOOTSTRAP_SQL.EPOCH_EXISTS;
const CLUSTER_ID_CONFIG_DESCRIPTION =
  'Authoritative durable cluster identity (minted once at first seed bootstrap)';
import {resolveHostedNodeClock} from
  '../shared/hosted-replica-authorities.js';
const REGISTRATION_REQUIRED_LEADER_TABLES = Object.freeze([
  SYSTEM_TABLE_NAME.PARTITIONS,
  SYSTEM_TABLE_NAME.SERVICES,
  SYSTEM_TABLE_NAME.TABLES,
  SYSTEM_TABLE_NAME.MESSAGE_GROUPS,
]);
const REGISTRATION_REQUIRED_LEADER_PARTITION_IDS = Object.freeze(
  REGISTRATION_REQUIRED_LEADER_TABLES.map((tableName) =>
    INITIAL_PARTITION_IDS[tableName],
  ).filter(Boolean),
);

/**
 * Handles the registration phase of seed bootstrap.
 */
class SeedRegistrationPhase {
  /**
   * @param {Object} options
   * @param {Object} options.delegates - Callbacks into the bootstrap
   *   service for accessing mutable state.
   */
  constructor(options = {}) {
    this.delegates = options.delegates || {};
    this.messageGroupRegistrationEvidenceByReplicaId = new Map();
    this.runtimeOwner = new SeedRegistrationRuntimeOwner({
      delegates: this.delegates,
    });
  }

  /**
   * Phase 4: Service registration.
   * Register all services in system tables using bootstrap mode.
   * @return {Promise<void>}
   */
  async phaseRegistration() {
    const d = this.delegates;
    const logger = d.getLogger();
    const timestamp = resolveHostedNodeClock(this.delegates)();

    await this.waitForRequiredPartitionLeadership();
    const systemTableWriter = this.ensureSystemTableWriter();

    logger.debug(BOOTSTRAP_LOG_MSG.BOOTSTRAP_MODE_ENABLED, {
      nodeId: d.getNodeId(),
      partitionCount: d.getPartitionServices().size,
    });
    systemTableWriter.enable();

    await this.registerMessageGroup(timestamp);
    await this.registerServices(timestamp);
    await this.registerMetaServiceDefinitions();
    await this.registerSystemTables(timestamp);
    await this.updatePartitionSizes();
    await this.seedDynamicConfiguration();
    await this.persistCurrentEpochIfMissing();
    await this.persistClusterIdIfMissing();

    logger.debug(BOOTSTRAP_LOG_MSG.SERVICE_REGISTRATION_COMPLETE, {
      nodeId: d.getNodeId(),
      servicesCreated: d.getServicesCreated(),
    });
  }

  /**
   * Return the exact partition leaders required by direct registration writes.
   * SeedRegistrationPhase owns this dependency cut; election scheduling may
   * read it but must not restate it.
   * @return {string[]}
   */
  getRequiredLeaderPartitionIds() {
    return [...REGISTRATION_REQUIRED_LEADER_PARTITION_IDS];
  }

  /**
   * Consume the partition leadership owner's existing one-time gate for the
   * registration dependency cut. The partition scheduler moves this same gate
   * earlier so the required cohort can form before unrelated FULL-persistence
   * work; SeedPartitionsPhase owns reuse of the satisfied result.
   * @return {Promise<void>}
   */
  async waitForRequiredPartitionLeadership() {
    await this.delegates.waitForPartitionLeadership({
      partitionIds: REGISTRATION_REQUIRED_LEADER_PARTITION_IDS,
    });
  }

  /**
   * Register the initial message group.
   * @param {number} now - Current timestamp.
   * @return {Promise<void>}
   */
  async registerMessageGroup(now) {
    const d = this.delegates;
    const logger = d.getLogger();
    const systemTableWriter = this.ensureSystemTableWriter();

    const leaderService = d.getLeaderMessageGroupService();
    const leaderNodeId = leaderService?.nodeId || d.getNodeId();

    const groupData = {
      group_id: INITIAL_MESSAGE_GROUP_ID,
      group_name: BOOTSTRAP_MESSAGE_GROUP.NAME,
      // The OWNING table's declaration. This was a restated literal 3 in
      // BOOTSTRAP_MESSAGE_GROUP that agreed with MESSAGE_GROUPS_SCHEMA only
      // by coincidence, so a change to the schema default would have left
      // this seeded row behind.
      replica_count: DECLARED_MESSAGE_GROUP_REPLICA_COUNT_DEFAULT,
      [COLUMN.LEADER_NODE_ID]: leaderNodeId,
      policy: JSON.stringify(BOOTSTRAP_MESSAGE_GROUP.POLICY),
      created_at: now,
      updated_at: now,
    };

    try {
      await systemTableWriter.upsertSystemTableRow(
        SYSTEM_TABLE_NAME.MESSAGE_GROUPS,
        groupData,
      );
      logger.debug(BOOTSTRAP_LOG_MSG.MESSAGE_GROUP_REGISTERED, {
        groupId: INITIAL_MESSAGE_GROUP_ID,
      });
    } catch (error) {
      logger.error(
        BOOTSTRAP_LOG_MSG.MESSAGE_GROUP_REGISTER_FAILED, {
          groupId: INITIAL_MESSAGE_GROUP_ID,
          error: error.message,
        });
      throw error;
    }
  }

  /**
   * Register all services in the services table.
   * @param {number} now - Current timestamp.
   * @return {Promise<void>}
   */
  async registerServices(now) {
    const d = this.delegates;
    const logger = d.getLogger();
    const systemTableWriter = this.ensureSystemTableWriter();
    const nodeId = d.getNodeId();
    const messageGroupServiceRowOwner =
      new MessageGroupServiceRowOwner({
        systemTableWriter,
        now: () => now,
      });
    const partitionServiceRowOwner =
      new PartitionServiceRowOwner({
        systemTableWriter,
        now: () => now,
      });
    const partitionRegistrationEvidenceByReplicaId = new Map();

    // Register message group replicas
    for (const [replicaId, service] of
      d.getMessageGroupServices()) {
      const serviceData =
        MessageGroupServiceRowOwner.buildServiceRow({
          groupId: INITIAL_MESSAGE_GROUP_ID,
          replicaId,
          nodeId,
          service,
          timestamp: now,
        });

      logger.debug(
        BOOTSTRAP_LOG_MSG.REGISTERING_SERVICE, {
          serviceId: replicaId,
          serviceType: SERVICE_TYPE.MESSAGE_GROUP,
          raftRole: serviceData.raft_role,
          address: serviceData.address,
          nodeId,
        });

      try {
        const registrationEvidence =
          await messageGroupServiceRowOwner.registerReplica({
            groupId: INITIAL_MESSAGE_GROUP_ID,
            replicaId,
            nodeId,
            service,
            timestamp: now,
            status: SERVICE_STATUS.STOPPED,
          });
        this.messageGroupRegistrationEvidenceByReplicaId.set(
          replicaId,
          registrationEvidence,
        );
      } catch (error) {
        logger.error(
          BOOTSTRAP_LOG_MSG.MESSAGE_GROUP_SERVICE_REGISTER_FAILED,
          {replicaId, error: error.message},
        );
        throw error;
      }
    }

    // Register partition replicas
    for (const [replicaId, service] of
      d.getPartitionServices()) {
      try {
        const registrationEvidence =
          await partitionServiceRowOwner.registerReplica({
            partitionId: service.partitionId,
            replicaId,
            nodeId,
            service,
            timestamp: now,
            status: SERVICE_STATUS.STOPPED,
          });
        partitionRegistrationEvidenceByReplicaId.set(
          replicaId,
          registrationEvidence,
        );
      } catch (error) {
        logger.error(
          BOOTSTRAP_LOG_MSG.PARTITION_SERVICE_REGISTER_FAILED,
          {replicaId, error: error.message},
        );
        throw error;
      }
    }

    await activatePartitionServiceRows({
      nodeId,
      systemTableWriter,
      replicaStateMachine: d.getReplicaStateMachine(),
      messageRouter: typeof d.getMessageRouter === LOCAL_STR_FUNCTION ?
        d.getMessageRouter() :
        null,
      onDeferredActivation: ({partitionId, replicaId, error}) => {
        logger.warn(
          LOCAL_STR_DEFERRING_SEED_PARTITION_SERVICE_ROW_ACT,
          {
            nodeId,
            partitionId,
            replicaId,
            error: error?.message || String(error),
          },
        );
      },
      partitionServices: d.getPartitionServices(),
      partitionRegistrationEvidenceByReplicaId,
      now: () => now,
    });

    logger.debug(BOOTSTRAP_LOG_MSG.SERVICES_REGISTERED, {
      messageGroupServices: d.getMessageGroupServices().size,
      partitionServices: d.getPartitionServices().size,
    });
  }

  /**
   * Register built-in runtime service definitions.
   * @return {Promise<void>}
   */
  async registerMetaServiceDefinitions() {
    const d = this.delegates;
    const logger = d.getLogger();
    const systemTableWriter = this.ensureSystemTableWriter();
    const metaServices =
      await registerBuiltInMetaServiceDefinitions({
        nowMs: resolveHostedNodeClock(d)(),
        upsertRow: async (tableName, row) => {
          await systemTableWriter.upsertSystemTableRow(
            tableName, row,
          );
        },
      });
    const metaEndpoints =
      await registerBuiltInMetaServiceEndpoints({
        upsertRow: async (tableName, row) => {
          await systemTableWriter.upsertSystemTableRow(
            tableName, row,
          );
          this.projectBootstrapRowToCache(tableName, row);
        },
        nodeId: d.getNodeId(),
        nodeAddress: d.getNodeAddress(),
        advertisedNodeWsAddress: d.getAdvertisedNodeWsAddress?.() || null,
        wsPort: d.getWsPort(),
        nowMs: resolveHostedNodeClock(d)(),
        // Seed registration runs only on a virgin cluster (no prior endpoint
        // rows exist to replace): the rows are born at this boot.
        bootIncarnation: d.getBootIncarnation(),
      });

    logger.debug(BOOTSTRAP_LOG_MSG.SERVICES_REGISTERED, {
      metaServices,
      metaEndpoints,
    });
  }

  /**
   * Project bootstrap-time system-table rows into the local cache when a
   * writable cache is available so later bootstrap steps observe the same
   * canonical metadata without waiting on cache convergence.
   * @param {string} tableName
   * @param {Object} row
   * @return {void}
   */
  projectBootstrapRowToCache(tableName, row) {
    const systemTableCache =
      this.delegates.getSystemTableCache?.();
    if (!systemTableCache) {
      return;
    }
    const logger = this.delegates.getLogger?.();
    try {
      createBootstrapCacheHydrationApplier(systemTableCache)(
        tableName,
        LOCAL_STR_INSERT,
        row,
      );
    } catch (error) {
      logger?.warn?.(BOOTSTRAP_LOG_MSG.CACHE_PROJECTION_FAILED, {
        tableName,
        error: error?.message,
      });
    }
  }

  /**
   * Register system tables metadata.
   * @param {number} now - Current timestamp.
   * @return {Promise<void>}
   */
  async registerSystemTables(now) {
    const d = this.delegates;
    const logger = d.getLogger();
    const systemTableWriter = this.ensureSystemTableWriter();

    for (const schema of SYSTEM_TABLE_SCHEMAS) {
      const tableName = schema.tableName;
      const partitionId = INITIAL_PARTITION_IDS[tableName];

      const tableData = {
        table_id: tableName,
        table_name: tableName,
        schema_definition: JSON.stringify(schema),
        partition_key: schema.columns[0].name,
        table_policies: JSON.stringify({}),
        partition_count: 1,
        active_partition_version: 1,
        pending_partition_version: null,
        partition_transition_state: null,
        partition_transition_metadata: null,
        created_at: now,
        updated_at: now,
      };

      try {
        await systemTableWriter.upsertSystemTableRow(
          SYSTEM_TABLE_NAME.TABLES,
          tableData,
        );
      } catch (error) {
        logger.error(BOOTSTRAP_LOG_MSG.TABLE_REGISTER_FAILED, {
          tableName,
          error: error.message,
        });
        throw error;
      }

      const partitionData = {
        partition_id: partitionId,
        table_id: tableName,
        table_name: tableName,
        partition_key_start: null,
        partition_key_end: null,
        partition_version: 1,
        replica_count: DECLARED_REPLICA_COUNT_DEFAULT,
        size_bytes: 0,
        leader_node_id: d.getNodeId(),
        state: PARTITION_STATE.NORMAL,
        created_at: now,
        updated_at: now,
      };

      try {
        await systemTableWriter.upsertSystemTableRow(
          SYSTEM_TABLE_NAME.PARTITIONS,
          partitionData,
        );
      } catch (error) {
        logger.error(
          BOOTSTRAP_LOG_MSG.PARTITION_REGISTER_FAILED, {
            partitionId,
            error: error.message,
          });
        throw error;
      }
    }

    logger.debug(BOOTSTRAP_LOG_MSG.SYSTEM_TABLES_REGISTERED, {
      tableCount: SYSTEM_TABLE_SCHEMAS.length,
    });
  }

  /**
   * Update partition sizes in the partitions table.
   * @return {Promise<void>}
   */
  async updatePartitionSizes() {
    const d = this.delegates;
    const logger = d.getLogger();
    const systemTableWriter = this.ensureSystemTableWriter();

    const updatedPartitions = new Set();
    let updatedCount = 0;

    for (const [_replicaId, partitionService] of
      d.getPartitionServices()) {
      const partitionId = partitionService.partitionId;

      if (updatedPartitions.has(partitionId)) {
        continue;
      }

      try {
        const sizeBytes =
          await partitionService.calculatePartitionSize();

        await systemTableWriter.updateSystemTableRow(
          SYSTEM_TABLE_NAME.PARTITIONS,
          {partition_id: partitionId},
          {size_bytes: sizeBytes, updated_at: resolveHostedNodeClock(this.delegates)()},
        );

        updatedPartitions.add(partitionId);
        updatedCount++;

        logger.debug(BOOTSTRAP_LOG_MSG.PARTITION_SIZE_UPDATED, {
          partitionId,
          sizeBytes,
        });
      } catch (error) {
        logger.error(
          BOOTSTRAP_LOG_MSG.PARTITION_SIZE_UPDATE_FAILED, {
            partitionId,
            error: error.message,
          });
        throw error;
      }
    }

    logger.debug(BOOTSTRAP_LOG_MSG.PARTITION_SIZES_UPDATED, {
      updatedCount,
      totalPartitions: updatedPartitions.size,
    });
  }

  /**
   * Seed dynamic configuration into the config system table.
   * @return {Promise<void>}
   */
  async seedDynamicConfiguration() {
    const d = this.delegates;
    const logger = d.getLogger();

    const configPartition =
      this.runtimeOwner.findLeaderPartition(SYSTEM_TABLE_NAME.CONFIG);
    if (configPartition?.isLeader) {
      try {
        const result = await configPartition.executeQuery(
          BOOTSTRAP_SQL.CONFIG_COUNT,
        );
        if (result && result.rows && result.rows.length > 0 &&
            result.rows[0].count > 0) {
          logger.info(BOOTSTRAP_LOG_MSG.CONFIG_ALREADY_SEEDED, {
            existingCount: result.rows[0].count,
          });
          return;
        }
      } catch (error) {
        logger.debug(BOOTSTRAP_LOG_MSG.CONFIG_CHECK_FAILED, {
          error: error.message,
        });
        throw error;
      }
    } else {
      logger.debug(BOOTSTRAP_LOG_MSG.CONFIG_LEADER_MISSING, {
        strategy: LOCAL_STR_DIRECT_BOOTSTRAP_SEED,
      });
    }

    const systemTableCache = d.getSystemTableCache();
    const cdcIntegrationService =
      d.ensureBootstrapCdcIntegrationService();

    const dynamicConfigService = new DynamicConfigService({
      cdcIntegrationService,
      systemTableCache,
      nodeId: d.getNodeId(),
      now: resolveHostedNodeClock(d),
    });
    await dynamicConfigService.initialize();

    try {
      const result = await dynamicConfigService.seedConfiguration(
        CONFIG_SEED_SOURCE.SYSTEM,
        {
          skipExistingCheck: true,
          useDirectCdcMutations: true,
          nowMs: resolveHostedNodeClock(d)(),
        },
      );
      logger.info(BOOTSTRAP_LOG_MSG.CONFIG_SEEDED, {
        seeded: result.seeded.length,
        skipped: result.skipped.length,
      });
    } catch (error) {
      logger.error(BOOTSTRAP_LOG_MSG.CONFIG_SEED_FAILED, {
        error: error.message,
        stack: error.stack,
      });
      throw error;
    }
  }

  /**
   * Persist the authoritative assignment epoch in config table.
   * @return {Promise<void>}
   */
  async persistCurrentEpochIfMissing() {
    const d = this.delegates;
    const epochManager = d.getEpochManager();
    if (!epochManager) {
      return;
    }

    const configPartition =
      this.runtimeOwner.findLeaderPartition(SYSTEM_TABLE_NAME.CONFIG);
    if (configPartition?.isLeader) {
      const result = await configPartition.executeQuery(
        EPOCH_EXISTS_SQL,
        [EPOCH_CONFIG_KEY],
      );
      const hasEpoch = result?.success &&
        Array.isArray(result.rows) &&
        result.rows.length > 0;
      if (hasEpoch) {
        return;
      }
    }

    const epoch = epochManager.getCurrentEpoch();
    const serializedEpoch = epoch.toJSON();
    const now = resolveHostedNodeClock(this.delegates)();
    const systemTableWriter = this.ensureSystemTableWriter();

    await systemTableWriter.upsertSystemTableRow(
      SYSTEM_TABLE_NAME.CONFIG, {
        [COLUMN.CONFIG_KEY]: EPOCH_CONFIG_KEY,
        [COLUMN.CONFIG_VALUE]: serializedEpoch,
        [COLUMN.VALUE_TYPE]: CONFIG_VALUE_TYPE.JSON,
        [COLUMN.REQUIRES_RESTART]: 0,
        [COLUMN.DESCRIPTION]:
          BOOTSTRAP_EPOCH.CONFIG_DESCRIPTION,
        [COLUMN.DEFAULT_VALUE]: serializedEpoch,
        [COLUMN.UPDATED_BY]: d.getNodeId(),
        [COLUMN.UPDATED_AT]: now,
        [COLUMN.CREATED_AT]: now,
      });
  }

  /**
   * Mint the durable cluster identity exactly once: the first seed bootstrap
   * persists a randomUUID as the replicated CONFIG-row singleton. A later
   * boot that finds the row already present leaves it untouched (the
   * identity never changes for the life of the cluster).
   * @return {Promise<void>}
   */
  async persistClusterIdIfMissing() {
    const d = this.delegates;
    const configPartition =
      this.runtimeOwner.findLeaderPartition(SYSTEM_TABLE_NAME.CONFIG);
    if (configPartition?.isLeader) {
      const result = await configPartition.executeQuery(
        CLUSTER_ID_EXISTS_SQL,
        [CLUSTER_ID_CONFIG_KEY],
      );
      const hasClusterId = result?.success &&
        Array.isArray(result.rows) &&
        result.rows.length > 0;
      if (hasClusterId) {
        return;
      }
    }

    const clusterId = randomUUID();
    const now = resolveHostedNodeClock(this.delegates)();
    const systemTableWriter = this.ensureSystemTableWriter();

    await systemTableWriter.upsertSystemTableRow(
      SYSTEM_TABLE_NAME.CONFIG, {
        [COLUMN.CONFIG_KEY]: CLUSTER_ID_CONFIG_KEY,
        [COLUMN.CONFIG_VALUE]: clusterId,
        [COLUMN.VALUE_TYPE]: CONFIG_VALUE_TYPE.STRING,
        [COLUMN.REQUIRES_RESTART]: 0,
        [COLUMN.DESCRIPTION]: CLUSTER_ID_CONFIG_DESCRIPTION,
        [COLUMN.DEFAULT_VALUE]: clusterId,
        [COLUMN.UPDATED_BY]: d.getNodeId(),
        [COLUMN.UPDATED_AT]: now,
        [COLUMN.CREATED_AT]: now,
      });
  }

  /**
   * Ensure system table writer is initialized.
   * @return {BootstrapSystemTableWriter|RoutedSqlSystemTableWriter}
   */
  ensureSystemTableWriter() {
    const d = this.delegates;
    let systemTableWriter = d.getSystemTableWriter();
    if (!systemTableWriter) {
      const cdcIntegrationService =
        d.ensureBootstrapCdcIntegrationService();
      systemTableWriter = new BootstrapSystemTableWriter(
        cdcIntegrationService,
        d.getPartitionServices(),
      );
      d.setSystemTableWriter(systemTableWriter);
    }
    return systemTableWriter;
  }

  /**
   * Swap writer to routed SQL implementation once cache is hydrated.
   */
  swapSystemTableWriter() {
    const d = this.delegates;
    const logger = d.getLogger();
    const cdcIntegrationService = d.getCdcIntegrationService();
    if (!cdcIntegrationService) {
      return;
    }

    const currentWriter = d.getSystemTableWriter();
    if (currentWriter && currentWriter.disable) {
      currentWriter.disable();
      logger.debug(BOOTSTRAP_LOG_MSG.BOOTSTRAP_MODE_DISABLED, {
        nodeId: d.getNodeId(),
      });
    }

    const newWriter = new RoutedSqlSystemTableWriter(
      cdcIntegrationService,
    );
    newWriter.enable();
    d.setSystemTableWriter(newWriter);
  }
}

export {SeedRegistrationPhase};
