WITH classified AS MATERIALIZED (
 SELECT CASE
   WHEN typeof(transaction_id) <> 'text' OR octet_length(transaction_id) <> 32
     OR transaction_id GLOB '*[^0-9a-f]*' THEN 0
   WHEN typeof(session_id) <> 'text' OR octet_length(session_id) = 0 THEN 0
   WHEN typeof(transaction_epoch) <> 'integer' OR transaction_epoch < 0
     OR transaction_epoch > 9007199254740991 THEN 0
   WHEN typeof(timeout_deadline) <> 'integer' OR timeout_deadline < 0
     OR timeout_deadline > 9007199254740991 THEN 0
   WHEN typeof(created_at) <> 'integer' OR created_at < 0
     OR created_at > 9007199254740991 OR timeout_deadline < created_at THEN 0
   WHEN typeof(transaction_mode) <> 'text'
     OR octet_length(transaction_mode) NOT IN (8,10) THEN 0
   WHEN octet_length(session_id) > @input_cap THEN 3
   ELSE lagrange_creation_identity_state(
     CAST(session_id AS BLOB), transaction_epoch, timeout_deadline,
     CAST(transaction_mode AS BLOB), created_at, CAST(@session_id AS BLOB),
     @transaction_epoch, @timeout_deadline, CAST(@transaction_mode AS BLOB),
     @created_at)
   END AS identity_state,
   CASE
    WHEN typeof(status) <> 'text' OR octet_length(status) <> 6 THEN 0
    WHEN CAST(status AS BLOB) <> x'414354495645' THEN 0
    WHEN typeof(participant_set_state) <> 'text'
      OR octet_length(participant_set_state) <> 4 THEN 0
    WHEN CAST(participant_set_state AS BLOB) <> x'4f50454e' THEN 0
    WHEN typeof(participant_set_text) <> 'text'
      OR octet_length(participant_set_text) <> 2 THEN 0
    WHEN CAST(participant_set_text AS BLOB) <> x'5b5d' THEN 0
    WHEN typeof(commit_mode) <> 'text' OR octet_length(commit_mode) <> 12 THEN 0
    WHEN CAST(commit_mode AS BLOB) <> x'4e4f545f53454c4543544544' THEN 0
    WHEN typeof(frozen_participant_count) <> 'integer'
      OR frozen_participant_count <> 0 THEN 0
    WHEN typeof(updated_at) <> 'integer' OR updated_at <> created_at THEN 0
    WHEN decision IS NOT NULL OR decision_text IS NOT NULL
      OR decision_digest IS NOT NULL THEN 0
    ELSE 1 END AS initial_candidate,
   octet_length(session_id) AS stored_input_bytes
 FROM sql_transactions WHERE transaction_id=@transaction_id)
SELECT @transaction_id AS transaction_id, @attempt_key AS attempt_key,
 identity_state,
 CASE WHEN identity_state=1 THEN initial_candidate ELSE 0 END AS initial_match,
 CASE WHEN identity_state=3 THEN stored_input_bytes ELSE 0 END AS required_input_bytes
FROM classified
