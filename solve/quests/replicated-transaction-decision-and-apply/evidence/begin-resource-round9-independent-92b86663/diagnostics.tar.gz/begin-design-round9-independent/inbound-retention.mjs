import {defineMessageRouterInboundDispatch} from './navigation/src/transport/message-router-inbound-dispatch.js';
import {MESSAGE_ROUTER_SHARED} from './navigation/src/transport/message-router-shared.js';
const {RouterMessageType}=MESSAGE_ROUTER_SHARED;
class Receiver {}
defineMessageRouterInboundDispatch(Receiver);
const receiver=new Receiver();
const replies=[], requests=[], settle=[];
receiver.nodeInboundActivityAt=new Map();
receiver.timeSource={now:()=>1};
receiver.logger={debug(){},warn(){},error(){}};
receiver.connectionAuthorityOwner={captureIncomingDelivery:()=>null};
receiver.sendRaw=(_ws,message)=>replies.push(message.type);
receiver.handlers=new Map([['partition',envelope=>{
 requests.push(envelope);
 return new Promise(resolve=>settle.push(resolve));
}]]);
let aggregateWireBytes=0;
for(let sender=0;sender<4;sender++) {
 const frame=Buffer.from(JSON.stringify({type:RouterMessageType.SERVICE_MESSAGE,messageId:`m${sender}`,targetAddress:'partition',sourceAddress:`s${sender}`,sourceNodeId:`n${sender}`,payload:{type:'QUERY',session:'x'.repeat(16384),inputReservation:16384,resultMaxRows:1,resultMaxBytes:256}}));
 aggregateWireBytes+=frame.length;
 receiver.dispatchInboundMessage(`n${sender}`,{},frame);
}
await Promise.resolve();
const peak={requests:requests.length,acknowledgedBeforeHandlerCompletion:replies.length,aggregateWireBytes,aggregateParsedSessionBytes:requests.reduce((n,e)=>n+Buffer.byteLength(e.payload.session),0),individualSenderStampBytes:16384,receiverReservationCalls:0};
for(const resolve of settle)resolve({success:true,rows:[]});
await Promise.resolve();await Promise.resolve();
console.log(JSON.stringify({scope:'Actual inbound parse/dispatch with deferred handler double, no sockets or native target run; demonstrates existing owner boundary and retained parsed requests, not a measured heap maximum.',peak,replyCountAfter:replies.length},null,2));
