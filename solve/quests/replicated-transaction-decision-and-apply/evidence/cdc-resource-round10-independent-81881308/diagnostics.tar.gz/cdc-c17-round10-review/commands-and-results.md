# Round-ten independent diagnostic commands and results

Scope: documentation/native phase review only. No product or test source, metadata,
Quest or index was changed. The source search for obsolete documentation/script
names returned missing paths; it supplied no evidence and no product failure.
Actual release/runtime owners were then read from their current paths.

## Exact native phase diagnostic

Working directory:
`/mnt/data/peter/projects/.worktrees/rs-raft-candidate-20261011/test-output/continuation-20261011/cdc-c17-round10-review`

Command executed:

```sh
/mnt/data/peter/projects/.worktrees/tx1-cdc-20261011/test-output/cdc-adrop-layout-20261011/node-22.22.0-production close-barrier-probe.cjs . > close-barrier-probe.log 2>&1
```

Exit0. The script uses a public net.Server, public close/immediate calls, a
microtask shutdown phase latch and V8 snapshots. Client sockets live in a
separate process. The latch is not the proposed production drop observer.
The extracted native graph was one432-byte TCPSocketWrap plus one432-byte
TCPServerWrap at first-immediate, zero of either at second-immediate.
`events.json` records exact runtime versions and event order. The executable
SHA is1bec56ef7cfa9a76f3e0b7c0a87f220eb73f23102b9c0b4c7529a3f7c3ce7c31.

Snapshots were decoded using their own `snapshot.meta.node_fields` and node
stride, selecting names `Node / TCPSocketWrap` and `Node / TCPServerWrap` and
recording type, self_size and count. The result is close-barrier-result.json.

## Source/subject verification

Python hashlib SHA-256 checks verified subject0d725dc4, complete144212-byte
prefix0c44f474, all46 packet manifest entries, layout229cc51a, prior reportaa0e355c,
and all34 application/deployment paths against round-nine navigation hashes.
`navigation.json` records every observed path/result and the recomputed bank
arithmetic480/4792/6080/16384 KiB and supported-row byte totals.

Additional exact official Node v22.22.0 files were fetched using Python
urllib.request from the URLs in `native/manifest.json`. These complement the
retained Node22.22/libuv1.51 source packet. No executable/source attestation is
inferred from matching version strings or official upstream file hashes.

## Result boundaries

This observes the proposed close barrier's native lifetime defect. It is not
an application regression test, coverage adapter test,512 KiB overflow,
48-root stress run, whole-process/RSS bound, future runtime certification or
production startup/recovery acceptance. The following nested immediate is a
positive phase control, not an approved implementation patch.
