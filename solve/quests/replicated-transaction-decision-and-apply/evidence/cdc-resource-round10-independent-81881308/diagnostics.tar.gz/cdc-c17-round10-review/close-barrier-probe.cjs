'use strict';
// Phase diagnostic only: a test latch requests shutdown immediately after a
// native accepted-handle callback. This is not the proposed production drop
// observer, nor an implementation of the coverage listener.
const net = require('node:net');
const fs = require('node:fs');
const path = require('node:path');
const v8 = require('node:v8');
const cp = require('node:child_process');
const output = process.argv[2];
const server = net.createServer();
server.maxConnections = 0;
const events = [];
const timer = setTimeout(() => { throw new Error('phase probe timeout'); }, 5000);
let seen = false;
function capture(phase) {
  const file = path.join(output, phase + '.heapsnapshot');
  v8.writeHeapSnapshot(file);
  events.push(phase);
}
server.on('drop', () => {
  if (seen) return;
  seen = true;
  events.push('drop');
  queueMicrotask(() => {
    events.push('shutdown-request');
    server.close(() => {
      events.push('server-close');
      setImmediate(() => {
        capture('first-immediate');
        setImmediate(() => {
          capture('second-immediate');
          clearTimeout(timer);
          fs.writeFileSync(path.join(output, 'events.json'), JSON.stringify({
            executable: process.execPath, versions: process.versions, events,
          }, null, 2) + '\n');
        });
      });
    });
  });
});
server.listen(0, '127.0.0.1', () => {
  cp.spawn(process.execPath, ['-e',
    "const net=require('node:net');const s=net.connect(Number(process.argv[1]),'127.0.0.1');s.on('error',()=>{});s.on('close',()=>process.exit(0));setTimeout(()=>process.exit(3),3000);",
    String(server.address().port)], {stdio: 'ignore'});
});
