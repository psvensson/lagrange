import {PARTITION_SERVICE_SHARED} from './partition-service-shared.js';
import {QUERY_ERROR_CODE} from '../query/query-constants.js';
import {HLCTimestamp} from '../hlc/hlc-timestamp.js';
import {PartitionServiceSchemaMigrationBase} from './partition-service-schema-migration-base.js';
import {
  createPartitionServiceTransactionSessionMethods,
} from './partition-service-transaction-session-methods.js';
import {
  PARTITION_COMMITTED_COMMAND_ERROR_CODE,
  PARTITION_COMMITTED_COMMAND_HOST_FAILURE_REASON,
  PARTITION_COMMITTED_COMMAND_OUTCOME,
} from './partition-service-constants.js';
import {
  REPLICA_OPERATION_MESSAGE_GROUP_MEMBERSHIP_COLUMNS,
} from '../bootstrap/replica-operation-message-group-membership-schema-constants.js';
import {
  isCommittedCommandType,
  isCommittedSqlCommandType,
} from './partition-committed-command-admission.js';
import {PARTITION_COMMITTED_STATEMENT_RECORD_STATE} from
  './partition-committed-statement-outcome-constants.js';
import {
  readCommittedStatementOutcome,
  recordCommittedStatementOutcome,
  settleFailedCommittedStatement,
  settleRecordedCommittedStatement,
} from './partition-committed-statement-outcome.js';
import {
  PARTITION_WRITE_LEADERSHIP_REFUSAL,
  pickTypedWriteAnswer,
} from './partition-write-kernel.js';
import {runCommittedPartitionStatement} from './partition-statement-admission.js';
import {advancePartitionWriteGeneration, isPartitionReserved, readPartitionWriteOrigin} from
  './partition-participant-transaction-store.js';
import {assertTransactionSchemaWriteEnforced, coordinatorTableSchemaRefusal} from
  '../query/distributed/distributed-transaction-schema-enforcement.js';
import {applyCommittedTransactionCommand, settleReservedCommittedStatement} from
  './partition-participant-transaction-apply.js';
import {requestCoordinatorSettlement, applyCoordinatorSettlement} from
  './partition-coordinator-settlement.js';
import {COORDINATOR_SETTLEMENT_TYPE} from './partition-coordinator-settlement-constants.js';
import {ensureSqlTransactionsDecisionColumns} from
  './partition-coordinator-table-columns.js';
import {answerParticipantSessionQuery, routeParticipantTransactionRequest} from
  './partition-participant-transaction-request.js';
import {
  applyCdcAcknowledgementCommand,
  isCdcCommandType,
  recordCommittedStatementCdc,
} from './partition-cdc-obligation.js';
import {QUERY_RESULT_REQUEST_FIELD} from '../query/query-result-budget.js';
import {findParticipantSession} from './partition-participant-transaction-session.js';
const READ_AUTHORITY_WITNESS_STATE = Object.freeze({
  NOT_APPLICABLE: 'not_applicable',
  OBSERVED: 'observed',
});
const COMMIT_APPLY_EFFECT_PHASE = Object.freeze({
  COMMIT: 'afterCommit',
  ROLLBACK: 'afterRollback',
});

const {
  ERRORS,
  PARTITION_SERVICE_COLUMN,
  PARTITION_SERVICE_COLUMN_SQL,
  PARTITION_SERVICE_ERROR_MSG,
  PARTITION_SERVICE_EVENT,
  PARTITION_SERVICE_LITERAL,
  PARTITION_SERVICE_LOG_MSG,
  PARTITION_SERVICE_MESSAGE_TYPE,
  PARTITION_SERVICE_MIGRATION_OPERATION,
  PARTITION_SERVICE_OPERATION,
  PARTITION_SERVICE_RESPONSE,
  PARTITION_SERVICE_VALUE,
  PARTITION_TRANSITION_STATE,
  TABLES,
  buildDurableCommitWitness,
  QUERY_PAYLOAD_FIELD_ENTRY_ID,
  QUERY_PAYLOAD_FIELD_EXPECTED_PARTITION_VERSION,
  QUERY_PAYLOAD_FIELD_IDEMPOTENCY_KEY,
  QUERY_PAYLOAD_FIELD_MIGRATION_ID,
  QUERY_PAYLOAD_FIELD_MIGRATION_OPERATION,
  QUERY_PAYLOAD_FIELD_OPERATION_ID,
  RaftRole,
  SYSTEM_TABLE_NAME,
  isRaftRsTransportEnvelope,
} = PARTITION_SERVICE_SHARED;

class PartitionServiceEntryApplyBase extends PartitionServiceSchemaMigrationBase {
  ensureReplicaOperationsTableColumns() {
    if (this.tableName !== SYSTEM_TABLE_NAME.REPLICA_OPERATIONS) {
      return;
    }
    const columns = this.db
      .prepare(`PRAGMA table_info(${this.tableName})`)
      .all();
    const hasTargetClaimKey = columns.some(
      (col) => col.name === PARTITION_SERVICE_COLUMN.TARGET_CLAIM_KEY,
    );
    const hasMembershipPublicationEpoch = columns.some(
      (col) => col.name ===
        PARTITION_SERVICE_COLUMN.MEMBERSHIP_PUBLICATION_EPOCH,
    );
    const admissionColumns = [
      [PARTITION_SERVICE_COLUMN.CREATE_ADMISSION_STATE,
        PARTITION_SERVICE_COLUMN_SQL.ADD_CREATE_ADMISSION_STATE],
      [PARTITION_SERVICE_COLUMN.CREATE_ADMISSION_TOKEN,
        PARTITION_SERVICE_COLUMN_SQL.ADD_CREATE_ADMISSION_TOKEN],
      [PARTITION_SERVICE_COLUMN.CREATE_ADMISSION_REPLICA_CREATED_AT,
        PARTITION_SERVICE_COLUMN_SQL.ADD_CREATE_ADMISSION_REPLICA_CREATED_AT],
      [PARTITION_SERVICE_COLUMN.CREATE_ADMISSION_ATTEMPT_TOKEN,
        PARTITION_SERVICE_COLUMN_SQL.ADD_CREATE_ADMISSION_ATTEMPT_TOKEN],
      [PARTITION_SERVICE_COLUMN.CREATE_ADMISSION_PREVIOUS_ATTEMPT_TOKEN,
        PARTITION_SERVICE_COLUMN_SQL
          .ADD_CREATE_ADMISSION_PREVIOUS_ATTEMPT_TOKEN],
      [PARTITION_SERVICE_COLUMN.CREATE_ADMISSION_ATTEMPT_SEQ,
        PARTITION_SERVICE_COLUMN_SQL.ADD_CREATE_ADMISSION_ATTEMPT_SEQ],
      [PARTITION_SERVICE_COLUMN.CREATE_ADMISSION_WORKFLOW_UPDATED_AT,
        PARTITION_SERVICE_COLUMN_SQL
          .ADD_CREATE_ADMISSION_WORKFLOW_UPDATED_AT],
      [PARTITION_SERVICE_COLUMN.CREATE_ADMISSION_OWNER_INCARNATION,
        PARTITION_SERVICE_COLUMN_SQL
          .ADD_CREATE_ADMISSION_OWNER_INCARNATION],
    ];
    const membershipColumns =
      REPLICA_OPERATION_MESSAGE_GROUP_MEMBERSHIP_COLUMNS.map((column) => [
        column.name,
        `ADD COLUMN ${column.name} ${column.type}`,
      ]);
    if (!hasTargetClaimKey) {
      this.db.exec(
        `ALTER TABLE ${this.tableName} ` +
          PARTITION_SERVICE_COLUMN_SQL.ADD_TARGET_CLAIM_KEY,
      );
      this.logger.info(
        PARTITION_SERVICE_LOG_MSG
          .ADDED_REPLICA_OPERATIONS_TARGET_CLAIM_KEY,
        {tableName: this.tableName, partitionId: this.partitionId},
      );
    }
    if (!hasMembershipPublicationEpoch) {
      this.db.exec(
        `ALTER TABLE ${this.tableName} ` +
          PARTITION_SERVICE_COLUMN_SQL.ADD_MEMBERSHIP_PUBLICATION_EPOCH,
      );
      this.logger.info(
        PARTITION_SERVICE_LOG_MSG
          .ADDED_REPLICA_OPERATIONS_MEMBERSHIP_PUBLICATION_EPOCH,
        {tableName: this.tableName, partitionId: this.partitionId},
      );
    }
    for (const [columnName, addColumnSql] of admissionColumns) {
      if (columns.some((column) => column.name === columnName)) continue;
      this.db.exec(`ALTER TABLE ${this.tableName} ${addColumnSql}`);
      this.logger.info(
        PARTITION_SERVICE_LOG_MSG
          .ADDED_REPLICA_OPERATIONS_CREATE_ADMISSION_COLUMN,
        {tableName: this.tableName, partitionId: this.partitionId, columnName},
      );
    }
    for (const [columnName, addColumnSql] of membershipColumns) {
      if (columns.some((column) => column.name === columnName)) continue;
      this.db.exec(`ALTER TABLE ${this.tableName} ${addColumnSql}`);
      this.logger.info(
        PARTITION_SERVICE_LOG_MSG
          .ADDED_REPLICA_OPERATIONS_MESSAGE_GROUP_MEMBERSHIP_COLUMN,
        {tableName: this.tableName, partitionId: this.partitionId, columnName},
      );
    }
  }

  ensureSqlTransactionsTableColumns() {
    if (this.tableName !== SYSTEM_TABLE_NAME.SQL_TRANSACTIONS) {
      return;
    }
    const columns = this.db
      .prepare(`PRAGMA table_info(${this.tableName})`)
      .all();
    const hasTransactionEpoch = columns.some(
      (col) => col.name === PARTITION_SERVICE_COLUMN.TRANSACTION_EPOCH,
    );
    const hasTimeoutDeadline = columns.some(
      (col) => col.name === PARTITION_SERVICE_COLUMN.TIMEOUT_DEADLINE,
    );
    const hasTransactionMode = columns.some(
      (col) => col.name === PARTITION_SERVICE_COLUMN.TRANSACTION_MODE,
    );
    const hasParticipantSetState = columns.some(
      (col) => col.name === PARTITION_SERVICE_COLUMN.PARTICIPANT_SET_STATE,
    );
    const hasCommitMode = columns.some(
      (col) => col.name === PARTITION_SERVICE_COLUMN.COMMIT_MODE,
    );
    const hasFrozenParticipantCount = columns.some(
      (col) => col.name === PARTITION_SERVICE_COLUMN.FROZEN_PARTICIPANT_COUNT,
    );
    if (!hasTransactionEpoch) {
      this.db.exec(
        `ALTER TABLE ${this.tableName} ` +
          PARTITION_SERVICE_COLUMN_SQL.ADD_TRANSACTION_EPOCH,
      );
      this.logger.info(
        PARTITION_SERVICE_LOG_MSG.ADDED_SQL_TRANSACTIONS_TRANSACTION_EPOCH,
        {tableName: this.tableName, partitionId: this.partitionId},
      );
    }
    if (!hasTimeoutDeadline) {
      this.db.exec(
        `ALTER TABLE ${this.tableName} ` +
          PARTITION_SERVICE_COLUMN_SQL.ADD_TIMEOUT_DEADLINE,
      );
      this.logger.info(
        PARTITION_SERVICE_LOG_MSG.ADDED_SQL_TRANSACTIONS_TIMEOUT_DEADLINE,
        {tableName: this.tableName, partitionId: this.partitionId},
      );
    }
    if (!hasTransactionMode) {
      this.db.exec(
        `ALTER TABLE ${this.tableName} ` +
          PARTITION_SERVICE_COLUMN_SQL.ADD_TRANSACTION_MODE,
      );
      this.logger.info(
        PARTITION_SERVICE_LOG_MSG.ADDED_SQL_TRANSACTIONS_TRANSACTION_MODE,
        {tableName: this.tableName, partitionId: this.partitionId},
      );
    }
    if (!hasParticipantSetState) {
      this.db.exec(
        `ALTER TABLE ${this.tableName} ` +
          PARTITION_SERVICE_COLUMN_SQL.ADD_PARTICIPANT_SET_STATE,
      );
      this.logger.info(
        PARTITION_SERVICE_LOG_MSG
          .ADDED_SQL_TRANSACTIONS_PARTICIPANT_SET_STATE,
        {tableName: this.tableName, partitionId: this.partitionId},
      );
    }
    if (!hasCommitMode) {
      this.db.exec(
        `ALTER TABLE ${this.tableName} ` +
          PARTITION_SERVICE_COLUMN_SQL.ADD_COMMIT_MODE,
      );
      this.logger.info(
        PARTITION_SERVICE_LOG_MSG.ADDED_SQL_TRANSACTIONS_COMMIT_MODE,
        {tableName: this.tableName, partitionId: this.partitionId},
      );
    }
    if (!hasFrozenParticipantCount) {
      this.db.exec(
        `ALTER TABLE ${this.tableName} ` +
          PARTITION_SERVICE_COLUMN_SQL.ADD_FROZEN_PARTICIPANT_COUNT,
      );
      this.logger.info(
        PARTITION_SERVICE_LOG_MSG
          .ADDED_SQL_TRANSACTIONS_FROZEN_PARTICIPANT_COUNT,
        {tableName: this.tableName, partitionId: this.partitionId},
      );
    }
    // The coordinator's insert-once decision record (TX1 seam C): the
    // participant vocabulary names the columns and their DDL.
    ensureSqlTransactionsDecisionColumns(this);
  }
  /**
   * Handle incoming transport message.
   * A raft-rs semantic envelope is stepped into the replica's operation
   * port; anything else is an application message.
   * Requirements: 8.3, 8.4, 13.1, 13.2, 13.3, 13.4
   * @param {Object} envelope - Message envelope.
   * @return {Promise<Object>} Response.
   * @private
   */
  async handleTransportMessage(envelope) {
    const payload = envelope.payload || envelope;
    if (isRaftRsTransportEnvelope(payload)) {
      if (this.raft) {
        await Promise.resolve(this.raft.step(payload));
      }
      return {acknowledged: true};
    }
    return this.handleApplicationMessage(envelope);
  }
  /**
   * Handle application messages (non-Raft messages).
   * Consensus envelopes are handled by handleTransportMessage().
   * This method only handles application-level messages like FORWARD_WRITE.
   * Requirements: 13.3, 13.4
   * @param {Object} message - Application message
   * @return {Promise<Object>} Processing result
   */
  async handleApplicationMessage(message) {
    const payload = this.extractApplicationPayload(message);
    if (!payload || !payload.type) {
      return {
        acknowledged: false,
        error: PARTITION_SERVICE_ERROR_MSG.INVALID_MESSAGE,
      };
    }
    const admission = this.resolveRemovalServingAdmission(payload);
    if (admission.allowed !== true) {
      return {
        acknowledged: true,
        success: false,
        error: PARTITION_SERVICE_ERROR_MSG.SERVING_ADMISSION_FENCED_FOR_REMOVAL,
        deferRetry: true,
        partitionId: this.partitionId,
      };
    }
    if (admission.servingRequest) {
      this.activeServingRequestCount += 1;
    }
    try {
      return await this.handleAdmittedApplicationMessage(payload);
    } finally {
      if (admission.servingRequest) {
        this.activeServingRequestCount -= 1;
      }
    }
  }

  /**
   * Classify the complete serving ingress set in one place. Transaction
   * controls remain admitted so an existing owner can finish; BEGIN is then
   * rejected by the transaction owner when no session already exists.
   * @param {Object} payload
   * @return {{allowed: boolean, servingRequest: boolean}}
   * @private
   */
  resolveRemovalServingAdmission(payload) {
    const servingRequest = this.isRemovalServingRequestType(payload.type);
    if (!servingRequest || this.removalServingAdmissionFenced !== true) {
      return {allowed: true, servingRequest};
    }
    if (payload.type === PARTITION_SERVICE_MESSAGE_TYPE.TRANSACTION ||
        payload.type === COORDINATOR_SETTLEMENT_TYPE) {
      return {allowed: true, servingRequest};
    }
    const sessionId =
      payload.sessionId || payload.operation?.sessionId || null;
    // An open session finishes: a legacy one, or a participant staging one.
    return {
      allowed: Boolean((sessionId && this.resolveOpenTransactionState(sessionId)) ||
        findParticipantSession(this, payload)),
      servingRequest,
    };
  }

  /**
   * @param {string} type
   * @return {boolean}
   * @private
   */
  isRemovalServingRequestType(type) {
    switch (type) {
    case PARTITION_SERVICE_MESSAGE_TYPE.FORWARD_WRITE:
    case PARTITION_SERVICE_MESSAGE_TYPE.SYSTEM_TABLE_WRITE:
    case PARTITION_SERVICE_MESSAGE_TYPE.QUERY:
    case PARTITION_SERVICE_MESSAGE_TYPE.TRANSACTION:
    case COORDINATOR_SETTLEMENT_TYPE:
      return true;
    default:
      return false;
    }
  }

  /**
   * Dispatch one application message after the removal-serving owner admits
   * it. Keeping the switch behind that single gate prevents new ingress paths
   * from accidentally bypassing removal drain accounting.
   * @param {Object} payload
   * @return {Promise<Object>}
   * @private
   */
  async handleAdmittedApplicationMessage(payload) {
    switch (payload.type) {
    case PARTITION_SERVICE_MESSAGE_TYPE.FORWARD_WRITE:
      if (payload.operation) {
        return this.applyWrite(payload.operation);
      }
      return {
        acknowledged: false,
        error: PARTITION_SERVICE_ERROR_MSG.INVALID_FORWARD_WRITE,
      };
    case PARTITION_SERVICE_MESSAGE_TYPE.SYSTEM_TABLE_WRITE:
      return this.handleSystemTableWrite(payload);
    case PARTITION_SERVICE_MESSAGE_TYPE.QUERY:
      return this.handleRemoteQuery(payload);
    case PARTITION_SERVICE_MESSAGE_TYPE.TRANSACTION:
      return this.handleTransactionMessage(payload);
    case COORDINATOR_SETTLEMENT_TYPE:
      return requestCoordinatorSettlement(this, payload);
    case PARTITION_SERVICE_MESSAGE_TYPE.START_SPLIT_REPLICATION:
      return this.handleStartSplitReplication(payload);
    case PARTITION_SERVICE_MESSAGE_TYPE.START_MERGE_REPLICATION:
      return this.handleStartMergeReplication(payload);
    case PARTITION_SERVICE_MESSAGE_TYPE.LEARNER_PROMOTION_PROOF:
      return this.handleLearnerPromotionProofRequest(payload);
    default:
      this.logger.debug(PARTITION_SERVICE_LOG_MSG.UNKNOWN_MESSAGE_TYPE, {
        type: payload.type,
        partitionId: this.partitionId,
      });
      return {
        acknowledged: false,
        error: PARTITION_SERVICE_ERROR_MSG.unknownMessage(payload.type),
      };
    }
  }
  /**
   * Handle remote transaction control operations.
   * @param {Object} payload - Transaction message payload.
   * @return {Promise<Object>} Transaction operation response.
   * @private
   */
  async handleTransactionMessage(payload) {
    const operation = payload?.operation;
    const sessionId = payload?.sessionId || null;
    const transactionEpoch = Number.isFinite(payload?.transactionEpoch) ?
      Math.floor(payload.transactionEpoch) :
      null;
    try {
      // A request carrying a transactionId is the participant protocol's; the
      // L6 fences keep a sessionId-only request off a participant's partition.
      const result = await (routeParticipantTransactionRequest(this, payload) ??
        this.executeTransactionControl(operation, sessionId, transactionEpoch));
      if (!result) {
        return {
          acknowledged: false,
          success: false,
          error: PARTITION_SERVICE_ERROR_MSG.unknownOperation(operation),
        };
      }
      return {
        acknowledged: true,
        success: result?.success === true,
        ...result,
      };
    } catch (error) {
      return {
        acknowledged: true,
        success: false,
        error: error.message,
        deferRetry: error?.deferRetry === true,
      };
    }
  }

  /**
   * @param {string} operation
   * @param {string|null} sessionId
   * @param {number|null} transactionEpoch
   * @return {Promise<Object|null>}
   * @private
   */
  async executeTransactionControl(operation, sessionId, transactionEpoch) {
    switch (operation) {
    case PARTITION_SERVICE_OPERATION.BEGIN_TRANSACTION:
    case PARTITION_SERVICE_LITERAL.BEGIN:
      return this.beginTransaction(sessionId, transactionEpoch);
    case PARTITION_SERVICE_OPERATION.PREPARE_TRANSACTION:
    case PARTITION_SERVICE_LITERAL.PREPARE:
      return this.prepareTransaction(sessionId);
    case PARTITION_SERVICE_OPERATION.COMMIT:
      return this.commitTransaction(sessionId);
    case PARTITION_SERVICE_OPERATION.ROLLBACK:
      return this.rollbackTransaction(sessionId);
    case PARTITION_SERVICE_OPERATION.TRANSACTION_OUTCOME:
      return {
        success: true,
        outcome: this.resolveTransactionCommitOutcome(
          sessionId,
          transactionEpoch,
        ),
      };
    default:
      return null;
    }
  }
  /**
   * Extract canonical application payload from transport envelopes.
   * Message-group direct deliveries wrap payloads as:
   * {messageId, payload, sourceGroup, sourceReplica}.
   * @param {Object} message - Incoming transport message/envelope.
   * @return {Object|null} Canonical payload.
   * @private
   */
  extractApplicationPayload(message) {
    const directPayload = message?.payload || message;
    if (
      directPayload &&
      typeof directPayload === PARTITION_SERVICE_LITERAL.OBJECT &&
      !directPayload.type &&
      directPayload.payload &&
      typeof directPayload.payload === PARTITION_SERVICE_LITERAL.OBJECT
    ) {
      return directPayload.payload;
    }
    return directPayload || null;
  }
  /**
   * Handle system table write operations from remote nodes.
   * This allows joining nodes to update system tables via CDC routing.
   * @param {Object} payload - Write operation payload.
   * @param {string} payload.operation - Operation type (INSERT, UPDATE, DELETE).
   * @param {string} payload.tableName - Target table name.
   * @param {Object} payload.data - Data for INSERT/UPDATE.
   * @param {Object} payload.whereClause - WHERE clause for UPDATE/DELETE.
   * @return {Promise<Object>} Operation result.
   * @private
   */
  async handleSystemTableWrite(payload) {
    const {operation, tableName, data, whereClause} = payload;
    this.logger.debug(PARTITION_SERVICE_LOG_MSG.HANDLING_SYSTEM_TABLE_WRITE, {
      operation,
      tableName,
      partitionId: this.partitionId,
      replicaId: this.replicaId,
    });
    try {
      let result;
      switch (operation) {
      case PARTITION_SERVICE_OPERATION.INSERT:
        result = await this.insertData(tableName, data);
        break;
      case PARTITION_SERVICE_OPERATION.UPDATE:
        result = await this.updateData(tableName, whereClause, data);
        break;
      case PARTITION_SERVICE_OPERATION.DELETE:
        result = await this.deleteData(tableName, whereClause);
        break;
      case PARTITION_SERVICE_OPERATION.UPSERT:
        result = await this.upsertData(tableName, data);
        break;
      default:
        return {
          acknowledged: false,
          error: PARTITION_SERVICE_ERROR_MSG.unknownOperation(operation),
        };
      }
      return {
        acknowledged: true,
        success: result.success,
        changes: result.changes || 0,
      };
    } catch (error) {
      this.logger.error(PARTITION_SERVICE_ERROR_MSG.SYSTEM_TABLE_WRITE_FAILED, {
        operation,
        tableName,
        error: error.message,
        partitionId: this.partitionId,
      });
      throw error;
    }
  }
  /**
   * Describe the replica that actually served a successful read.
   * @param {boolean} isWriteOperation
   * @return {Object}
   * @private
   */
  buildRemoteReadAuthorityWitness(isWriteOperation) {
    if (isWriteOperation) {
      return {state: READ_AUTHORITY_WITNESS_STATE.NOT_APPLICABLE};
    }
    // The term is the consensus core's own, read through the port.
    const status = this.raft?.readStatus();
    return {
      state: READ_AUTHORITY_WITNESS_STATE.OBSERVED,
      partitionId: this.partitionId,
      servingNodeId: this.nodeId,
      servingReplicaId: this.replicaId,
      term: status?.term ?? null,
      role: this.role,
      // The witness records WHEN THIS REPLICA observed its own authority, so
      // it reads this replica's clock. This is the owner decision the metered
      // oracle's knownAmbientSiteOutsideProofCone reserved: the site had no
      // clock owner when it was recorded, and the composed formation reaching
      // it is what supplied one.
      observedAtMs: this.timeSource.now(),
    };
  }
  /**
   * Handle remote SQL query execution.
   * Enables transparent query routing - any node can execute queries on any partition.
   * For write operations on non-leaders, returns a redirect response with leader address.
   * @param {Object} payload - Query payload.
   * @param {string} payload.sql - SQL query string.
   * @param {Array} payload.params - Query parameters.
   * @return {Promise<Object>} Query result or redirect response.
   * @private
   */
  /**
   * Write-path epoch fencing at the partition boundary: reject a write
   * whose expectedPartitionVersion mismatches the locally authoritative
   * partition epoch with a typed stale-epoch outcome. Epoch evidence
   * never fails OPEN: when the local tables row is unavailable (cold
   * cache after restart) but the payload carries an expectation, the
   * write defers pre-cutover / fails closed post-cutover instead of
   * silently skipping validation. Returns the rejection envelope or
   * null when the write may proceed.
   * @param {*} expectedVersion - Payload epoch expectation.
   * @return {Object|null}
   * @private
   */
  rejectStalePartitionEpochWrite(expectedVersion) {
    if (!Number.isSafeInteger(expectedVersion) || expectedVersion <= 0) {
      return null;
    }
    const localVersion = this.resolveLocalActivePartitionVersion();
    if (localVersion === null) {
      return this.resolveEpochEvidenceGapOutcome(expectedVersion);
    }
    if (localVersion !== expectedVersion) {
      this.logger.warn(
        PARTITION_SERVICE_LOG_MSG.STALE_PARTITION_EPOCH_REJECTED,
        {
          partitionId: this.partitionId,
          expectedVersion,
          localVersion,
        },
      );
      return {
        acknowledged: true,
        success: false,
        error: PARTITION_SERVICE_ERROR_MSG.STALE_PARTITION_EPOCH_WRITE,
        errorCode: QUERY_ERROR_CODE.STALE_PARTITION_EPOCH,
        partitionId: this.partitionId,
      };
    }
    return null;
  }

  /**
   * Resolve the locally authoritative active partition version from the
   * cached tables row; null when the row is unavailable.
   * @return {number|null}
   * @private
   */
  resolveLocalActivePartitionVersion() {
    const row =
      this.systemTableCache?.get?.(TABLES.TABLES, this.tableId) ||
      this.systemTableCache?.get?.(TABLES.TABLES, this.tableName) ||
      null;
    const version = Number(
      row?.active_partition_version ?? row?.activePartitionVersion,
    );
    return Number.isSafeInteger(version) && version > 0 ? version : null;
  }

  /**
   * Epoch evidence gap (cold cache): a write carrying an epoch
   * expectation must never fail open. Pre-cutover it defers (the
   * evidence will hydrate and the retry re-validates); post-cutover it
   * fails closed (a withdrawn epoch must never accept writes).
   * @param {number} expectedVersion - Payload epoch expectation.
   * @return {Object} Rejection/defer envelope.
   * @private
   */
  resolveEpochEvidenceGapOutcome(expectedVersion) {
    const cutoverActive =
      this.splitReplication?.phase ===
        PARTITION_TRANSITION_STATE.SPLIT_CUTOVER_ACTIVE ||
      this.mergeReplication?.phase ===
        PARTITION_TRANSITION_STATE.MERGE_CUTOVER_ACTIVE;
    if (cutoverActive) {
      this.logger.warn(
        PARTITION_SERVICE_LOG_MSG.STALE_PARTITION_EPOCH_REJECTED,
        {partitionId: this.partitionId, expectedVersion, evidenceGap: true},
      );
      return {
        acknowledged: true,
        success: false,
        error: PARTITION_SERVICE_ERROR_MSG.STALE_PARTITION_EPOCH_WRITE,
        errorCode: QUERY_ERROR_CODE.STALE_PARTITION_EPOCH,
        partitionId: this.partitionId,
      };
    }
    this.logger.info(
      PARTITION_SERVICE_LOG_MSG.PARTITION_EPOCH_EVIDENCE_DEFERRED,
      {partitionId: this.partitionId, expectedVersion},
    );
    return {
      acknowledged: true,
      success: false,
      error: PARTITION_SERVICE_ERROR_MSG.PARTITION_EPOCH_EVIDENCE_MISSING,
      errorCode: QUERY_ERROR_CODE.PARTITION_EPOCH_EVIDENCE_DEFERRED,
      deferRetry: true,
      partitionId: this.partitionId,
    };
  }

  async handleRemoteQuery(payload) {
    const {
      sql,
      params,
      splitMirrorOrigin,
      sessionId,
      [QUERY_PAYLOAD_FIELD_ENTRY_ID]: entryId,
      [QUERY_PAYLOAD_FIELD_OPERATION_ID]: operationId,
      [QUERY_PAYLOAD_FIELD_IDEMPOTENCY_KEY]: idempotencyKey,
      [QUERY_PAYLOAD_FIELD_MIGRATION_OPERATION]: migrationOperation,
      [QUERY_PAYLOAD_FIELD_MIGRATION_ID]: migrationId,
      [QUERY_RESULT_REQUEST_FIELD.DEADLINE_MS]: resultDeadlineMs,
      [QUERY_RESULT_REQUEST_FIELD.MAX_BYTES]: resultMaxBytes,
      [QUERY_RESULT_REQUEST_FIELD.MAX_ROWS]: resultMaxRows,
    } = payload;
    if (!sql) {
      return {
        acknowledged: false,
        error: PARTITION_SERVICE_ERROR_MSG.MISSING_SQL_QUERY,
      };
    }
    const isWriteOperation = this.isWriteQuery(sql);
    if (isWriteOperation) {
      const epochRejection = this.rejectStalePartitionEpochWrite(
        payload[QUERY_PAYLOAD_FIELD_EXPECTED_PARTITION_VERSION],
      );
      if (epochRejection) {
        return epochRejection;
      }
    }
    if (isWriteOperation && this.role !== RaftRole.LEADER) {
      const leaderAddress = this.resolveLeaderAddress();
      if (leaderAddress) {
        this.logger.debug(
          PARTITION_SERVICE_LOG_MSG.REDIRECTING_WRITE_TO_LEADER,
          {
            partitionId: this.partitionId,
            replicaId: this.replicaId,
            leaderAddress,
          },
        );
        return {
          acknowledged: true,
          success: false,
          redirect: PARTITION_SERVICE_RESPONSE.LEADER_REDIRECT,
          leaderAddress,
          partitionId: this.partitionId,
        };
      }
      return {
        acknowledged: true,
        success: false,
        error: ERRORS.NO_LEADER_AVAILABLE_FOR_WRITE,
        // Typed as the write kernel types it: not proposed here.
        failureCode: PARTITION_WRITE_LEADERSHIP_REFUSAL.NOT_LEADER,
        partitionId: this.partitionId,
      };
    }
    const participantAnswer = answerParticipantSessionQuery(this, payload);
    if (participantAnswer !== null) return participantAnswer;
    const readAuthorityWitness =
      this.buildRemoteReadAuthorityWitness(isWriteOperation);
    this.logger.debug(PARTITION_SERVICE_LOG_MSG.HANDLING_REMOTE_QUERY, {
      sql: sql.substring(
        0,
        PARTITION_SERVICE_VALUE.DEFAULT_QUERY_TIMEOUT_MS,
      ),
      partitionId: this.partitionId,
      replicaId: this.replicaId,
    });
    try {
      let result = null;
      if (
        migrationOperation === PARTITION_SERVICE_MIGRATION_OPERATION.ALTER_TABLE
      ) {
        result = await this.executeMigrationAlterQuery(sql, params || [], {
          migrationId: migrationId || null,
          sessionId: sessionId || null,
        });
      } else {
        result = await this.executeQuery(sql, params || [], {
          entryId: entryId || null,
          operationId: operationId || null,
          idempotencyKey: idempotencyKey || null,
          splitMirrorOrigin: splitMirrorOrigin || null,
          sessionId: sessionId || null,
          resultDeadlineMs,
          resultMaxBytes,
          resultMaxRows,
        });
      }
      // A routed write can come back rejected without throwing (for example
      // NO_LEADER when a stale-topology commit guard refuses a unilateral
      // apply). The envelope must carry that outcome — collapsing it to
      // success acks a write that never landed and the coordinator stops
      // re-routing to the true leader.
      const resultSuccess = result?.success !== false;
      return {
        acknowledged: true,
        success: resultSuccess,
        ...(resultSuccess || !result?.error ? {} : {error: result.error}),
        ...(resultSuccess || !result?.errorCode ?
          {} :
          {errorCode: result.errorCode}),
        // What is known of a write that did not succeed crosses this hop as
        // its typed fields - its code and the entry it was proposed under
        // among them - never as its text alone: a caller re-delivers an
        // unknown outcome only under that entryId.
        ...(resultSuccess ? {} : pickTypedWriteAnswer(result)),
        rows: result.rows,
        changes: result.changes,
        // A settled replay names itself (PARTITION_SETTLED_REPLAY): with an
        // unknown count it carries no `changes`, and the router's caller
        // decides on the named state, never on the absent count.
        ...(result?.settledReplay === undefined ? {} :
          {settledReplay: result.settledReplay}),
        count: result.count,
        partitionId: this.partitionId,
        durableCommitWitness: result.durableCommitWitness,
        originHlc: result.originHlc,
        acceptingNodeId: result.acceptingNodeId,
        acknowledgedAtMs: result.acknowledgedAtMs,
        readAuthorityWitness,
      };
    } catch (error) {
      this.logger.error(PARTITION_SERVICE_ERROR_MSG.REMOTE_QUERY_FAILED, {
        sql: sql.substring(
          0,
          PARTITION_SERVICE_VALUE.DEFAULT_QUERY_TIMEOUT_MS,
        ),
        error: error.message,
        partitionId: this.partitionId,
      });
      return {
        acknowledged: true,
        success: false,
        error: error.message,
        errorCode: error.code || null,
        partitionId: this.partitionId,
      };
    }
  }
  /**
   * Execute one migration ALTER TABLE request through the Raft write path.
   * @param {string} sql - ALTER TABLE SQL.
   * @param {Array} params - SQL params.
   * @param {Object} options - Migration context.
   * @return {Promise<Object>} Execution result.
   * @private
   */
  async executeMigrationAlterQuery(sql, params = [], options = {}) {
    if (!sql) {
      throw new Error(PARTITION_SERVICE_ERROR_MSG.MIGRATION_ALTER_MISSING_SQL);
    }
    const protectedSchema = coordinatorTableSchemaRefusal(this.tableName);
    if (protectedSchema !== null) {
      return {...protectedSchema, partitionId: this.partitionId};
    }
    this.registerMigrationDefaultFromAlterSql(sql);
    return this.proposeWrite({
      type: PARTITION_SERVICE_OPERATION.MIGRATION_ALTER_TABLE,
      sql,
      params,
      migrationId: options.migrationId || null,
      sessionId: options.sessionId || null,
    });
  }
  /**
   * Parse and register one column default from ALTER TABLE ADD COLUMN SQL.
   * @param {string} sql - ALTER TABLE SQL.
   * @return {void}
   * @private
   */
  registerMigrationDefaultFromAlterSql(sql) {
    const parsed = this.parseAddColumnDefaultFromAlterSql(sql);
    if (!parsed || !parsed.columnName || !parsed.hasDefault) {
      return;
    }
    const tableKey = String(this.tableName || this.tableId || '');
    if (!tableKey) {
      return;
    }
    let columnDefaults = this.migrationColumnDefaultsByTable.get(tableKey);
    if (!columnDefaults) {
      columnDefaults = /* @__PURE__ */ new Map();
      this.migrationColumnDefaultsByTable.set(tableKey, columnDefaults);
    }
    columnDefaults.set(parsed.columnName, parsed.defaultLiteral);
    this.logger.info(PARTITION_SERVICE_LOG_MSG.MIGRATION_DEFAULT_REGISTERED, {
      partitionId: this.partitionId,
      tableName: tableKey,
      columnName: parsed.columnName,
    });
  }
  /**
   * Extract one default literal from ALTER TABLE ... ADD COLUMN SQL.
   * @param {string} sql - ALTER TABLE SQL.
   * @return {Object|null} Parsed default metadata.
   * @private
   */
  parseAddColumnDefaultFromAlterSql(sql) {
    const normalizedSql = String(sql || '');
    const addColumnMatch = normalizedSql.match(
      /^\s*ALTER\s+TABLE\s+.+?\s+ADD\s+COLUMN\s+([^\s]+)\s+([\s\S]+)$/i,
    );
    if (!addColumnMatch) {
      return null;
    }
    const columnName = String(addColumnMatch[1] || '').replace(
      /^["'`]|["'`]$/g,
      '',
    );
    const definitionTail = String(addColumnMatch[2] || '');
    const defaultMatch = definitionTail.match(
      /\bDEFAULT\s+((?:'[^']*'|"[^"]*"|`[^`]*`|[^\s,]+))/i,
    );
    return {
      columnName,
      hasDefault: defaultMatch !== null,
      defaultLiteral: defaultMatch ? defaultMatch[1] : null,
    };
  }
  /**
   * Check if a SQL query is a write operation.
   * @param {string} sql - SQL query string.
   * @return {boolean} True if write operation.
   * @private
   */
  isWriteQuery(sql) {
    if (!sql) return false;
    const trimmed = sql.trim().toUpperCase();
    return (
      trimmed.startsWith(PARTITION_SERVICE_LITERAL.INSERT) ||
      trimmed.startsWith(PARTITION_SERVICE_LITERAL.UPDATE) ||
      trimmed.startsWith(PARTITION_SERVICE_LITERAL.DELETE) ||
      trimmed.startsWith(PARTITION_SERVICE_LITERAL.CREATE) ||
      trimmed.startsWith(PARTITION_SERVICE_LITERAL.DROP) ||
      trimmed.startsWith(PARTITION_SERVICE_LITERAL.ALTER)
    );
  }
  /**
   * Advance the partition HLC to witness a committed entry's timestamp.
   * Idempotent (the clock takes the max), guarded against a missing/unparseable
   * timestamp (some committed command types legitimately carry none), and never
   * allowed to throw out of the apply path.
   * @param {Object} command - The committed command (may carry a `timestamp` HLC).
   */
  witnessCommandHlc(command) {
    try {
      const witnessed = HLCTimestamp.tryFromString(command?.timestamp);
      if (witnessed) {
        this.hlcClock.update(witnessed);
      }
    } catch (_error) {
      // Witnessing the clock must never break entry application.
    }
  }

  /**
   * The proposer's commit identity for one committed write: its position in
   * the log and, on the replica that proposed it (the only one holding the
   * pending write), the durable commit witness built from the committed
   * entry itself.
   * @param {Object} command - The committed command.
   * @param {number} index - The committed entry's index.
   * @param {number} term - The committed entry's term.
   * @return {Object} Fields merged into the resolved write result.
   * @private
   */
  buildCommittedWriteIdentity(command, index, term) {
    const originHlc =
      typeof command?.timestamp === 'string' && command.timestamp.length > 0 ?
        command.timestamp : null;
    if (command.proposedBy !== this.replicaId) {
      return {
        partitionId: this.partitionId,
        logIndex: index,
        ...(originHlc ? {originHlc} : {}),
      };
    }
    return {
      partitionId: this.partitionId,
      logIndex: index,
      ...(originHlc ? {originHlc} : {}),
      durableCommitWitness: buildDurableCommitWitness({
        partitionId: this.partitionId,
        leaderNodeId: this.nodeId,
        leaderReplicaId: command.proposedBy,
        logEntry: {term, index, data: command},
      }),
    };
  }

  /**
   * Apply one committed entry to the state machine. The consensus port calls
   * this inside the SQLite transaction that also advances its applied state;
   * every observable effect is deferred to `effects.afterCommit` (or
   * `effects.afterRollback`) so nothing escapes a rolled-back apply.
   * @param {Object} committed - The frozen committed record.
   * @param {Object} committed.command - The decoded committed command.
   * @param {number} committed.index - The entry's log index.
   * @param {number} committed.term - The entry's term.
   * @param {{afterCommit: Array, afterRollback: Array}} committed.effects
   * @return {string} A PARTITION_COMMITTED_COMMAND_OUTCOME.
   */
  applyCommittedEntry({command, index, term, effects, committedConfiguration}) {
    const scheduleEffect = (phase, effect) => {
      effects[phase].push(() => {
        try {
          effect();
        } catch (error) {
          this.logger.error(
            PARTITION_SERVICE_ERROR_MSG.COMMITTED_ENTRY_EFFECT_FAILED,
            {partitionId: this.partitionId, logIndex: index, phase,
              error: error.message},
          );
        }
      });
    };
    const commandType = command?.type;
    // Only a bug or version skew commits one (the admission owner never
    // proposes it); consuming it silently would let this replica skip what
    // another applies, so the application fails closed, typed: the group's
    // host failure names the reason, the index and the type.
    if (!isCommittedCommandType(commandType)) {
      const error = new Error(
        `${PARTITION_SERVICE_ERROR_MSG.COMMITTED_COMMAND_UNRECOGNISED}: ` +
        `${JSON.stringify(commandType)} at index ${index}`);
      error.code = PARTITION_COMMITTED_COMMAND_ERROR_CODE.UNRECOGNISED;
      error.outcome = PARTITION_COMMITTED_COMMAND_OUTCOME.UNRECOGNISED;
      error.reason = PARTITION_COMMITTED_COMMAND_HOST_FAILURE_REASON
        .COMMAND_UNKNOWN;
      error.detail = Object.freeze({index, commandType: commandType ?? null});
      scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.ROLLBACK, () =>
        this.rejectCommittedWrite(command?.entryId, error),
      );
      throw error;
    }
    // Witness the committed entry's HLC on EVERY replica (leader and follower),
    // before any branch/early-return, so this clock advances past every entry it
    // applies. Without this, a new leader whose wall clock lags the old leader
    // could stamp a later write (e.g. a DELETE) with a LOWER HLC than an earlier
    // committed write, breaking cross-leader monotonicity used as an LWW fence.
    scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.COMMIT, () =>
      this.witnessCommandHlc(command),
    );
    this.logger.debug(PARTITION_SERVICE_LOG_MSG.APPLYING_COMMITTED_ENTRY, {
      partitionId: this.partitionId,
      commandType,
    });
    if (commandType === COORDINATOR_SETTLEMENT_TYPE) {
      return applyCoordinatorSettlement(this, {command, index, term,
        afterCommit: (effect) => scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.COMMIT, effect),
        afterRollback: (effect) => scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.ROLLBACK, effect)});
    }
    if (isCommittedSqlCommandType(commandType)) {
      if (command.sql) {
        assertTransactionSchemaWriteEnforced(this.db, this.tableName,
          readPartitionWriteOrigin(this.db) !== null);
        const entryKey = this.getCommittedEntryKey(command);
        const identity = this.buildCommittedWriteIdentity(command, index, term);
        const afterCommit = (effect) =>
          scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.COMMIT, effect);
        // The recorded outcome of this entry key decides whether the
        // statement runs: a settled key is never executed again, on any
        // replica, before or after a restart.
        const recorded = readCommittedStatementOutcome(this, entryKey);
        if (recorded.state ===
            PARTITION_COMMITTED_STATEMENT_RECORD_STATE.SETTLED) {
          return settleRecordedCommittedStatement(this, {
            recorded, command, afterCommit});
        }
        // A PREPARED participant transaction holds every other statement.
        if (isPartitionReserved(this.db)) {
          return settleReservedCommittedStatement(this, {command, afterCommit});
        }
        let info;
        try {
          info = runCommittedPartitionStatement(this, command);
        } catch (error) {
          return settleFailedCommittedStatement(this, {
            error, command, entryKey, index, term, identity, afterCommit,
            afterRollback: (effect) =>
              scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.ROLLBACK, effect),
          });
        }
        recordCommittedStatementOutcome(this, {
          entryKey,
          outcome: PARTITION_COMMITTED_COMMAND_OUTCOME.APPLIED,
          index,
          term,
          result: info,
        });
        recordCommittedStatementCdc(this, {command, index, term, afterCommit},
          {entryKey, result: info});
        advancePartitionWriteGeneration(this.db);
        if (command.type === PARTITION_SERVICE_OPERATION.MIGRATION_ALTER_TABLE) {
          afterCommit(() => this.registerMigrationDefaultFromAlterSql(command.sql));
        }
        afterCommit(() => {
          this.resolveCommittedWrite(command.entryId, {
            success: true,
            changes: info.changes,
            lastInsertRowid: info.lastInsertRowid,
            ...identity,
          });
        });
      }
    } else if (isCdcCommandType(commandType)) {
      // The CDC delivery owner's committed acknowledgement: its owner.
      return applyCdcAcknowledgementCommand(this, {command, index, term,
        afterCommit: (effect) => scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.COMMIT, effect),
        afterRollback: (effect) => scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.ROLLBACK, effect)});
    } else {
      // A transaction command (participant, or a legacy marker): its owner.
      return applyCommittedTransactionCommand(this, {command, index, term,
        committedConfiguration,
        afterCommit: (effect) => scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.COMMIT, effect),
        afterRollback: (effect) => scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.ROLLBACK, effect)});
    }
    scheduleEffect(COMMIT_APPLY_EFFECT_PHASE.COMMIT, () =>
      this.emit(PARTITION_SERVICE_EVENT.ENTRY_COMMITTED, {
        partitionId: this.partitionId,
        command,
      }),
    );
    // A statement was applied; a write type without a statement is recorded
    // in the log only.
    return command.sql ? PARTITION_COMMITTED_COMMAND_OUTCOME.APPLIED :
      PARTITION_COMMITTED_COMMAND_OUTCOME.RECORDED_ONLY;
  }
}
Object.assign(
  PartitionServiceEntryApplyBase.prototype,
  createPartitionServiceTransactionSessionMethods(),
);
export {PartitionServiceEntryApplyBase};
