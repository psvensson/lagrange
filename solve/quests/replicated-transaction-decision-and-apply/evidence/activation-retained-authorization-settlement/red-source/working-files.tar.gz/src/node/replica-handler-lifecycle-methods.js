/**
 * ReplicaHandler lifecycle + message dispatch methods.
 *
 * Owns initialization and the inbound message router entrypoint that fans
 * out to the create / remove / step-down request handlers.
 *
 * Requirements: 10.2, 3.1
 */
import {
  ReplicaOperationField,
  ReplicaOperationMessageType,
  ReplicaOperationResponseStatus,
} from '../rebalancer/replica-operation-constants.js';
import {OperationType} from '../rebalancer/replica-status.js';
import {CREATE_ADMISSION_ERROR_CODE} from
  './replica-create-admission-owner.js';
import {
  REPLICA_HANDLER_DEFAULT,
  REPLICA_HANDLER_ERROR_MSG,
  REPLICA_HANDLER_LOG_MSG,
} from './replica-handler-constants.js';
import {PARTICIPANT_RELEASE_ACTION, PARTICIPANT_RELEASE_RESULT_FIELD,
  PARTICIPANT_RELEASE_TYPE} from
  '../partition/partition-participant-transaction-cutover-constants.js';
import {receiveParticipantRelease} from './replica-handler-participant-release.js';
import {runParticipantCutover} from './replica-handler-participant-cutover.js';

const LOCAL_STR_CONSTRUCTOR = 'constructor';
const CREATE_ADMISSION_RECOVERY_NOT_STARTED = false;

function invalidCreateOperationResponse(handler) {
  return handler.buildReplicaOperationResponse(
    ReplicaOperationResponseStatus.ERROR,
    {
      error: REPLICA_HANDLER_ERROR_MSG.CREATE_OPERATION_TYPE_REQUIRED,
      errorCode: CREATE_ADMISSION_ERROR_CODE.INVALID,
      nodeId: handler.nodeId,
    },
  );
}

async function dispatchCreateReplicaMessage(handler, payload) {
  const operationType = payload?.[ReplicaOperationField.OPERATION_TYPE];
  const valid = operationType === OperationType.ADD ||
    operationType === OperationType.REPLACE;
  return valid ? handler.handleCreateReplica(payload) :
    invalidCreateOperationResponse(handler);
}

async function dispatchReplicaMessage(handler, type, payload) {
  switch (type) {
  case ReplicaOperationMessageType.CREATE_REPLICA:
    return dispatchCreateReplicaMessage(handler, payload);
  case ReplicaOperationMessageType.REMOVE_REPLICA:
    return handler.handleRemoveReplica(payload);
  case ReplicaOperationMessageType.STEP_DOWN_REPLICA:
    return handler.handleStepDownReplica(payload);
  case ReplicaOperationMessageType.READ_REPLICA_MEMBERSHIP:
    return handler.handleReadReplicaMembership(payload);
  case ReplicaOperationMessageType.RETIRE_REPLICA_PEER:
    return handler.handleRetireReplicaPeer(payload);
  case ReplicaOperationMessageType.READ_COMMITTED_MEMBERSHIP:
    return handler.handleReadCommittedMembership(payload);
  default:
    return handler.buildReplicaOperationResponse(
      ReplicaOperationResponseStatus.ERROR,
      {error: REPLICA_HANDLER_ERROR_MSG.UNKNOWN_MESSAGE_TYPE(type)},
    );
  }
}

function assignReplicaHandlerLifecycleMethods(ReplicaHandler) {
  class ReplicaHandlerLifecycleMethods {
    /**
     * Initialize the replica handler.
     */
    initialize() {
      if (this.initialized) {
        return;
      }
      this.logger.info(REPLICA_HANDLER_LOG_MSG.INITIALIZING, {
        nodeId: this.nodeId,
        dataDir: this.dataDir,
      });
      this.initialized = true;
      // Removal-cleanup debt owner (audit finding 12): a failed/stranded
      // replica-removal cleanup must not orphan DB/WAL files indefinitely,
      // so every startup reconciles the partitions directory against
      // authoritative rows via the idempotent reconcile cleanup path.
      this.removedReplicaCleanupAdmissionBarrier =
        this.captureRemovedReplicaCleanupStartupAuthorities();
      this.removedReplicaCleanupDebtSweepTask =
        this.removedReplicaCleanupAdmissionBarrier.then(
          (startupAuthorities) =>
            this.sweepRemovedReplicaCleanupDebt(startupAuthorities),
        ).finally(() => this.watchGroupRetiredTombstones?.()).catch((error) => {
          this.logger.warn(
            REPLICA_HANDLER_LOG_MSG.REMOVED_CLEANUP_SWEEP_FAILED,
            {nodeId: this.nodeId, error: error.message},
          );
        });
      this.startReplicaCreateAdmissionRecovery();
    }

    startReplicaCreateAdmissionRecovery() {
      if (this.shuttingDown) return CREATE_ADMISSION_RECOVERY_NOT_STARTED;
      this.replicaCreateAdmissionRecoveryRearmOwner.cancel();
      const barrier = this.recoverRetainedReplicaCreateAdmissions();
      this.replicaCreateAdmissionRecoveryBarrier = barrier;
      this.replicaCreateAdmissionRecoveryTask = barrier.catch((error) => {
        if (this.shuttingDown) return;
        this.logger.warn(
          REPLICA_HANDLER_LOG_MSG.CREATE_ADMISSION_RECOVERY_FAILED,
          {nodeId: this.nodeId, error: error.message},
        );
        this.replicaCreateAdmissionRecoveryRearmOwner.arm(
          () => this.startReplicaCreateAdmissionRecovery(),
          REPLICA_HANDLER_DEFAULT.CREATE_ADMISSION_RECOVERY_RETRY_MS,
        );
      });
      return barrier;
    }

    async awaitReplicaCreateAdmissionRecoveryBarrier() {
      if (this.replicaCreateAdmissionRecoveryBarrier) {
        await this.replicaCreateAdmissionRecoveryBarrier;
      }
    }
    /**
     * Handle incoming message (called by message router).
     * @param {Object} envelope - Message envelope.
     * @return {Promise<Object>} Response.
     */
    async handleMessage(envelope) {
      const {payload, correlationId} = envelope;
      const type = payload?.[ReplicaOperationField.TYPE];
      // Release fact reads and admission closure must remain reachable before
      // registration. Storage-changing lifecycle work still waits for its own
      // retained-storage admission inside the release recipient.
      if (type === PARTICIPANT_RELEASE_TYPE) {
        const response = payload.action === PARTICIPANT_RELEASE_ACTION.RELEASE ?
          await runParticipantCutover(this, payload) :
          await receiveParticipantRelease(this, payload);
        return {acknowledged: true,
          [PARTICIPANT_RELEASE_RESULT_FIELD]: response, correlationId};
      }
      await this.awaitRemovedReplicaCleanupAdmissionBarrier();
      this.logger.debug(REPLICA_HANDLER_LOG_MSG.MESSAGE_RECEIVED, {
        type,
        correlationId,
        operationId: payload?.operationId,
      });
      const response = await dispatchReplicaMessage(this, type, payload);
      // Include correlationId in response for RPC matching; a request's
      // attempt sequence is echoed so the requester drops a late answer of
      // an earlier attempt.
      const attemptSeq = payload?.[ReplicaOperationField.ATTEMPT_SEQ];
      return {
        ...response,
        ...(attemptSeq === undefined ? {} :
          {[ReplicaOperationField.ATTEMPT_SEQ]: attemptSeq}),
        correlationId,
      };
    }
  }
  for (const methodName of Object.getOwnPropertyNames(
    ReplicaHandlerLifecycleMethods.prototype,
  )) {
    if (methodName === LOCAL_STR_CONSTRUCTOR) {
      continue;
    }
    Object.defineProperty(
      ReplicaHandler.prototype,
      methodName,
      Object.getOwnPropertyDescriptor(
        ReplicaHandlerLifecycleMethods.prototype,
        methodName,
      ),
    );
  }
}

export {assignReplicaHandlerLifecycleMethods};
