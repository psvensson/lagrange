import {PARTITION_SERVICE_SHARED} from './partition-service-shared.js';
import {trackSyncSection} from '../diagnostics/event-loop-gap-watchdog.js';
import {
  RAFT_OPERATION_OUTCOME,
} from '../raft/raft-operation-port-constants.js';

// Watchdog sync-section site for the closed-handle partition replica boot
// block (round-10 bootstrap-batch stall attribution).
const PARTITION_REPLICA_INIT_SYNC_SECTION_SITE = 'partition_replica_init';
import {isCatchupLearnerRaftRole} from '../raft/replica-voter-readiness.js';
import {
  isBootstrapPeerAdmissible,
  reconcileRaftPeersFromCacheForService,
  redriveAdmissionsOnMembershipChange,
} from './partition-service-raft-peer-cache-reconciliation.js';
import {admitPartitionRaftPeer} from
  './partition-service-raft-membership-administration.js';
import {
  relayPartitionConsensusObservations,
  wirePartitionRaftLifecycleEvents,
} from './partition-service-raft-lifecycle-wiring.js';
import {PartitionServiceCoreBase} from './partition-service-core-base.js';
import {warmHlcFromDurableWitnesses} from './partition-hlc-warmup.js';
import {
  createPartitionServiceTable,
} from './partition-service-table-bootstrap.js';
import {
  resolvePendingSnapshotInstall,
  resolveReplicaCheckpointsRoot,
} from '../raft/snapshot-install.js';
import {RAFT_EVENT} from '../raft/constants.js';
import {
  RAFT_OPERATION_PORT_REQUEST,
  hostedConsensusSubstrate,
} from '../raft/raft-operation-port-request.js';
import {RAFT_SNAPSHOT_INSTALL_OUTCOME} from '../raft/snapshot-install-constants.js';
import {
  cleanupStaleTransferStaging,
} from '../raft/snapshot-transfer-receiver.js';
import {
  createPartitionSnapshotCadence,
} from './partition-snapshot-cadence.js';
import {
  detectLegacyPartitionConsensusState,
  legacyPartitionConsensusStateError,
} from './partition-legacy-consensus-state.js';
import {
  LEGACY_PARTITION_CONSENSUS_OUTCOME,
} from './partition-legacy-consensus-state-constants.js';
import {
  consensusInitRefusedError,
  openPartitionConsensusPort,
} from './partition-consensus-port-opening.js';
import {createCommittedStatementOutcomeTable} from
  './partition-committed-statement-outcome.js';
import {openParticipantTransactionStore} from
  './partition-participant-transaction-store.js';
import {isHeldByHostFailure} from './partition-write-kernel.js';
import {admitParticipantReleaseProposalDispatch} from
  './partition-participant-release-dispatch-admission.js';
import {REPLICA_DB_PRAGMA} from '../storage/storage-constants.js';

const {
  AddressManager,
  CANONICAL_PARTITION_LEADER_OBSERVATION_STATE,
  COLUMN,
  CONFIG_KEY,
  ConfigurationManager,
  Database,
  ENTITY_TYPE,
  PARTITION_SERVICE_ADDRESS,
  PARTITION_SERVICE_DEFAULT,
  PARTITION_SERVICE_ERROR_MSG,
  PARTITION_SERVICE_EVENT,
  PARTITION_SERVICE_INIT_STAGE,
  PARTITION_SERVICE_LEARNER_PROMOTION_SCHEDULE_REASON,
  PARTITION_SERVICE_LOG_MSG,
  PARTITION_SERVICE_ROLE,
  PARTITION_SERVICE_TYPE,
  PARTITION_SERVICE_VALUE,
  RaftRole,
  ReplicaStatus,
  SERVICE_TYPE,
  TABLES,
  assertCritical,
  computeReplicaElectionTimeouts,
  fs,
  path,
  resolveCanonicalPartitionLeaderObservation,
  resolveRaftTransportDeliveryOptions,
} = PARTITION_SERVICE_SHARED;

class PartitionServiceRaftInitBase extends PartitionServiceCoreBase {
  /**
   * One checkpoint-cadence tick, driven by the 1s prepared-state-hold sweep
   * (S6 Phase A link 1). The cadence owner holds the leader-only role gate
   * and the in-flight flag — the sweep only provides the heartbeat. Lazily
   * constructed so guard-injected services without raft state stay inert.
   * The returned promise NEVER rejects (typed outcomes only).
   * @param {number} nowMs sweep timestamp (nowMs-overridable in guards)
   * @return {Promise<Object>} typed frozen cadence tick result
   */
  runSnapshotCadenceTick(nowMs) {
    if (!this.snapshotCadence) {
      this.snapshotCadence = createPartitionSnapshotCadence({service: this});
    }
    return this.snapshotCadence.tick(nowMs);
  }

  /**
   * Resolve the current raft term when a live raft instance exists; the
   * leadership-state helper passes it with the leadership event so the
   * owner-local canonical leader projection can mint a tenure claim. A null
   * return simply mints no claim — fail-closed.
   * @return {number|null}
   */
  resolveCurrentTermSafe() {
    if (!this.raft) {
      return null;
    }
    try {
      const term = Number(this.raft.readStatus().term);
      return Number.isFinite(term) ? term : null;
    } catch {
      return null;
    }
  }

  /**
   * Join newly visible peers and replace moved peer addresses using the
   * authoritative services cache. Missing rows are ignored conservatively.
   * @private
   */
  reconcileRaftPeersFromCache() {
    reconcileRaftPeersFromCacheForService(this);
  }
  /**
   * Read one system table row from the local cache when present.
   * @param {string} tableName
   * @param {Function} predicate
   * @return {Object|null}
   * @private
   */
  getCachedSystemTableRow(tableName, predicate) {
    if (!this.systemTableCache || typeof predicate !== 'function') {
      return null;
    }
    if (typeof this.systemTableCache.filter === 'function') {
      const rows = this.systemTableCache.filter(tableName, predicate);
      return rows[0] || null;
    }
    if (typeof this.systemTableCache.getAll === 'function') {
      const rows = this.systemTableCache.getAll(tableName) || [];
      return rows.find(predicate) || null;
    }
    return null;
  }
  /**
   * Read matching system table rows from the local cache when present.
   * @param {string} tableName
   * @param {Function} predicate
   * @return {Array<Object>}
   * @private
   */
  getCachedSystemTableRows(tableName, predicate) {
    if (!this.systemTableCache || typeof predicate !== 'function') {
      return [];
    }
    if (typeof this.systemTableCache.filter === 'function') {
      return this.systemTableCache.filter(tableName, predicate);
    }
    if (typeof this.systemTableCache.getAll === 'function') {
      const rows = this.systemTableCache.getAll(tableName) || [];
      return rows.filter(predicate);
    }
    return [];
  }
  /**
   * Resolve the current leader replica from canonical owner-row metadata.
   * Owner rows are the only canonical leader truth for partition routing; if
   * leader_node_id is missing or stale, fail closed instead of deriving from
   * services.raft_role.
   * @return {string|null}
   * @private
   */
  resolveLeaderIdFromMetadata() {
    const serviceRows = this.getCachedSystemTableRows(
      TABLES.SERVICES,
      (service) =>
        service?.[COLUMN.PARTITION_ID] === this.partitionId &&
        service?.[COLUMN.SERVICE_TYPE] === SERVICE_TYPE.PARTITION &&
        service?.[COLUMN.STATUS] !== ReplicaStatus.FAILED &&
        service?.[COLUMN.STATUS] !== ReplicaStatus.REMOVED,
    );
    if (serviceRows.length === 0) {
      return null;
    }
    const resolveLeaderReplicaId = (leaderNodeId) => {
      if (
        typeof leaderNodeId !== 'string' ||
        leaderNodeId.length === 0
      ) {
        return null;
      }
      const leaderReplica = serviceRows.find(
        (service) => service?.[COLUMN.NODE_ID] === leaderNodeId,
      );
      const leaderReplicaId =
        leaderReplica?.[COLUMN.REPLICA_ID] ||
        leaderReplica?.[COLUMN.SERVICE_ID] ||
        null;
      return typeof leaderReplicaId === 'string' &&
        leaderReplicaId.length > 0 ?
        leaderReplicaId :
        null;
    };
    const partitionRow = this.getCachedSystemTableRow(
      TABLES.PARTITIONS,
      (partition) => partition?.[COLUMN.PARTITION_ID] === this.partitionId,
    );
    const leaderObservation = resolveCanonicalPartitionLeaderObservation({
      partition: partitionRow,
      partitionPresent: partitionRow !== null,
      serviceRows,
    });
    if (
      leaderObservation?.state !==
      CANONICAL_PARTITION_LEADER_OBSERVATION_STATE.AVAILABLE
    ) {
      return null;
    }
    return resolveLeaderReplicaId(leaderObservation?.leaderNodeId);
  }
  /**
   * Seed leader identity from the startup leader-address hint when joining
   * an already-established group. Stable joins may not observe a fresh Raft
   * leader-change event before learner promotion needs to run.
   * @return {string|null}
   * @private
   */
  resolveLeaderIdFromHint() {
    if (!this.leaderAddressHint) {
      return null;
    }
    try {
      const parsed = AddressManager.getInstance().parse(this.leaderAddressHint);
      return parsed.serviceType === ENTITY_TYPE.PARTITION ?
        parsed.serviceId :
        null;
    } catch (_parseErr) {
      return null;
    }
  }
  /**
   * Report partition initialization progress stage.
   * @param {string} stage - Initialization stage.
   * @param {Object} details - Additional stage details.
   * @private
   */
  reportInitializationStage(stage, details = {}) {
    if (!this.onInitializationStage) {
      return;
    }
    try {
      this.onInitializationStage({
        stage,
        partitionId: this.partitionId,
        replicaId: this.replicaId,
        ...details,
      });
    } catch (error) {
      this.logger.warn(PARTITION_SERVICE_LOG_MSG.INIT_STAGE_CALLBACK_FAILED, {
        partitionId: this.partitionId,
        replicaId: this.replicaId,
        stage,
        error: error.message,
      });
    }
  }
  /**
   * Warm the partition HLC from the maximum HLC over the committed commands of
   * the rs-raft durable store, so a restarted node never emits an HLC below one
   * it previously committed. One-time full scan of the committed prefix at
   * init. NOTE: the rs-raft log is not compacted, so this is
   * O(committed-log-size); it is acceptable because init is not re-entered.
   * A database without the rs-raft record is a no-op; an undecodable
   * committed command fails init closed (the durable log is not trustworthy).
   */
  warmHlcFromCommittedLog() {
    warmHlcFromDurableWitnesses({
      service: this,
      hlcClock: this.hlcClock,
    });
  }
  /**
   * Initialize the partition service.
   * Opens the partition's raft-rs consensus port over its durable store.
   * Requirements: 8.1, 10.1, 10.2, 10.3, 10.4, 10.5
   * @return {Promise<void>}
   */
  async initialize() {
    if (this.initialized) {
      return;
    }
    this.reportInitializationStage(PARTITION_SERVICE_INIT_STAGE.STARTING, {
      partitionId: this.partitionId,
      tableId: this.tableId,
      replicaId: this.replicaId,
      nodeId: this.nodeId,
      replicaCount: this.replicaIds.length,
      dbPath: this.dbPath,
    });
    if (!this.suppressLifecycleLogs) {
      this.logger.info(PARTITION_SERVICE_LOG_MSG.INITIALIZING, {
        partitionId: this.partitionId,
        tableId: this.tableId,
        replicaId: this.replicaId,
        nodeId: this.nodeId,
        replicaCount: this.replicaIds.length,
        dbPath: this.dbPath,
      });
    }
    // The whole closed-handle boot block (dir/snapshot fs work, db open +
    // pragmas, legacy-state refusal, schema DDL) is synchronous by design; tag it
    // so bootstrap-batch stalls attribute in the watchdog's siteDeltas
    // instead of reporting as unexplained gaps (round-10).
    trackSyncSection(PARTITION_REPLICA_INIT_SYNC_SECTION_SITE, () => {
      if (this.dbPath !== PARTITION_SERVICE_DEFAULT.MEMORY_DB_PATH) {
        const dbDir = path.dirname(this.dbPath);
        if (!fs.existsSync(dbDir)) {
          fs.mkdirSync(dbDir, {recursive: true});
          this.logger.debug(PARTITION_SERVICE_LOG_MSG.CREATED_PARTITION_DIR, {
            path: dbDir,
          });
        }
      }
      // Snapshot-install boot boundary: resolve pending install remnants
      // while NO handle is open; a nonce conflict fails the boot closed.
      if (this.dbPath !== PARTITION_SERVICE_DEFAULT.MEMORY_DB_PATH) {
        const installResolution = resolvePendingSnapshotInstall({
          replicaDbPath: this.dbPath,
        });
        if (installResolution.outcome ===
            RAFT_SNAPSHOT_INSTALL_OUTCOME.INSTALL_STATE_CONFLICT) {
          throw new Error(
            `${PARTITION_SERVICE_ERROR_MSG.SNAPSHOT_INSTALL_STATE_CONFLICT}: ` +
            `${installResolution.detail}`,
          );
        }
        // Recorded-gap closure (S4): sweep stale transfer staging at the
        // same closed-handle boot boundary — no transfer is in flight
        // during init, so every staged transfer directory here is a
        // leftover.
        cleanupStaleTransferStaging(
          resolveReplicaCheckpointsRoot(this.dbPath));
      }
      this.reportInitializationStage(PARTITION_SERVICE_INIT_STAGE.OPENING_DB, {
        dbPath: this.dbPath,
      });
      this.db = new Database(this.dbPath);
      this.db.pragma(REPLICA_DB_PRAGMA.JOURNAL_MODE);
      this.db.pragma(REPLICA_DB_PRAGMA.SYNCHRONOUS);
      // Before any DDL and before the port: a database holding the retired
      // backend's consensus state and no rs-raft record is never reused.
      const legacyConsensusState = detectLegacyPartitionConsensusState({
        db: this.db, partitionId: this.partitionId});
      if (legacyConsensusState.outcome ===
          LEGACY_PARTITION_CONSENSUS_OUTCOME.DETECTED) {
        this.db.close();
        this.db = null;
        throw legacyPartitionConsensusStateError(
          legacyConsensusState, this.partitionId);
      }
      this.createTransactionOutcomeTable();
      createCommittedStatementOutcomeTable(this.db);
      openParticipantTransactionStore(this.db);
      if (this.schema) {
        this.createTable();
      }
    });
    if (this.transport) {
      // Kept as this replica's exact handler identity (owner decision N2).
      this.transportHandler = this.handleTransportMessage.bind(this);
      this.transport.register(this.unifiedAddress, this.transportHandler);
    }
    this.role = RaftRole.FOLLOWER;
    const config = ConfigurationManager.getInstance();
    const heartbeatMs =
      config.get(CONFIG_KEY.RAFT_HEARTBEAT_INTERVAL_MS) ||
      PARTITION_SERVICE_VALUE.RAFT_HEARTBEAT_DEFAULT_MS;
    const baseElectionMinMs =
      config.get(CONFIG_KEY.RAFT_ELECTION_TIMEOUT_MIN_MS) ||
      PARTITION_SERVICE_VALUE.RAFT_ELECTION_MIN_DEFAULT_MS;
    const baseElectionMaxMs =
      config.get(CONFIG_KEY.RAFT_ELECTION_TIMEOUT_MAX_MS) ||
      PARTITION_SERVICE_VALUE.RAFT_ELECTION_MAX_DEFAULT_MS;
    const tickIntervalMs = config.get(CONFIG_KEY.RAFT_TICK_INTERVAL_MS);
    const {electionMinMs, electionMaxMs} = computeReplicaElectionTimeouts({
      replicaId: this.replicaId,
      replicaIds: this.replicaIds,
      baseElectionMinMs,
      baseElectionMaxMs,
      electionJitterPerReplicaMs:
        PARTITION_SERVICE_VALUE.ELECTION_JITTER_PER_REPLICA_MS,
    });
    this.raftTimingConfig = {
      heartbeatMs,
      baseElectionMinMs,
      baseElectionMaxMs,
      electionMinMs,
      electionMaxMs,
      tickIntervalMs: Number.isFinite(tickIntervalMs) ? tickIntervalMs : null,
    };
    if (this.deferElection) {
      this.logger.debug(
        PARTITION_SERVICE_LOG_MSG.DEFERRING_ELECTION_START,
        {replicaId: this.replicaId, partitionId: this.partitionId},
      );
    }
    // Restart recovery reloads committed state from the durable DB without
    // re-applying entries through applyCommittedEntry, so a fresh HLC clock would
    // not witness already-committed HLCs and could regress below a value this node
    // previously committed. Warm the clock from the max committed HLC on the log.
    this.warmHlcFromCommittedLog();
    // The backend boundary (binding direction addendum §1): the group states
    // its own requirements and the rs-raft backend builds the port. Nothing
    // is read from a global - a backend that needs something absent from
    // this request changes the boundary rather than reaching around it.
    this.raft = await openPartitionConsensusPort(this, {
      [RAFT_OPERATION_PORT_REQUEST.GROUP_ID]: this.partitionId,
      [RAFT_OPERATION_PORT_REQUEST.PEER_ID]: this.replicaId,
      [RAFT_OPERATION_PORT_REQUEST.PEER_ADDRESS]: this.unifiedAddress,
      [RAFT_OPERATION_PORT_REQUEST.BOOTSTRAP_PEER_IDS]: this.replicaIds,
      ...(this.bootstrapMembership === null ? {} : {
        [RAFT_OPERATION_PORT_REQUEST.BOOTSTRAP_MEMBERSHIP]:
          this.bootstrapMembership,
      }),
      [RAFT_OPERATION_PORT_REQUEST.IDENTITY_EXISTED]: this.identityExisted,
      ...(this.identityRecorded === null ? {} : {
        [RAFT_OPERATION_PORT_REQUEST.IDENTITY_RECORDED]:
          this.identityRecorded,
      }),
      [RAFT_OPERATION_PORT_REQUEST.DURABLE_STORAGE]: this.db,
      [RAFT_OPERATION_PORT_REQUEST.TIMING]: this.raftTimingConfig,
      [RAFT_OPERATION_PORT_REQUEST.SUBSTRATE]: hostedConsensusSubstrate(this),
      [RAFT_OPERATION_PORT_REQUEST.DEFER_ELECTION]:
        this.defersElectionScheduling(),
      [RAFT_OPERATION_PORT_REQUEST.SEND_TO_PEER]: (peerAddress, packet) =>
        this.transport.deliver(
          peerAddress,
          packet,
          resolveRaftTransportDeliveryOptions({
            ...packet,
            targetAddress: peerAddress,
          }),
        ),
      [RAFT_OPERATION_PORT_REQUEST.RESOLVE_PEER_ADDRESS]: (address) =>
        this.buildPeerAddress(address),
      // One committed record per applied entry, inside the transaction
      // that also advances the rs-raft applied state.
      [RAFT_OPERATION_PORT_REQUEST.APPLY_COMMITTED_ENTRY]: (committed) =>
        this.applyCommittedEntry(committed),
      [RAFT_OPERATION_PORT_REQUEST.ADMIT_PROPOSAL_DISPATCH]: (command) =>
        admitParticipantReleaseProposalDispatch(this, command),
      [RAFT_OPERATION_PORT_REQUEST.SNAPSHOT_CATCHUP_NEEDED]: (decision) => {
        if (typeof this.onSnapshotCatchupNeeded ===
            PARTITION_SERVICE_TYPE.FUNCTION) {
          this.onSnapshotCatchupNeeded(decision);
        }
      },
    });
    await this.refuseConsensusHeldAtOpen();
    // Committed-prefix divergence witness (quest raft-committed-prefix-
    // conflict-livelock): the follower's consensus core surfaces a poisoned
    // committed prefix exactly once per conflict identity instead of
    // retrying an impossible truncation every heartbeat. Log it as the
    // durable operator-visible signal; repair itself rides the existing
    // typed append-fail -> leader catch-up/install route.
    relayPartitionConsensusObservations(this);
    redriveAdmissionsOnMembershipChange(this);
    this.raft.subscribe(
      RAFT_EVENT.COMMITTED_PREFIX_DIVERGENCE,
      (observation) => {
        this.logger.error(
          PARTITION_SERVICE_LOG_MSG.COMMITTED_PREFIX_DIVERGENCE,
          {
            replicaId: this.replicaId,
            partitionId: this.partitionId,
            ...observation,
          },
        );
      },
    );
    if (this.defersElectionScheduling() && this.raft) {
      this.raft.stopScheduling();
      this.logger.debug(
        PARTITION_SERVICE_LOG_MSG.STOPPED_SCHEDULING_FOR_DEFERRED_ELECTION, {
          replicaId: this.replicaId,
          partitionId: this.partitionId,
        });
    }
    // A demotion the port announces is the core's: a lone leader whose group
    // becomes unusable is announced without a role and must stop leading
    // (its writes are refused, not proposed into a broken group). Only a
    // joining learner's catch-up keeps its learner role. Its ticks keep
    // running: the core decides whether it may campaign (a learner never
    // does), and a replica whose ticks stop keeps a stale leader lease.
    const shouldIgnoreDemotionEvent = (eventName) => {
      const isJoiningLearner =
        this.isJoiningExistingGroup === true &&
        isCatchupLearnerRaftRole(this.role);
      return isJoiningLearner && (
        eventName === PARTITION_SERVICE_ROLE.FOLLOWER ||
        eventName === PARTITION_SERVICE_ROLE.CANDIDATE);
    };
    if (this.isJoiningExistingGroup) {
      this.role = RaftRole.LEARNER;
      this.seedLearnerPromotionWakeObservation();
      this.logger.info(PARTITION_SERVICE_LOG_MSG.STARTING_AS_LEARNER, {
        replicaId: this.replicaId,
        partitionId: this.partitionId,
        promotionCheckIntervalMs: this.learnerCatchUpCheckIntervalMs,
      });
      this.scheduleLearnerPromotion(
        PARTITION_SERVICE_LEARNER_PROMOTION_SCHEDULE_REASON.INITIAL_DELAY,
      );
    }
    wirePartitionRaftLifecycleEvents(this, shouldIgnoreDemotionEvent);
    const totalPeerCount = Math.max(0, this.replicaIds.length - 1);
    let joinedPeerCount = 0;
    this.reportInitializationStage(PARTITION_SERVICE_INIT_STAGE.JOINING_PEERS, {
      peerTotal: totalPeerCount,
      peerJoined: joinedPeerCount,
    });
    for (const peerId of this.replicaIds) {
      // A committed member the address book cannot place yet resolves once
      // discovery catches up; the bootstrap membership, not the address
      // book, names the members (owner decision O1). A peer whose row has
      // not recorded its fact is admitted only on that row change (F2).
      const peerAddress = peerId === this.replicaId ||
        !isBootstrapPeerAdmissible(this, peerId) ? null :
        this.resolveKnownPeerAddress(peerId);
      if (peerAddress !== null) {
        if (!this.suppressLifecycleLogs) {
          this.logger.info(PARTITION_SERVICE_LOG_MSG.JOINING_PEER_ADDRESS, {
            peerId,
            peerAddress,
            replicaId: this.replicaId,
            partitionId: this.partitionId,
            addressFormat: peerAddress.includes(
              PARTITION_SERVICE_ADDRESS.SEPARATOR,
            ) ?
              PARTITION_SERVICE_ADDRESS.FORMAT_UNIFIED :
              PARTITION_SERVICE_ADDRESS.FORMAT_SIMPLE,
          });
        }
        // The bootstrap peers are voters of the core's initial
        // configuration already; the admission owner proposes only on a
        // leader and only a peer the configuration does not name.
        admitPartitionRaftPeer(this, {replicaIdentity: peerId, peerAddress});
        joinedPeerCount += 1;
        this.reportInitializationStage(
          PARTITION_SERVICE_INIT_STAGE.JOINED_PEER,
          {
            peerId,
            peerAddress,
            peerTotal: totalPeerCount,
            peerJoined: joinedPeerCount,
          },
        );
      }
    }
    this.reconcileRaftPeersFromCache();
    this.maybeInitializeRebalancer();
    // A lone replica below its participation gate (a restore that has not
    // replayed to its gate) does not campaign; its scheduling is armed for
    // the gate's opening instead (owner decision O1).
    if (this.replicaIds.length === 1 &&
        this.raft.readStatus()?.gateOpen === false) {
      this.raft.startScheduling();
    } else if (this.replicaIds.length === 1) {
      assertCritical(
        this.raft &&
          typeof this.raft.campaign === PARTITION_SERVICE_TYPE.FUNCTION,
        PARTITION_SERVICE_ERROR_MSG.SINGLE_REPLICA_RAFT_OWNER_REQUIRED,
        {partitionId: this.partitionId, replicaId: this.replicaId},
      );
      // The campaign's outcome is the port's answer to "can this replica
      // lead its own group": a refusal is a partition that can never serve a
      // write, so initialization fails closed with a typed outcome and
      // releases what it acquired (R11) instead of reporting a leader.
      const campaign = await this.raft.campaign();
      if (campaign?.outcome !== RAFT_OPERATION_OUTCOME.CORE_OK) {
        await this.shutdown();
        throw consensusInitRefusedError(this.partitionId, campaign);
      }
      this.logger.info(PARTITION_SERVICE_LOG_MSG.SINGLE_REPLICA_LEADER, {
        replicaId: this.replicaId,
        partitionId: this.partitionId,
      });
    } else {
      this.queueRoleUpdate(this.role);
    }
    this.startPeriodicSizeUpdates();
    this.startPreparedStateHoldTimeoutSweep();
    await this.updatePartitionSize();
    this.initialized = true;
    this.reportInitializationStage(PARTITION_SERVICE_INIT_STAGE.READY, {
      sizeBytes: this.sizeBytes,
      peerTotal: totalPeerCount,
      peerJoined: joinedPeerCount,
    });
    if (!this.suppressLifecycleLogs) {
      this.logger.info(PARTITION_SERVICE_LOG_MSG.INITIALIZED, {
        partitionId: this.partitionId,
        replicaId: this.replicaId,
        sizeBytes: this.sizeBytes,
      });
    }
    this.emit(PARTITION_SERVICE_EVENT.INITIALIZED, {
      partitionId: this.partitionId,
      replicaId: this.replicaId,
    });
  }
  /**
   * Whether this replica's tick scheduling waits for startElection(): a
   * founder's or a restored voter's deferred election does; a joiner's does
   * not - its core is a learner of its own configuration until the AddNode
   * that admits it is applied, so it cannot campaign, and it is ticked from
   * its opening so its election timer never freezes.
   * @return {boolean}
   * @private
   */
  defersElectionScheduling() {
    return this.deferElection === true && !this.isJoiningExistingGroup;
  }
  /**
   * Refuse initialization when the port opened the group held by its host
   * failure (its durable record could not be read at open), whatever the
   * replica count, releasing what initialization acquired (R11): a replica
   * serves nothing from a record it could not read. Healing in place is for
   * a group that fails while it runs.
   * @return {Promise<void>}
   * @private
   */
  async refuseConsensusHeldAtOpen() {
    const opened = this.raft.readStatus();
    if (!isHeldByHostFailure(opened)) {
      return;
    }
    await this.shutdown();
    throw consensusInitRefusedError(this.partitionId, opened);
  }
  /**
   * Start the Raft election timer.
   * Call this after all replicas in the group have been created and registered.
   * This prevents election storms when multiple replicas are created on the same node.
   * If deferElection was false, this is a no-op (election already started).
   */
  startElection() {
    if (this.electionStarted) {
      return;
    }
    if (this.replicaIds.length === 1) {
      this.electionStarted = true;
      return;
    }
    this.electionStarted = true;
    if (this.raft) {
      this.logger.info(PARTITION_SERVICE_LOG_MSG.STARTING_ELECTION_TIMER, {
        replicaId: this.replicaId,
        partitionId: this.partitionId,
        peerCount: this.replicaIds.length - 1,
      });
      this.raft.startScheduling();
    }
  }
  /**
   * Apply raft timing configuration to this live replica.
   * @param {Object} timingConfig
   * @param {number} timingConfig.heartbeatIntervalMs
   * @param {number} timingConfig.electionTimeoutMinMs
   * @param {number} timingConfig.electionTimeoutMaxMs
   * @param {number} [timingConfig.tickIntervalMs]
   * @return {boolean} True when applied to an initialized raft instance.
   */
  applyRaftTimingConfig(timingConfig = {}) {
    const heartbeatMs = timingConfig.heartbeatIntervalMs;
    const baseElectionMinMs = timingConfig.electionTimeoutMinMs;
    const baseElectionMaxMs = timingConfig.electionTimeoutMaxMs;
    const previousTickIntervalMs =
      this.raftTimingConfig?.tickIntervalMs || null;
    const hasTickInterval = Object.prototype.hasOwnProperty.call(
      timingConfig,
      'tickIntervalMs',
    );
    const tickIntervalMs = timingConfig.tickIntervalMs;
    if (
      !Number.isFinite(heartbeatMs) ||
      !Number.isFinite(baseElectionMinMs) ||
      !Number.isFinite(baseElectionMaxMs) ||
      (hasTickInterval &&
        (!Number.isFinite(tickIntervalMs) || tickIntervalMs <= 0)) ||
      baseElectionMinMs > baseElectionMaxMs
    ) {
      return false;
    }
    const {electionMinMs, electionMaxMs, jitterMs} =
      computeReplicaElectionTimeouts({
        replicaId: this.replicaId,
        replicaIds: this.replicaIds,
        baseElectionMinMs,
        baseElectionMaxMs,
        electionJitterPerReplicaMs:
          PARTITION_SERVICE_VALUE.ELECTION_JITTER_PER_REPLICA_MS,
      });
    this.raftTimingConfig = {
      heartbeatMs,
      baseElectionMinMs,
      baseElectionMaxMs,
      electionMinMs,
      electionMaxMs,
      tickIntervalMs: hasTickInterval ?
        tickIntervalMs :
        this.raftTimingConfig?.tickIntervalMs || null,
    };
    const shouldRearmTimer =
      this.replicaIds.length > 1 &&
      (!this.deferElection || this.electionStarted);
    const applied = this.raft?.configureTick?.({
      heartbeatMs,
      electionMinMs,
      electionMaxMs,
      rearmTimer: shouldRearmTimer,
    });
    if (!applied) {
      return false;
    }
    const tickChanged =
      hasTickInterval && tickIntervalMs !== previousTickIntervalMs;
    const tickRuntimeApplied =
      !tickChanged || this.applyRuntimeTickInterval(tickIntervalMs);
    this.logger.info(PARTITION_SERVICE_LOG_MSG.APPLIED_RUNTIME_RAFT_TIMING, {
      partitionId: this.partitionId,
      replicaId: this.replicaId,
      heartbeatMs,
      electionMinMs,
      electionMaxMs,
      tickIntervalMs: hasTickInterval ? tickIntervalMs : null,
      tickRuntimeApplied,
      jitterMs,
      rearmTimer: shouldRearmTimer,
    });
    return tickRuntimeApplied;
  }
  /**
   * Apply raft provider tick interval when supported by the active provider.
   * @param {number} tickIntervalMs
   * @return {boolean} True when applied to a live raft instance.
   */
  applyRuntimeTickInterval(tickIntervalMs) {
    if (
      !this.raft ||
      !Number.isFinite(tickIntervalMs) ||
      tickIntervalMs <= 0
    ) {
      return false;
    }
    const result = this.raft.configureTick({tickIntervalMs});
    return result === true ||
      result?.outcome === RAFT_OPERATION_OUTCOME.CORE_OK;
  }
  /**
   * Create the table based on schema (DDL owner:
   * partition-service-table-bootstrap.js).
   * @private
   */
  createTable() {
    createPartitionServiceTable(this);
  }
}
export {PartitionServiceRaftInitBase};
