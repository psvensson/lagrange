from pathlib import Path
import json,hashlib
D=Path(__file__).parent
r=json.loads((D/'independent-feasibility.json').read_text())
a=D/'author-replay/solve/quests/replicated-transaction-decision-and-apply/evidence/begin-round10-resource-domain-feasibility.json'
checks={
'author-evidence-rerun-byte-identical':hashlib.sha256(a.read_bytes()).hexdigest()=='eda8880920086a1a5448149c9494277c65708b392a8539fdd4d5d937ee56d2b3',
'expired-original-blocks-later-recovery-grants':all(not x['grantLive'] and x['acceptedContractTurnDeadline']>x['now'] for x in r['clockSchedule'] if x['now']>x['originalDeadline']),
'fixed-result-omits-four-exact-immutable-fields':len(r['shape']['missingExactImmutableFields'])==4,
'credit-request-omits-phase-and-offset':r['shape']['missingCreditBindingFields']==['phase','page_offset'],
'four-pressure-responses-exceed-one-slot':r['responseSchedules']['fourOrigins']['liveResponseFrames']>r['responseSchedules']['fourOrigins']['globalResponseSlots'],
'grant-before-callback-can-overlap-response':r['responseSchedules']['grantBeforeCallback']['liveResponseFrames']==2,
'late-classification-arrives-after-token-release':r['responseSchedules']['lateClassification']['targetTokenAtParse'] is False,
'protected-lane-closes-old-cohort-equation':r['completionArithmetic']['oldTAdmitted']==1 and r['completionArithmetic']['total']==r['completionArithmetic']['T'],
'proposed-nul-bom-native-domain-controls':len(r['scalar'])==6 and all(x['storedExact'] and x['decodedExact'] for x in r['scalar']),
'invalid-native-utf8-refused':all(x['rejected'] for x in r['utf8Rejections']),
'empty-schema-has-lawful-existing-initial-install':r['virginSchema']['before']['state']=='install_required' and r['virginSchema']['actualPriorOwnerInstall']['state']=='enforced',
'advanced-commit-reconstruction-keeps-original-key':r['exactKeyAndPages']['initialAndAdvancedSameKey'] and r['exactKeyAndPages']['decisionBefore']==r['exactKeyAndPages']['decisionAfter']=='COMMIT',
'conflicting-canonical-identities-change-key':r['exactKeyAndPages']['mutatedEpochKeyDiffers'] and r['exactKeyAndPages']['mutatedSessionKeyDiffers'],
'fixed-session-pages-compose-but-not-all-six':r['exactKeyAndPages']['concatenatedSessionMatches'] and r['exactKeyAndPages']['finalAdvanced'] and len(r['shape']['missingExactImmutableFields'])>0,
}
for name,ok in checks.items(): print(('CONFIRMED' if ok else 'UNEXPECTED')+' '+name)
print(f'{sum(checks.values())}/{len(checks)} expected observations confirmed; includes design counterexamples, not source approval.')
raise SystemExit(0 if all(checks.values()) else 1)
