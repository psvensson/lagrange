# Exact executed diagnostic commands

All commands ran with cwd:
`/mnt/data/peter/projects/.worktrees/rs-raft-candidate-20261011/test-output/continuation-20261011/begin-design-round11-independent`

```sh
node author-replay/solve/quests/replicated-transaction-decision-and-apply/evidence/begin-round11-endpoint-feasibility.mjs
node round10-native-controls.mjs > round10-native-controls.json
node independent-adverse-schedules.mjs > independent-adverse-schedules.json
python3 evaluate-feasibility.py > feasibility-verdict.log
```

The first command executed the exact copied author driver against immutable navigation source via E-only symlinks, producing the byte-identical author JSON. The second copied the prior independent native controls unchanged; its obsolete round-ten shape/deadline/one-response-slot models remain explicitly historical and are not asserted against round eleven. The third executes actual existing committed-origin application and native SQLite; endpoint/capacity/deadline portions are executable design models. The fourth evaluates 23 expected observations, including two grouped design failures. No future endpoint implementation, heap ceiling or live cluster is certified.

Setup and provenance are in `provenance.json`: all twelve selected navigation source files match actual frozen B, and exact subject/predecessor/driver/JSON/report/dependency hashes are recorded. No B path was written. Symlinks in author-replay point to read-only navigation source and the existing installed node_modules; they are dependencies, not duplicate artifact files in the manifest.
