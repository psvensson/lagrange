CREATE TRIGGER sql_transactions_initial_lineage_v1
BEFORE INSERT ON sql_transactions
WHEN COALESCE((
  typeof(NEW.transaction_id) = 'text' AND length(NEW.transaction_id) = 32
  AND NEW.transaction_id NOT GLOB '*[^0-9a-f]*'
  AND typeof(NEW.session_id) = 'text' AND octet_length(NEW.session_id) > 0
  AND typeof(NEW.transaction_epoch) = 'integer'
  AND NEW.transaction_epoch BETWEEN 0 AND 9007199254740991
  AND typeof(NEW.timeout_deadline) = 'integer'
  AND NEW.timeout_deadline BETWEEN 0 AND 9007199254740991
  AND NEW.transaction_mode IN ('EXPLICIT', 'AUTOCOMMIT')
  AND NEW.status = 'ACTIVE' AND NEW.participant_set_state = 'OPEN'
  AND NEW.participant_set_text = '[]' AND NEW.commit_mode = 'NOT_SELECTED'
  AND NEW.frozen_participant_count = 0
  AND NEW.decision IS NULL AND NEW.decision_text IS NULL AND NEW.decision_digest IS NULL
), 0) = 0 OR EXISTS (
  SELECT 1 FROM sql_transactions WHERE transaction_id = NEW.transaction_id
)
BEGIN SELECT RAISE(ABORT, 'transaction_initial_row_refused'); END
