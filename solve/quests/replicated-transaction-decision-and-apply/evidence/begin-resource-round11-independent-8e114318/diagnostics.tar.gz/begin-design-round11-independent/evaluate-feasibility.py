import json,hashlib
from pathlib import Path
p=Path(__file__).parent
x=json.loads((p/'independent-adverse-schedules.json').read_text())
n=json.loads((p/'round10-native-controls.json').read_text())
a=p/'author-replay/solve/quests/replicated-transaction-decision-and-apply/evidence'
checks={
 'exact author replay':(a/'begin-round11-endpoint-feasibility.json').read_bytes()==(a/'begin-round11-endpoint-feasibility.author.json').read_bytes(),
 'actual lawful origin application':x['schema']['outcome']=='applied' and x['schema']['afterOrigin']['origin']=={'originIndex':7,'originTerm':3},
 'actual V2 enforcer is present with origin':x['schema']['afterOrigin']['enforcement']['schemaVersion']==2,
 'actual replay preserves origin':x['schema']['replay']=='replayed' and x['schema']['afterReplay']['origin']==x['schema']['afterOrigin']['origin'],
 'D11-2 lawful V2 refused':x['schema']['round11ForLawfulProducedV2']=='INCOMPATIBLE',
 'fresh V3 install positive':x['schema']['directV3EmptyInstallWorks'],
 'defective enforcer refusal':x['schema']['defectiveRefusals']==['INCOMPATIBLE','INCOMPATIBLE'],
 'empty legacy prior installer positive':x['schema']['emptyLegacyShape']['before']['state']=='install_required' and x['schema']['emptyLegacyShape']['after']['state']=='enforced',
 'D11-2 empty legacy narrowed':x['schema']['emptyLegacyShape']['round11']=='INCOMPATIBLE',
 'same envelope reconnect positive':x['capacity']['sameEnvelopeSuccessor']['enabled'],
 'D11-1 larger successor remains blocked after drain':not x['capacity']['largerEnvelopeSuccessor']['enabled'] and x['capacity']['largerEnvelopeSuccessor']['nativeLaneAvailable'],
 'D11-1 no dropped record or decision mutation':x['capacity']['largerEnvelopeSuccessor']['decision']=='COMMIT' and not x['capacity']['largerEnvelopeSuccessor']['rollbackEmissions'],
 'post expiry reconciliation grant live':x['deadlineRoles'][1]['reconciliationTurnDeadline']>x['deadlineRoles'][1]['now'],
 'post expiry foreground still fenced':x['deadlineRoles'][1]['foregroundTurnDeadline']<x['deadlineRoles'][1]['now'] and not x['deadlineRoles'][1]['reconciliationCanMutate'],
 'four immutable values in new tuple':x['shape']['immutableFieldsPresent'],
 'phase offset byte binding present':x['shape']['creditBindingFieldsPresent'],
 'four endpoint frames fit distinct slots':x['endpoint']['overlap'][1]['sqlCalls']==1 and sum(x['endpoint']['overlap'][1]['slots'].values())==4,
 'expiry retains grant frame':x['endpoint']['late'][1]['slots']['creditResult'] and not x['endpoint']['late'][1]['native'],
 'late classifier makes no native call':x['endpoint']['late'][-1]['sqlCalls']==0,
 'scalar six native positives':len(n['scalar'])==6 and all(r['storedExact'] and r['decodedExact'] for r in n['scalar']),
 'native invalid UTF8 refusals':len(n['utf8Rejections'])==3 and all(r['rejected'] for r in n['utf8Rejections']),
 'complete advanced immutable key control':n['exactKeyAndPages']['initialAndAdvancedSameKey'] and n['exactKeyAndPages']['concatenatedSessionMatches'] and n['exactKeyAndPages']['finalAdvanced'],
 'durable COMMIT unchanged with missing progress':n['exactKeyAndPages']['decisionBefore']==n['exactKeyAndPages']['decisionAfter']=='COMMIT' and n['exactKeyAndPages']['participantProgressRows']==[],
}
for name,passed in checks.items(): print(('PASS ' if passed else 'FAIL ')+name)
print(f'{sum(checks.values())}/{len(checks)} expected observations; includes design counterexamples; not source acceptance')
assert all(checks.values())
