import fs from 'node:fs';
import assert from 'node:assert/strict';
import Database from '/mnt/data/peter/projects/.worktrees/rs-raft-startup-integration-20261011/node_modules/better-sqlite3/lib/index.js';
import {applyCommittedTransactionCommand} from '../begin-design-round9-independent/navigation/src/partition/partition-participant-transaction-apply.js';
import {openParticipantTransactionStore,readPartitionWriteOrigin,readPartitionWriteGeneration} from '../begin-design-round9-independent/navigation/src/partition/partition-participant-transaction-store.js';
import {readTransactionSchemaEnforcement,installTransactionSchemaEnforcement} from '../begin-design-round9-independent/navigation/src/query/distributed/distributed-transaction-schema-enforcement.js';
const create=`CREATE TABLE sql_transactions(transaction_id TEXT PRIMARY KEY,session_id TEXT NOT NULL,status TEXT NOT NULL,transaction_epoch INTEGER,timeout_deadline INTEGER,transaction_mode TEXT NOT NULL,participant_set_state TEXT NOT NULL,participant_set_text TEXT,commit_mode TEXT NOT NULL,frozen_participant_count INTEGER NOT NULL,decision TEXT,decision_text TEXT,decision_digest TEXT,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)`;
const db=new Database(':memory:'); db.exec(create);openParticipantTransactionStore(db);
const callbacks=[],answers=[];
const service={db,tableName:'sql_transactions',partitionId:'tx-p0',logger:{info(){},debug(){}},resolveCommittedWrite(id,result){answers.push({id,result});},rejectCommittedWrite(){},emit(){}};
const committed={command:{type:'PARTICIPANT_GENERATION_ORIGIN',partitionId:'tx-p0',entryId:'origin-proof'},index:7,term:3,afterCommit(fn){callbacks.push(fn);},afterRollback(){}};
const beforeOrigin={origin:readPartitionWriteOrigin(db),enforcement:readTransactionSchemaEnforcement(db)};
const outcome=db.transaction(()=>applyCommittedTransactionCommand(service,committed))(); for(const cb of callbacks.splice(0))cb();
const afterOrigin={origin:readPartitionWriteOrigin(db),generation:readPartitionWriteGeneration(db),enforcement:readTransactionSchemaEnforcement(db),rows:db.prepare('SELECT count(*) AS n FROM sql_transactions').get().n};
const replay=db.transaction(()=>applyCommittedTransactionCommand(service,committed))();for(const cb of callbacks.splice(0))cb();
const afterReplay={origin:readPartitionWriteOrigin(db),generation:readPartitionWriteGeneration(db),enforcement:readTransactionSchemaEnforcement(db)};
assert.equal(beforeOrigin.origin,null);assert.equal(outcome,'applied');assert.equal(afterOrigin.enforcement.schemaVersion,2);assert.deepEqual(afterOrigin.origin,{originIndex:7,originTerm:3});assert.equal(replay,'replayed');
// Literal model of the changed table, not a future implementation.
function round11Schema(originPresent,rowCount,trigger,shapeComplete=true){
 if(!originPresent&&rowCount===0&&shapeComplete&&trigger==='MISSING')return 'INSTALL_REQUIRED_V3';
 if(!originPresent&&rowCount===0&&shapeComplete&&trigger==='EXACT_V2')return 'UPGRADE_REQUIRED_V2_TO_V3';
 if(originPresent&&trigger==='EXACT_V3')return 'ENFORCED_V3';
 return 'INCOMPATIBLE';
}
const v2trigger=db.prepare("SELECT name,sql FROM sqlite_schema WHERE type='trigger' AND tbl_name='sql_transactions'").get();
const v3=v2trigger.sql.replace('length(NEW.session_id) > 0','octet_length(NEW.session_id) > 0');
const fresh=new Database(':memory:');fresh.exec(create);fresh.transaction(()=>fresh.exec(v3))();
assert.equal(fresh.prepare("SELECT sql FROM sqlite_schema WHERE type='trigger'").get().sql,v3);
const partial=new Database(':memory:');partial.exec('CREATE TABLE sql_transactions(transaction_id TEXT PRIMARY KEY,session_id TEXT)');const partialBefore=readTransactionSchemaEnforcement(partial);const partialAfter=partial.transaction(()=>installTransactionSchemaEnforcement(partial))();const emptyLegacyShape={before:partialBefore,after:partialAfter,round11:round11Schema(false,0,'MISSING',false)};partial.close();
const schema={emptyLegacyShape,beforeOrigin,outcome,afterOrigin,replay,afterReplay,answers,round11ForLawfulProducedV2:round11Schema(true,0,'EXACT_V2'),round11UpgradePrecondition:{originPresent:false,rowCount:0,trigger:'EXACT_V2'},directV3EmptyInstallWorks:true,positiveStates:[round11Schema(false,0,'MISSING'),round11Schema(false,0,'EXACT_V2'),round11Schema(true,0,'EXACT_V3')],defectiveRefusals:['MISSING','FOREIGN'].map(t=>round11Schema(true,0,t))};
// Model the exact fixed-total admission equation with finite, measured connection envelopes.
const T=1048576,native=262144,oldCapability=32768,retained=T-native-oldCapability;
function capabilitySchedule(nextCapability){let used=native+oldCapability+retained;const events=[{event:'admit full retained cohort',used,free:T-used}];used-=oldCapability;events.push({event:'old generation physically drained and fully released',used,free:T-used});const enabled=T-used>=nextCapability;if(enabled)used+=nextCapability;events.push({event:enabled?'enable successor':'successor typed unavailable',used,free:T-used});return {T,native,retained,oldCapability,nextCapability,enabled,nativeLaneAvailable:true,events,requiresUnrelatedRecordRelease:!enabled,recordId:'a'.repeat(32),decision:'COMMIT',rollbackEmissions:[],newInsertEmissions:[]};}
const capacity={sameEnvelopeSuccessor:capabilitySchedule(oldCapability),largerEnvelopeSuccessor:capabilitySchedule(oldCapability+1),additionalOriginAtFullCohort:{T,alreadyUsed:T,newCapability:oldCapability,enabled:false},note:'Illustrative safe-integer units, not measured heap limits. The contradiction holds for any permitted positive successor allowance delta. It remains after the old generation has fully physically drained.'};
assert.equal(capacity.sameEnvelopeSuccessor.enabled,true);assert.equal(capacity.largerEnvelopeSuccessor.enabled,false);
class Endpoint {
 constructor(){this.state='CONNECTION_READY';this.slots={creditAck:false,creditResult:false,classifierAck:false,classifierResult:false};this.native=false;this.sqlCalls=0;this.history=[];}
 log(event){this.history.push({event,state:this.state,native:this.native,slots:{...this.slots},sqlCalls:this.sqlCalls});}
 grant(){assert.equal(this.state,'CONNECTION_READY');this.slots.creditAck=true;this.slots.creditResult=true;this.native=true;this.state='GRANTED';this.log('grant submitted, callback pending');}
 expiry(){if(this.state==='GRANTED'){this.state='EXPIRED_DRAINING';this.native=false;}this.log('semantic expiry');}
 classify(){this.slots.classifierAck=true;this.slots.classifierResult=true;if(this.state==='GRANTED'){this.state='CLASSIFYING';this.sqlCalls++;this.native=false;this.log('native synchronous step finished, frames retained');}else{assert.equal(this.state,'EXPIRED_DRAINING');this.log('GRANT_EXPIRED, no SQL');}}
 callback(slot){this.slots[slot]=false;this.log('callback '+slot);}
}
const overlap=new Endpoint();overlap.grant();overlap.classify();overlap.expiry();assert.equal(Object.values(overlap.slots).filter(Boolean).length,4);assert.equal(overlap.sqlCalls,1);for(const slot of Object.keys(overlap.slots))overlap.callback(slot);
const late=new Endpoint();late.grant();late.expiry();assert.equal(late.slots.creditResult,true);late.classify();assert.equal(late.sqlCalls,0);
const fourOrigins=Array.from({length:4},()=>new Endpoint());fourOrigins[0].grant();for(const e of fourOrigins.slice(1)){e.slots.creditAck=true;e.slots.creditResult=true;e.log('typed native-lane pressure');}
const endpoint={scope:'Executable model of DS 2524-2576; no future production endpoint is imported',overlap:overlap.history,late:late.history,fourOrigins:fourOrigins.map(e=>e.history),maxSimultaneousFrameSlots:8,allocatedPermanentFrameSlots:16};
const deadlineRoles=[4000,6000].map(now=>({now,originalDeadline:5000,foregroundTurnDeadline:Math.min(5000,now+1000),reconciliationTurnDeadline:now+1000,reconciliationCanMutate:false,reconciliationCanMint:false}));
const authored=JSON.parse(fs.readFileSync(new URL('author-replay/solve/quests/replicated-transaction-decision-and-apply/evidence/begin-round11-endpoint-feasibility.json',import.meta.url)));
const shape={immutableFieldsPresent:['transaction_epoch','timeout_deadline','transaction_mode','created_at'].every(x=>authored.tupleFields.pageResult.includes(x)),creditBindingFieldsPresent:['phase','page_offset','page_bytes'].every(x=>authored.tupleFields.creditRequest.includes(x)),generationDomainsSeparate:authored.generationDomains.crossDomainNumericEqualityRequired===false};
assert.equal(shape.immutableFieldsPresent,true);assert.equal(shape.creditBindingFieldsPresent,true);
const result={scope:'Independent design schedules plus actual installed SQLite and existing committed-origin application. No production private classification/grant implementation is claimed.',schema,capacity,endpoint,deadlineRoles,shape};
console.log(JSON.stringify(result,null,2));db.close();fresh.close();
