import fs from 'node:fs';
import Database from '/mnt/data/peter/projects/.worktrees/rs-raft-startup-integration-20261011/node_modules/better-sqlite3/lib/index.js';
import {buildInitialTransactionDeliveryKey,encodeInitialTransactionRow} from '../begin-design-round9-independent/navigation/src/query/distributed/distributed-transaction-creation-contract.js';
import {readTransactionSchemaEnforcement,installTransactionSchemaEnforcement} from '../begin-design-round9-independent/navigation/src/query/distributed/distributed-transaction-schema-enforcement.js';
import {buildDecisionRecord,participantIdOf} from '../begin-design-round9-independent/navigation/src/partition/partition-participant-transaction-bytes.js';
import {participantSetTextOf} from '../begin-design-round9-independent/navigation/src/query/distributed/distributed-transaction-participant-manifest.js';
const TX='a'.repeat(32), PAGE=4096;
function initial(session='session'){return {transaction_id:TX,session_id:session,status:'ACTIVE',transaction_epoch:7,timeout_deadline:5000,transaction_mode:'EXPLICIT',participant_set_state:'OPEN',participant_set_text:'[]',commit_mode:'NOT_SELECTED',frozen_participant_count:0,updated_at:1000,decision:null,decision_text:null,decision_digest:null,created_at:1000};}
function initialFromImmutable(row){return {...initial(row.session_id),transaction_id:row.transaction_id,transaction_epoch:row.transaction_epoch,timeout_deadline:row.timeout_deadline,transaction_mode:row.transaction_mode,created_at:row.created_at,updated_at:row.created_at};}
function key(row){const restored=initialFromImmutable(row);return buildInitialTransactionDeliveryKey(restored.transaction_id,encodeInitialTransactionRow(restored));}
function result(row,attempt,offset=0,metadata=false){const bytes=Buffer.from(row.session_id);return {transaction_id:row.transaction_id,attempt_key:attempt,identity_state:key(row)===attempt?'KEY_MATCH':'KEY_DIFFERENT',initial_match:row.status==='ACTIVE'&&row.participant_set_state==='OPEN'&&row.decision===null?1:0,session_octets:bytes.length,page_offset:offset,session_page_hex:metadata?'':bytes.subarray(offset,offset+PAGE).toString('hex'),resource_generation:1};}
const row=initial('x'.repeat(PAGE+9));const attempt=key(row);
const decision=buildDecisionRecord(TX,'COMMIT',[[participantIdOf(TX,'partition-x'),'digest-x']]);
const advanced={...row,status:'COMMITTING',participant_set_state:'FROZEN',participant_set_text:participantSetTextOf(TX,['partition-x']),commit_mode:'TWO_PHASE_COMMIT',frozen_participant_count:1,updated_at:3000,decision:decision.decision,decision_text:decision.decisionText,decision_digest:decision.decisionDigest};
const pages=[result(row,attempt,0),result(advanced,attempt,PAGE),result(advanced,attempt,PAGE+9)];
const actualFields=Object.keys(result(row,attempt,0,true));
const requiredExactFields=['transaction_epoch','timeout_deadline','transaction_mode','created_at'];
const creditFields=['contract_version','transaction_id','attempt_key','target_node_id','target_replica_id','source_node_id','source_incarnation','resource_generation','original_deadline_at_ms','turn_deadline_at_ms'];
const clockSchedule=[4000,6000,7000].map(now=>{const control=now+1000,expiry=Math.min(control,5000);return {now,originalDeadline:5000,controlDeadline:control,round10GrantExpiry:expiry,grantLive:expiry>now,acceptedContractTurnDeadline:now<5000?Math.min(control,5000):control,retainedId:TX,durableDecision:advanced.decision};});
const responseSchedules={
 fourOrigins:{globalResponseSlots:1,events:['A grant frame retained until send callback','B credit request gets typed pressure','C credit request gets typed pressure','D credit request gets typed pressure'],liveResponseFrames:4,excessFrames:3},
 grantBeforeCallback:{globalResponseSlots:1,events:['target sends grant; callback pending','origin receives grant and sends classifier','target consumes grant and finishes synchronous SQLite','target serializes classification response; grant callback still pending'],liveResponseFrames:2,requiresAnotherSlotOrChargedWait:true},
 lateClassification:{events:['valid grant issued','origin sends classifier before its deadline','target unused-grant timer expires and releases token','in-flight canonical classifier frame arrives','target parses fixed frame to find expired credit'],targetTokenAtParse:false,connectionAllowanceDeclaredFor:'credit-request graph only'}
};
const db=new Database(':memory:');
db.exec(`CREATE TABLE sql_transactions(transaction_id TEXT PRIMARY KEY,session_id TEXT NOT NULL,status TEXT NOT NULL,transaction_epoch INTEGER,timeout_deadline INTEGER,transaction_mode TEXT NOT NULL,participant_set_state TEXT NOT NULL,participant_set_text TEXT,commit_mode TEXT NOT NULL,frozen_participant_count INTEGER NOT NULL,decision TEXT,decision_text TEXT,decision_digest TEXT,created_at INTEGER NOT NULL,updated_at INTEGER NOT NULL)`);
const virgin=readTransactionSchemaEnforcement(db);const installed=installTransactionSchemaEnforcement(db);
const trigger=db.prepare("SELECT name,sql FROM sqlite_schema WHERE type='trigger' AND tbl_name='sql_transactions'").get();
const v3sql=trigger.sql.replace('length(NEW.session_id) > 0','octet_length(NEW.session_id) > 0');
const replace=db.transaction(()=>{db.exec(`DROP TRIGGER ${trigger.name}`);db.exec(v3sql);});replace();
const insert=db.prepare('INSERT INTO sql_transactions VALUES (@transaction_id,@session_id,@status,@transaction_epoch,@timeout_deadline,@transaction_mode,@participant_set_state,@participant_set_text,@commit_mode,@frozen_participant_count,@decision,@decision_text,@decision_digest,@created_at,@updated_at)');
const scalar=[];for(const session of ['ordinary','\ufeff','\0','\0a','a\0b','💾']){db.exec('DELETE FROM sql_transactions');insert.run(initial(session));const raw=db.prepare('SELECT CAST(session_id AS BLOB) AS bytes FROM sql_transactions').get().bytes;scalar.push({hex:raw.toString('hex'),storedExact:raw.equals(Buffer.from(session)),decodedExact:new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(raw)===session,deliveryKey:key(initial(session))});}
const utf8Rejections=[];for(const hex of ['eda080','ff','c080']){try{new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(Buffer.from(hex,'hex'));utf8Rejections.push({hex,rejected:false});}catch{utf8Rejections.push({hex,rejected:true});}}
fs.writeFileSync(new URL('proposed-trigger.sql',import.meta.url),v3sql+'\n');
const output={scope:'Design feasibility. Native SQLite trigger/bytes and existing canonical key/decision builders are real. Grant, expiry, response custody and page-result contracts are explicit models of the document, not future production source.',
 exactKeyAndPages:{transactionId:TX,attemptKey:attempt,advancedKey:key(advanced),initialAndAdvancedSameKey:key(advanced)===attempt,durableAdvanced:advanced,participantProgressRows:[],pages,concatenatedSessionMatches:pages.map(x=>x.session_page_hex).join('')===Buffer.from(row.session_id).toString('hex'),finalAdvanced:pages.at(-1).initial_match===0,decisionBefore:advanced.decision,decisionAfter:advanced.decision,commitEmissions:[],rollbackEmissions:[],mutatedEpochKeyDiffers:key({...row,transaction_epoch:8})!==attempt,mutatedSessionKeyDiffers:key({...row,session_id:'y'.repeat(PAGE+9)})!==attempt},
 shape:{actualResultFields:actualFields,missingExactImmutableFields:requiredExactFields.filter(f=>!actualFields.includes(f)),creditRequestFields:creditFields,missingCreditBindingFields:['phase','page_offset'].filter(f=>!creditFields.includes(f)),leaderWitnessNote:'May remain in the already existing owner-RPC response envelope; absence inside this row is not itself a finding.'},
 clockSchedule,responseSchedules,
 completionArithmetic:{T:5506,fixed:1,completion:1835,record:1835,recordsAdmitted:2,total:1+1835+2*1835,oldT:3671,oldTAdmitted:Math.floor((3671-1-1835)/1835)},
 scalar,utf8Rejections,virginSchema:{before:virgin,actualPriorOwnerInstall:installed,round10LiteralMissingTriggerDisposition:'INCOMPATIBLE',note:'Document 2229-2237 needs to preserve lawful empty first installation separately from a missing required enforcer on an already-originated generation.'}
};
console.log(JSON.stringify(output,null,2));
