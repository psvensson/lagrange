from pathlib import Path
import hashlib
import json
import tarfile

C = Path('/mnt/data/peter/projects/.worktrees/tx1-cdc-20261011')
D = Path(__file__).parent
P = C / 'solve/quests/replicated-transaction-decision-and-apply/evidence/cdc-native-profile-prerequisite-20261011T2223'
checks = []
manifests = [(P / 'packet-sha256.txt', P), (C / 'solve/quests/replicated-transaction-decision-and-apply/evidence/cdc-transfer-owner-implementation-20261011T2236/packet-sha256.txt', C)]
for manifest, base in manifests:
    for line in manifest.read_text().splitlines():
        if not line:
            continue
        expected, p = line.split(None, 1)
        file = base / p.strip()
        actual = hashlib.sha256(file.read_bytes()).hexdigest()
        checks.append({'path': str(file), 'match': actual == expected, 'sha256': actual})
archive = Path('/tmp/cdc-node-cap-20261012/node-v22.22.0-linux-x64.tar.gz')
source = Path('/tmp/cdc-node-cap-20261012/node-v22.22.0.tar.gz')
sums = {line.split()[1]: line.split()[0] for line in (P / 'node-v22.22.0-SHASUMS256.txt').read_text().splitlines()}
for file in [archive, source]:
    actual = hashlib.sha256(file.read_bytes()).hexdigest()
    checks.append({'path': str(file), 'sha256': actual, 'match': actual == sums[file.name]})
with tarfile.open(archive) as t:
    digest = hashlib.sha256(t.extractfile('node-v22.22.0-linux-x64/bin/node').read()).hexdigest()
checks.append({'path': 'signed binary archive executable', 'sha256': digest, 'match': digest == '1bec56ef7cfa9a76f3e0b7c0a87f220eb73f23102b9c0b4c7529a3f7c3ce7c31'})
with tarfile.open(source) as t:
    for line in (P / 'source-correspondence.tsv').read_text().splitlines()[1:]:
        if not line:
            continue
        path, expected, *_ = line.split('\t')
        actual = hashlib.sha256(t.extractfile('node-v22.22.0/' + path).read()).hexdigest()
        checks.append({'path': path, 'sha256': actual, 'match': actual == expected})
(D / 'native-identity-checks.json').write_text(json.dumps(checks, indent=2) + '\n')
print('checks', len(checks), 'all_match', all(x['match'] for x in checks))
raise SystemExit(0 if all(x['match'] for x in checks) else 1)
