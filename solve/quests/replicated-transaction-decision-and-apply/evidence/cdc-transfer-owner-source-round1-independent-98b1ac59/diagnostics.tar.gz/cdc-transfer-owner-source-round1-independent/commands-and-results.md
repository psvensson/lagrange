# Independent transfer-owner source review commands

Date: 2026-10-12, Europe/Stockholm. No product files changed.

Working tree: `/mnt/data/peter/projects/.worktrees/tx1-cdc-20261011`.
Diagnostic directory: `/mnt/data/peter/projects/.worktrees/rs-raft-candidate-20261011/test-output/continuation-20261011/cdc-transfer-owner-source-round1-independent`.

## Frozen inputs and existing positive test

```sh
sha256sum src/cdc/cdc-coverage-transfer-owner.js test/cdc/cdc-coverage-lifecycle-owner.test.js
/tmp/cdc-node-cap-20261012/node scripts/run-classified-test-files.js test/cdc/cdc-coverage-lifecycle-owner.test.js
```

The two source hashes match the review request. The classified runner exited 0:
one file, 64 assertions, zero failures. Output: `focused-test.txt`.
`source-ledger.json` binds the copied navigation files. `git-object-checks.json`
independently compares both files with preservation snapshot
`c8800cd70d315b27034506d5632c6d554fabbb80`; both match. It also confirms the
reconcile-owner source is unchanged from accepted caller snapshot `2de41948...`.

## Behavioral counterexamples and positive controls

```sh
/tmp/cdc-node-cap-20261012/node --expose-gc /mnt/data/peter/projects/.worktrees/rs-raft-candidate-20261011/test-output/continuation-20261011/cdc-transfer-owner-source-round1-independent/owner-counterexamples.mjs
/tmp/cdc-node-cap-20261012/node /mnt/data/peter/projects/.worktrees/rs-raft-candidate-20261011/test-output/continuation-20261011/cdc-transfer-owner-source-round1-independent/descriptor-boundaries.mjs
```

The first diagnostic exits 1 intentionally because seven observations violate
the tested owner claims. Three controls pass: exact-capacity synchronous
successor; below-capacity refusal; collection of normal service/shutdown-record
references after terminal transfer and retirement. Raw output:
`counterexamples.txt`; full non-payload state: `counterexamples.json`.
These ten observations group into four findings, not seven separate defects.

The descriptor lattice exits 0 as an observation collector; this is not a
claim that all inputs were properly rejected. `descriptor-boundaries.json`
records ordinary invalid-number/boxed/string refusals, acceptance of negative
zero, and acceptance of a descriptor with zero own fields.

Both scripts import the exact frozen production transfer owner directly and
use its public exported operations. They do not patch production code or
model the pool separately. The terminalize callbacks and wakes are controlled
local boundary callbacks. They do not stand in for a native MessageRouter,
WebSocket, Raft, SQL, CDC delivery or startup proof.

The first diagnostic version was rerun after moving the graph creation into
a completed synchronous helper and adding the normal collection control.
The final retained script/log pair contains that stronger witness. There is
no future-source green or reverted-source treatment claimed.

## Exact native identity

```sh
python3 /mnt/data/peter/projects/.worktrees/rs-raft-candidate-20261011/test-output/continuation-20261011/cdc-transfer-owner-source-round1-independent/verify-native-inputs.py
gpg --homedir /tmp/cdc-node-cap-20261012/release-keys/gpg-only-active-keys --no-auto-check-trustdb --status-fd 1 --verify /mnt/data/peter/projects/.worktrees/tx1-cdc-20261011/solve/quests/replicated-transaction-decision-and-apply/evidence/cdc-native-profile-prerequisite-20261011T2223/node-v22.22.0-SHASUMS256.txt.sig /mnt/data/peter/projects/.worktrees/tx1-cdc-20261011/solve/quests/replicated-transaction-decision-and-apply/evidence/cdc-native-profile-prerequisite-20261011T2223/node-v22.22.0-SHASUMS256.txt
```

36 content checks match: 11 native packet entries, 6 implementation packet
entries, two signed archive digests, the extracted executable digest, and 16
source archive members. `native-identity-checks.json` records every result.
The signature check exits 0 and reports GOODSIG/VALIDSIG for exact retained
fingerprint `CC68F5A3106FF448322E48ED27F5E38D5B0A215F`.
GPG also reports unsafe temporary homedir permissions and TRUST_UNDEFINED;
the review pins the supplied release key and makes no fresh web-of-trust claim.

An initial inline identity-check attempt used the wrong base directory for
the native packet's basename entries and stopped with FileNotFoundError before
checking contents. The retained script corrects that setup error; its output
and JSON contain the complete successful run. No product failure was inferred
from that setup error.

The signed binary/source correspondence is independently checked here.
The previously retained cosign/distroless attestation and allocator/compiled
layout measurements were read, not rerun. They remain reference-profile
evidence. No future candidate distribution is certified by this review.
