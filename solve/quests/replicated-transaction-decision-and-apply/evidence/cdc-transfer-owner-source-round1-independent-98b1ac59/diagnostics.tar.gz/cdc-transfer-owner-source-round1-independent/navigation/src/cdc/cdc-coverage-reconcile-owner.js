import {CDC_PIPELINE_READINESS_TIMEOUT_MS} from
  '../constants/cdc-lifecycle-constants.js';
import {
  captureCdcCoverageToken,
  isCurrentCdcCoverageLifecycle,
  registerCdcCoverageLifecycleCleanup,
} from './cdc-coverage-lifecycle-owner.js';
import {registerCdcCoverageTransferWake} from
  './cdc-coverage-transfer-owner.js';
import {readCdcCoverageTransferDiagnostics} from
  './cdc-coverage-transfer-owner.js';
import {reportWaitBoundSpent} from '../logging/wait-bound-spent.js';

const CDC_COVERAGE_RECONCILE_STATE = Object.freeze({
  CANCELLED: 'cancelled',
  COMPLETE: 'complete',
  FAILED: 'failed',
  RETIRED: 'retired',
  SPENT: 'spent',
});
const CDC_COVERAGE_RECONCILE_REASON = Object.freeze({
  CALLER_CANCELLED: 'cdc_coverage_reconcile_caller_cancelled',
  CALLER_CAPACITY: 'cdc_coverage_reconcile_caller_capacity',
  DEADLINE: 'cdc_coverage_reconcile_deadline_spent',
  IDENTITY_INVALID: 'cdc_coverage_reconcile_identity_invalid',
  LIFECYCLE_STALE: 'cdc_coverage_reconcile_lifecycle_stale',
  OUTCOME_INVALID: 'cdc_coverage_reconcile_outcome_invalid',
  SHUTDOWN: 'cdc_coverage_reconcile_shutdown',
});
const CDC_COVERAGE_RECONCILE_WAIT = Object.freeze({
  AWAITED: 'complete authoritative CDC coverage publication',
  OWNER: 'CDC_COVERAGE_RECONCILE_DEFAULT.WINDOW_MS',
});
const CDC_COVERAGE_RECONCILE_DEFAULT = Object.freeze({
  COOLDOWN_INITIAL_MS: 1000,
  COOLDOWN_MAX_MS: 30000,
  RETRY_MAX_MS: 1000,
  RETRY_MIN_MS: 100,
  MAX_WAITERS_PER_DEBT: 64,
  WINDOW_MS: CDC_PIPELINE_READINESS_TIMEOUT_MS,
});
const owners = new WeakMap();
const CDC_COVERAGE_DIAGNOSTIC_INTERVAL_MS = 10 * 60 * 1000;

function exactIdentity(request) {
  return request && typeof request.partitionId === 'string' &&
    request.partitionId.length > 0 && typeof request.tableName === 'string' &&
    request.tableName.length > 0;
}

function reconcileKey(request) {
  return `${request.partitionId}\u0000${request.tableName}`;
}

function frozenOutcome(state, reasonCode, extra = {}) {
  return Object.freeze({state, success: state ===
    CDC_COVERAGE_RECONCILE_STATE.COMPLETE, reasonCode, ...extra});
}

function clampCdcCoverageBackoff(remaining, requested) {
  if (!Number.isFinite(remaining) || remaining <
      CDC_COVERAGE_RECONCILE_DEFAULT.RETRY_MIN_MS) return null;
  const requestedMs = Number.isFinite(requested) && requested > 0 ?
    Math.floor(requested) : CDC_COVERAGE_RECONCILE_DEFAULT.RETRY_MIN_MS;
  return Math.min(remaining, CDC_COVERAGE_RECONCILE_DEFAULT.RETRY_MAX_MS,
    Math.max(CDC_COVERAGE_RECONCILE_DEFAULT.RETRY_MIN_MS, requestedMs));
}

function clearTimer(service, timer) {
  if (timer !== null) service.timeSource.clearTimeout(timer);
}

function unrefTimer(timer) {
  timer?.unref?.();
  return timer;
}

function reportDebt(owner, debt, reason, generation = debt.generation) {
  const now = owner.service.timeSource.now();
  const transfer = readCdcCoverageTransferDiagnostics(owner.service);
  debt.lastReportAt = now;
  debt.reportSequence += 1;
  reportWaitBoundSpent(owner.service.logger, {
    wait: CDC_COVERAGE_RECONCILE_WAIT.OWNER,
    awaited: CDC_COVERAGE_RECONCILE_WAIT.AWAITED,
    subject: `${debt.tableName}@${debt.partitionId}`,
    boundMs: debt.windowMs,
    elapsedMs: Number.isFinite(generation?.startedAtMs) ?
      Math.max(0, now - generation.startedAtMs) :
      Math.max(0, now - debt.createdAtMs),
    lastObserved: {reason, lastOutcome: debt.lastOutcome,
      lastAttempt: debt.lastAttemptDiagnostics,
      reportSequence: debt.reportSequence},
    scope: {nodeId: owner.service.nodeId,
      tableName: debt.tableName, partitionId: debt.partitionId,
      generationId: generation?.id ?? null, attempts: debt.attempts,
      windowsSpent: debt.windowsSpent,
      targetLifecycleId: owner.lifecycle.lifecycleIncarnation,
      retainedBytes: transfer.retainedBytes,
      heldTransfers: transfer.held},
  });
}

function shouldReportDebt(owner, debt) {
  const count = debt.windowsSpent;
  const powerOfTwo = Number.isSafeInteger(count) && count > 0 &&
    Number.isInteger(Math.log2(count));
  return powerOfTwo || owner.service.timeSource.now() - debt.lastReportAt >=
    CDC_COVERAGE_DIAGNOSTIC_INTERVAL_MS;
}

function retireGeneration(service, generation) {
  if (!generation || generation.retired) return;
  generation.retired = true;
  clearTimer(service, generation.deadlineTimer);
  clearTimer(service, generation.backoffTimer);
  generation.deadlineTimer = null;
  generation.backoffTimer = null;
  generation.release?.({retired: true});
  generation.release = null;
}

function retireDebt(owner, debt) {
  retireGeneration(owner.service, debt.generation);
  clearTimer(owner.service, debt.cooldownTimer);
  debt.cooldownTimer = null;
  debt.retired = true;
}

function callerOutcome(state, reasonCode, waiter, debt) {
  return frozenOutcome(state, reasonCode, {
    deadlineMs: waiter.deadlineMs,
    generationId: debt.generation?.id ?? null,
  });
}

function settleCallerWaiter(owner, debt, expected, proposed) {
  if (debt.waiters.get(expected.id) !== expected ||
      expected.state !== 'pending') return false;
  const resolve = expected.resolve;
  const cancelled = expected.cancelled || expected.signal?.aborted === true;
  const lifecycleCurrent = expected.lifecycle === owner.lifecycle &&
    debtIsCurrent(owner, debt);
  const now = owner.service.timeSource.now();
  let outcome = proposed;
  if (cancelled) {
    outcome = callerOutcome(CDC_COVERAGE_RECONCILE_STATE.CANCELLED,
      CDC_COVERAGE_RECONCILE_REASON.CALLER_CANCELLED, expected, debt);
  } else if (!lifecycleCurrent) {
    outcome = callerOutcome(CDC_COVERAGE_RECONCILE_STATE.RETIRED,
      CDC_COVERAGE_RECONCILE_REASON.LIFECYCLE_STALE, expected, debt);
  } else if (now >= expected.deadlineMs) {
    outcome = callerOutcome(CDC_COVERAGE_RECONCILE_STATE.SPENT,
      CDC_COVERAGE_RECONCILE_REASON.DEADLINE, expected, debt);
  }
  expected.state = 'settled';
  debt.waiters.delete(expected.id);
  clearTimer(owner.service, expected.timer);
  expected.removeAbort?.();
  expected.timer = null;
  expected.removeAbort = null;
  expected.resolve = null;
  expected.signal = null;
  expected.lifecycle = null;
  resolve(outcome);
  return true;
}

function settleDebtWaiters(owner, debt, outcome) {
  for (const waiter of [...debt.waiters.values()]) {
    settleCallerWaiter(owner, debt, waiter, outcome);
  }
}

function registerCallerWaiter(owner, debt, deadlineMs, signal) {
  if (debt.waiters.size >=
      CDC_COVERAGE_RECONCILE_DEFAULT.MAX_WAITERS_PER_DEBT) return null;
  let resolve;
  const promise = new Promise((settle) => {
    resolve = settle;
  });
  const waiter = {id: ++debt.waiterSequence, deadlineMs,
    lifecycle: owner.lifecycle, signal: signal ?? null, cancelled: false,
    state: 'pending', resolve, timer: null, removeAbort: null, promise};
  debt.waiters.set(waiter.id, waiter);
  const cancel = () => {
    waiter.cancelled = true;
    settleCallerWaiter(owner, debt, waiter,
      callerOutcome(CDC_COVERAGE_RECONCILE_STATE.CANCELLED,
        CDC_COVERAGE_RECONCILE_REASON.CALLER_CANCELLED, waiter, debt));
  };
  if (signal) {
    signal.addEventListener('abort', cancel, {once: true});
    waiter.removeAbort = () => signal.removeEventListener('abort', cancel);
  }
  waiter.timer = unrefTimer(owner.service.timeSource.setTimeout(() => {
    if (debt.inFlight && debt.generation?.deadlineMs === waiter.deadlineMs) {
      return;
    }
    settleCallerWaiter(owner, debt, waiter,
      callerOutcome(CDC_COVERAGE_RECONCILE_STATE.SPENT,
        CDC_COVERAGE_RECONCILE_REASON.DEADLINE, waiter, debt));
  }, Math.max(0, deadlineMs - owner.service.timeSource.now())));
  if (signal?.aborted === true) cancel();
  return waiter;
}

function retireOwner(owner) {
  if (owner.retired) return;
  owner.retired = true;
  for (const debt of owner.debts.values()) {
    reportDebt(owner, debt, CDC_COVERAGE_RECONCILE_REASON.SHUTDOWN);
    settleDebtWaiters(owner, debt, frozenOutcome(
      CDC_COVERAGE_RECONCILE_STATE.RETIRED,
      CDC_COVERAGE_RECONCILE_REASON.SHUTDOWN));
    retireDebt(owner, debt);
  }
  owner.debts.clear();
  owner.unregisterTransferWake?.();
  owner.unregisterTransferWake = null;
}

function ownerFor(service) {
  const existing = owners.get(service);
  if (existing && isCurrentCdcCoverageLifecycle(existing.lifecycle)) {
    return existing;
  }
  if (existing) retireOwner(existing);
  const lifecycle = captureCdcCoverageToken(service);
  if (lifecycle === null) return null;
  const owner = {service, lifecycle, debts: new Map(), retired: false,
    unregister: null, unregisterTransferWake: null};
  owner.unregister = registerCdcCoverageLifecycleCleanup(service,
    () => retireOwner(owner));
  owner.unregisterTransferWake = registerCdcCoverageTransferWake(service,
    () => wakeAllCdcCoverageReconciles(service));
  owners.set(service, owner);
  return owner;
}

function remainingMs(owner, generation) {
  return Math.max(0, Math.floor(
    generation.deadlineMs - owner.service.timeSource.now()));
}

function generationIsCurrent(owner, debt, generation) {
  return !owner.retired && !debt.retired && !generation.retired &&
    debt.generation === generation &&
    isCurrentCdcCoverageLifecycle(owner.lifecycle);
}

function debtIsCurrent(owner, debt) {
  return !owner.retired && !debt.retired &&
    owner.debts.get(debt.key) === debt &&
    isCurrentCdcCoverageLifecycle(owner.lifecycle);
}

function deadlineSignal(owner, generation) {
  return new Promise((resolve) => {
    generation.release = resolve;
    generation.deadlineTimer = unrefTimer(
      owner.service.timeSource.setTimeout(() => {
        generation.expired = true;
        generation.release = null;
        resolve({deadline: true});
      }, remainingMs(owner, generation)));
  });
}

function backoffSignal(owner, generation, delayMs) {
  return new Promise((resolve) => {
    generation.backoffTimer = unrefTimer(
      owner.service.timeSource.setTimeout(() => {
        generation.backoffTimer = null;
        resolve({retry: true});
      }, delayMs));
  });
}

function validAttemptOutcome(result) {
  return result && typeof result === 'object' &&
    (result.success === true || result.deferRetry === true ||
      result.success === false);
}

function attemptContext(owner, debt, generation) {
  return Object.freeze({
    deadlineMs: generation.deadlineMs,
    generationId: generation.id,
    lifecycle: owner.lifecycle,
    partitionId: debt.partitionId,
    tableName: debt.tableName,
    isCurrent: () => generationIsCurrent(owner, debt, generation),
    remainingMs: () => remainingMs(owner, generation),
  });
}

async function executeAttempt(owner, debt, generation) {
  debt.attempts += 1;
  try {
    return await generation.execute(attemptContext(owner, debt, generation));
  } catch (error) {
    return {success: false, deferRetry: false,
      reasonCode: error?.code || error?.message || String(error)};
  }
}

function spentOutcome(debt, generation) {
  return frozenOutcome(CDC_COVERAGE_RECONCILE_STATE.SPENT,
    CDC_COVERAGE_RECONCILE_REASON.DEADLINE, {
      generationId: generation.id, attempts: debt.attempts,
      deadlineMs: generation.deadlineMs,
      lastOutcome: debt.lastOutcome,
    });
}

function decideValidAttempt(owner, debt, generation, settled) {
  debt.lastOutcome = settled.reasonCode ?? settled.reason ??
    (settled.success === true ? CDC_COVERAGE_RECONCILE_STATE.COMPLETE : null);
  debt.lastAttemptDiagnostics = Object.freeze({
    success: settled.success === true,
    deferRetry: settled.deferRetry === true,
    pages: Number.isSafeInteger(settled.pages) ? settled.pages : null,
    chunks: Number.isSafeInteger(settled.chunks) ? settled.chunks : null,
    sourceScopeId: typeof settled.sourceScope?.scopeId === 'string' ?
      settled.sourceScope.scopeId : null,
    transferId: typeof settled.transferId === 'string' ?
      settled.transferId : null,
  });
  if (settled.success === true) {
    debt.consecutiveSpent = 0;
    return {outcome: frozenOutcome(CDC_COVERAGE_RECONCILE_STATE.COMPLETE, null,
      {generationId: generation.id, value: settled})};
  } else if (settled.deferRetry !== true) {
    return {outcome: frozenOutcome(CDC_COVERAGE_RECONCILE_STATE.FAILED,
      debt.lastOutcome, {generationId: generation.id, value: settled})};
  }
  return {backoffMs: clampCdcCoverageBackoff(remainingMs(owner, generation),
    settled.retryAfterMs)};
}

function decideAttempt(owner, debt, generation, settled) {
  if (!generationIsCurrent(owner, debt, generation)) {
    return {outcome: frozenOutcome(CDC_COVERAGE_RECONCILE_STATE.RETIRED,
      CDC_COVERAGE_RECONCILE_REASON.LIFECYCLE_STALE)};
  } else if (!validAttemptOutcome(settled)) {
    debt.lastOutcome = CDC_COVERAGE_RECONCILE_REASON.OUTCOME_INVALID;
    return {outcome: frozenOutcome(CDC_COVERAGE_RECONCILE_STATE.FAILED,
      CDC_COVERAGE_RECONCILE_REASON.OUTCOME_INVALID)};
  }
  return decideValidAttempt(owner, debt, generation, settled);
}

async function runGeneration(owner, debt, generation) {
  const deadline = deadlineSignal(owner, generation);
  while (generationIsCurrent(owner, debt, generation)) {
    if (remainingMs(owner, generation) <= 0) break;
    const attempt = executeAttempt(owner, debt, generation);
    const settled = await Promise.race([attempt, deadline]);
    if (settled?.deadline === true) break;
    const decision = decideAttempt(owner, debt, generation, settled);
    if (decision.outcome) return decision.outcome;
    if (decision.backoffMs === null) {
      await deadline;
      break;
    }
    const retried = await Promise.race([
      backoffSignal(owner, generation, decision.backoffMs), deadline]);
    if (retried?.deadline === true) break;
  }
  return generationIsCurrent(owner, debt, generation) ?
    spentOutcome(debt, generation) :
    frozenOutcome(CDC_COVERAGE_RECONCILE_STATE.RETIRED,
      CDC_COVERAGE_RECONCILE_REASON.LIFECYCLE_STALE);
}

function cooldownMs(debt) {
  const exponent = Math.max(0, debt.consecutiveSpent - 1);
  return Math.min(CDC_COVERAGE_RECONCILE_DEFAULT.COOLDOWN_MAX_MS,
    CDC_COVERAGE_RECONCILE_DEFAULT.COOLDOWN_INITIAL_MS * (2 ** exponent));
}

function scheduleCooldown(owner, debt) {
  clearTimer(owner.service, debt.cooldownTimer);
  debt.cooldownTimer = unrefTimer(owner.service.timeSource.setTimeout(() => {
    debt.cooldownTimer = null;
    if (debtIsCurrent(owner, debt)) startGeneration(owner, debt);
  }, cooldownMs(debt)));
}

function generationFinished(owner, debt, generation, outcome) {
  retireGeneration(owner.service, generation);
  if (debt.generation !== generation || debt.retired) return outcome;
  debt.inFlight = null;
  settleDebtWaiters(owner, debt, outcome);
  if (outcome.state === CDC_COVERAGE_RECONCILE_STATE.COMPLETE) {
    owner.debts.delete(debt.key);
    retireDebt(owner, debt);
  } else if (outcome.state === CDC_COVERAGE_RECONCILE_STATE.SPENT &&
      isCurrentCdcCoverageLifecycle(owner.lifecycle)) {
    debt.consecutiveSpent += 1;
    debt.windowsSpent += 1;
    if (shouldReportDebt(owner, debt)) {
      reportDebt(owner, debt, outcome.reasonCode, generation);
    }
    scheduleCooldown(owner, debt);
  }
  return outcome;
}

function startGeneration(owner, debt, deadlineMs = null) {
  if (debt.inFlight) return debt.inFlight;
  const windowDeadline = owner.service.timeSource.now() + debt.windowMs;
  const generation = {id: ++debt.generationSequence,
    startedAtMs: owner.service.timeSource.now(),
    deadlineMs: deadlineMs ?? windowDeadline, deadlineTimer: null,
    backoffTimer: null, release: null, retired: false, expired: false,
    execute: debt.execute};
  debt.generation = generation;
  debt.inFlight = runGeneration(owner, debt, generation)
    .then((outcome) => generationFinished(owner, debt, generation, outcome));
  return debt.inFlight;
}

function validCallerSignal(signal) {
  return signal === undefined || Boolean(signal &&
    typeof signal.aborted === 'boolean' &&
    typeof signal.addEventListener === 'function' &&
    typeof signal.removeEventListener === 'function');
}

function suppliedDeadlineIsInvalid(request) {
  return request?.deadlineMs !== undefined &&
    (!Number.isSafeInteger(request.deadlineMs) || request.deadlineMs <= 0);
}

function callerWindowMs(request) {
  return Number.isFinite(request.windowMs) && request.windowMs > 0 ?
    Math.floor(request.windowMs) : CDC_COVERAGE_RECONCILE_DEFAULT.WINDOW_MS;
}

function refusedCallerAdmission(state, reasonCode, deadlineMs) {
  return {outcome: frozenOutcome(state, reasonCode,
    deadlineMs === undefined ? {} : {deadlineMs})};
}

function captureCallerAdmission(service, request, execute) {
  const signal = request?.signal;
  if (!exactIdentity(request) || suppliedDeadlineIsInvalid(request) ||
      !validCallerSignal(signal) || typeof execute !== 'function') {
    return refusedCallerAdmission(CDC_COVERAGE_RECONCILE_STATE.FAILED,
      CDC_COVERAGE_RECONCILE_REASON.IDENTITY_INVALID);
  }
  const windowMs = callerWindowMs(request);
  const now = service.timeSource.now();
  const requestedDeadline = Number.isSafeInteger(request.deadlineMs) ?
    request.deadlineMs : now + windowMs;
  if (!Number.isSafeInteger(requestedDeadline) || requestedDeadline <= now) {
    return refusedCallerAdmission(
      CDC_COVERAGE_RECONCILE_STATE.SPENT,
      CDC_COVERAGE_RECONCILE_REASON.DEADLINE,
      requestedDeadline);
  }
  if (signal?.aborted === true) {
    return refusedCallerAdmission(
      CDC_COVERAGE_RECONCILE_STATE.CANCELLED,
      CDC_COVERAGE_RECONCILE_REASON.CALLER_CANCELLED,
      requestedDeadline);
  }
  return {deadlineMs: requestedDeadline, signal, windowMs};
}

function resolveCallerDebt(owner, request, execute, windowMs) {
  const key = reconcileKey(request);
  let debt = owner.debts.get(key);
  if (debt) {
    if (!debt.inFlight) debt.execute = execute;
    return debt;
  }
  debt = {key, partitionId: request.partitionId, tableName: request.tableName,
    windowMs, execute, generationSequence: 0, generation: null,
    inFlight: null, cooldownTimer: null, consecutiveSpent: 0,
    windowsSpent: 0, attempts: 0, lastOutcome: null, retired: false,
    waiters: new Map(), waiterSequence: 0};
  debt.lastAttemptDiagnostics = null;
  debt.createdAtMs = owner.service.timeSource.now();
  debt.lastReportAt = Number.NEGATIVE_INFINITY;
  debt.reportSequence = 0;
  owner.debts.set(key, debt);
  return debt;
}

function attachCallerToDebt(owner, debt, admission) {
  const waiter = registerCallerWaiter(
    owner, debt, admission.deadlineMs, admission.signal);
  if (waiter === null) {
    return Promise.resolve(frozenOutcome(CDC_COVERAGE_RECONCILE_STATE.FAILED,
      CDC_COVERAGE_RECONCILE_REASON.CALLER_CAPACITY,
      {deferRetry: true, deadlineMs: admission.deadlineMs}));
  }
  if (!debt.inFlight) {
    clearTimer(owner.service, debt.cooldownTimer);
    debt.cooldownTimer = null;
    startGeneration(owner, debt, admission.deadlineMs);
  }
  return waiter.promise;
}

function armCdcCoverageReconcile(service, request, execute) {
  const admission = captureCallerAdmission(service, request, execute);
  if (admission.outcome) return Promise.resolve(admission.outcome);
  const owner = ownerFor(service);
  if (owner === null) {
    return Promise.resolve(frozenOutcome(CDC_COVERAGE_RECONCILE_STATE.RETIRED,
      CDC_COVERAGE_RECONCILE_REASON.LIFECYCLE_STALE));
  }
  const debt = resolveCallerDebt(
    owner, request, execute, admission.windowMs);
  return attachCallerToDebt(owner, debt, admission);
}

function wakeCdcCoverageReconcile(service, identity) {
  const owner = owners.get(service);
  if (!owner || !exactIdentity(identity)) return false;
  const debt = owner.debts.get(reconcileKey(identity));
  if (!debt || debt.retired || debt.inFlight) return false;
  clearTimer(service, debt.cooldownTimer);
  debt.cooldownTimer = null;
  startGeneration(owner, debt);
  return true;
}

function wakeAllCdcCoverageReconciles(service) {
  const owner = owners.get(service);
  if (!owner || owner.retired) return 0;
  let woken = 0;
  for (const debt of owner.debts.values()) {
    if (debt.retired || debt.inFlight) continue;
    clearTimer(service, debt.cooldownTimer);
    debt.cooldownTimer = null;
    startGeneration(owner, debt);
    woken += 1;
  }
  return woken;
}

function captureCdcCoverageReconcileDebts(service) {
  const owner = owners.get(service);
  if (!owner || owner.retired) return Object.freeze([]);
  return Object.freeze([...owner.debts.values()].filter(
    (debt) => !debt.retired).map((debt) => Object.freeze({
    request: Object.freeze({partitionId: debt.partitionId,
      tableName: debt.tableName, windowMs: debt.windowMs}),
    execute: debt.execute,
  })));
}

function rearmCdcCoverageReconcileDebts(service, retained) {
  if (!Array.isArray(retained)) return 0;
  let armed = 0;
  for (const item of retained) {
    if (!exactIdentity(item?.request) || typeof item?.execute !== 'function') {
      continue;
    }
    void armCdcCoverageReconcile(service, item.request, item.execute);
    armed += 1;
  }
  return armed;
}

function readCdcCoverageReconcileDiagnostics(service) {
  const owner = owners.get(service);
  if (!owner || owner.retired) return Object.freeze([]);
  return Object.freeze([...owner.debts.values()].map((debt) => Object.freeze({
    partitionId: debt.partitionId, tableName: debt.tableName,
    generationId: debt.generation?.id ?? null,
    inFlight: debt.inFlight !== null, cooldownArmed: debt.cooldownTimer !== null,
    consecutiveSpent: debt.consecutiveSpent, windowsSpent: debt.windowsSpent,
    attempts: debt.attempts, lastOutcome: debt.lastOutcome,
    waiters: debt.waiters.size,
  })));
}

export {
  CDC_COVERAGE_RECONCILE_DEFAULT,
  CDC_COVERAGE_RECONCILE_REASON,
  CDC_COVERAGE_RECONCILE_STATE,
  armCdcCoverageReconcile,
  captureCdcCoverageReconcileDebts,
  clampCdcCoverageBackoff,
  readCdcCoverageReconcileDiagnostics,
  rearmCdcCoverageReconcileDebts,
  wakeCdcCoverageReconcile,
  wakeAllCdcCoverageReconciles,
};
