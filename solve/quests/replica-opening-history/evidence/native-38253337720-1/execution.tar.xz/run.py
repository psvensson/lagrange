"""Exact native history proof on the existing WIP branch; never lands or merges."""
import hashlib,json,os,re,shutil,signal,subprocess,sys
from pathlib import Path
R=Path.cwd(); B=Path(__file__).parent; E=R/os.environ.get('EVIDENCE','test-output/opening-history-proof'); E.mkdir(parents=True,exist_ok=True)
M=json.loads((B/'manifest.json').read_text()); Q='replica-opening-history'; META=['test/shards/'+n+'.json' for n in ['primary-classes','resource-classes','subsystem-classes','impact-graph-seal']]
def sha(data):return hashlib.sha256(data).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],text=True).strip()
def command(name,args,limit=120):
 p=E/(name+'.log'); record={'command':args,'completed':False,'exit':None}
 with p.open('w') as f:
  process=subprocess.Popen(args,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,env={**os.environ,'LAGRANGE_RETRY_FAILED_ONCE':'0'})
  try:record.update(completed=True,exit=process.wait(timeout=limit))
  except subprocess.TimeoutExpired:
   os.killpg(process.pid,signal.SIGKILL);process.wait();record['timeout']=True
 (E/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n');return record

def tests(name,files):
 command_result=command(name,['npm','run','-s','test:file','--',*files],180);rows=[]
 destination=E/(name+'-tap');tap=R/'.tap/test-results'
 if tap.exists():shutil.copytree(tap,destination,dirs_exist_ok=True);shutil.rmtree(tap)
 for file in files:
  raw=destination/(file+'.tap');text=raw.read_text() if raw.exists() else ''; counts={key:int(matches[-1]) if (matches:=re.findall(r'^# '+key+r' (\d+)\s*$',text,re.M)) else None for key in ['tests','pass','fail','cancelled','skipped','todo']}
  durations=[float(x) for x in re.findall(r'^\s+duration_ms:\s*([\d.]+)\s*$',text,re.M)]
  target=30000 if file.endswith('.integration.test.js') or file.startswith(('test/integration/','test/bootstrap/')) else 2000
  rows.append({'file':file,'counts':counts,'testSha256':sha((R/file).read_bytes()),'maxCaseMs':max(durations,default=None),'targetMs':target,'toleranceFactor':10,'durationAccepted':bool(durations) and max(durations)<=10*target,'assertionFailures':len(re.findall(r'code: [\'\"]?ERR_ASSERTION',text))})
 result={**command_result,'files':rows};(E/(name+'.json')).write_text(json.dumps(result,indent=2)+'\n');return result

def total(result,key):return sum(row['counts'][key] or 0 for row in result['files'])
def clean_success(result,n):return result['completed'] and result['exit']==0 and total(result,'tests')==n and total(result,'pass')==n and all(row['counts'][k]==0 for row in result['files'] for k in ['fail','skipped','cancelled','todo'])
def commit(message,paths):
 subprocess.run(['git','add','--',*paths],check=True)
 subprocess.run(['git','commit','-m',message],check=True,env={**os.environ,'LAGRANGE_SKIP_PRECOMMIT':'1'})
 return git('rev-parse','HEAD')

# Expand the retained patch only after every touched input matches its hash.
# Restore the checkout before sealing so test-only baseline and source treatment
# remain separate commits; no reset/clean of unrelated workspace entries.
original={}
for file,entry in M['files'].items():
 p=R/file; data=p.read_bytes() if p.exists() else None
 assert (sha(data) if data is not None else None)==entry['before'],('patch input diverged',file)
 original[file]=data
subprocess.run(['git','apply','--check',str(B/'changes.patch')],check=True)
try:
 subprocess.run(['git','apply',str(B/'changes.patch')],check=True)
 for file,entry in M['files'].items():
  data=(R/file).read_bytes(); assert sha(data)==entry['after'],('expanded hash',file)
  dest=B/'files'/file;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
finally:
 for file,data in original.items():
  if data is None:
   if (R/file).exists():(R/file).unlink()
  else:(R/file).write_bytes(data)

before={}; prod=[p for p in M['files'] if p.startswith('src/')]; tests_selected=M['nativeTests']
for file,entry in M['files'].items():
 p=R/file; data=p.read_bytes() if p.exists() else None
 assert (sha(data) if data is not None else None)==entry['before'], ('input diverged',file)
 assert sha((B/'files'/file).read_bytes())==entry['after'],('bundle content diverged',file)
 before[file]=data
# Current production tree is checked per changed path, not assumed from local Git IDs.
input_head=git('rev-parse','HEAD');(E/'input-head.txt').write_text(input_head+'\n')
for file in M['files']:
 if file.startswith('src/'):continue
 dest=R/file;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(B/'files'/file,dest)
assert command('metadata-baseline',['npm','run','-s','test:metadata:refresh'])['exit']==0
assert command('seal',['node','scripts/solve.js','start','--id',Q,'--json'])['exit']==0
baseline_commit=commit('WIP rs-raft: seal native opening history and record operator timing tolerance', [p for p in M['files'] if not p.startswith('src/')]+META+[f'solve/quests/{Q}/log.ndjson'])
baseline=tests('baseline',tests_selected)
inherited_before=tests('inherited-baseline',[M['inheritedFixture']])
guideline_before=command('guidelines-baseline',['npm','run','-s','audit:guidelines'])
for file in prod:shutil.copyfile(B/'files'/file,R/file)
assert command('metadata-candidate',['npm','run','-s','test:metadata:refresh'])['exit']==0
assert command('source-attempt',['node','scripts/solve.js','note','--id',Q,'--attempt','Exact lifecycle opening fact and synced native bootstrap. Preserve never-opened retries, refuse established/unknown history loss, import staging as established. Candidate requires source review; no independent approval or landing claimed.','--json'])['exit']==0
candidate_sha=commit('WIP rs-raft: commit exact-incarnation history with native bootstrap before participation',prod+META+[f'solve/quests/{Q}/log.ndjson'])
after={file:(R/file).read_bytes() for file in prod}
(E/'source-hashes.json').write_text(json.dumps({'before':{p:sha(before[p]) if before[p] is not None else None for p in prod},'after':{p:sha(after[p]) for p in prod}},indent=2)+'\n')
candidate=tests('candidate',tests_selected)
try:
 for file in prod:
  if before[file] is None:(R/file).unlink()
  else:(R/file).write_bytes(before[file])
 revert=tests('source-revert',tests_selected)
finally:
 for file,data in after.items():(R/file).write_bytes(data)
regressions=tests('regressions',M['regressions'])
assert all((R/p).read_bytes()==data for p,data in after.items())
lint=command('lint',['./node_modules/.bin/eslint',*prod])
literals=command('changed-literals',['node','scripts/check-guideline-literals.js',*prod])
impact=command('impact',['npm','run','-s','audit:impact-contracts'])
boundary=command('boundary',['node','--input-type=module','-e',"import {auditRaftRsOperationBoundary as audit} from './scripts/checks/raft-rs-operation-boundary-audit.js';const v=audit({root:process.cwd()});console.log(JSON.stringify(v));process.exitCode=v.length?1:0;"])
guidelines=command('guidelines',['npm','run','-s','audit:guidelines'])
whitespace=command('whitespace',['git','diff','--check',input_head,'HEAD'])
counts=lambda x:{k:total(x,k) for k in ['tests','pass','fail','cancelled','skipped','todo']}
checks={'candidate-native':clean_success(candidate,28),'native-source-control':counts(baseline)==counts(revert) and total(baseline,'tests')==28 and total(baseline,'fail')>0,'negative-assertions':all(row['assertionFailures']==row['counts']['fail'] for sample in [baseline,revert] for row in sample['files']),'unchanged-native-tests':all([row['testSha256'] for row in sample['files']]==[row['testSha256'] for row in candidate['files']] for sample in [baseline,revert]),'regression-count':total(regressions,'tests')==M['expectedRegressionCount'],'regression-behavior':clean_success(regressions,M['expectedRegressionCount']),'hardware-duration-tolerance':all(row['durationAccepted'] for row in regressions['files']),'lint':lint['exit']==0,'changed-literals':literals['exit']==0,'impact':impact['exit']==0,'boundary':boundary['exit']==0,'whitespace':whitespace['exit']==0}
# Failed wider fixtures remain failures even when inherited; the native source
# proof never includes them in its positive population.
count_literal=lambda file:re.search(r'Found (\d+) new literal',file.read_text()).group(1)
summary={'input':input_head,'baseline':baseline_commit,'candidate':candidate_sha,'node':subprocess.check_output(['node','--version'],text=True).strip(),'checks':checks,'nativeBaseline':counts(baseline),'nativeCandidate':counts(candidate),'nativeSourceRevert':counts(revert),'regressions':counts(regressions),'inheritedBaseline':counts(inherited_before),'literalCounts':{'before':count_literal(E/'guidelines-baseline.log'),'candidate':count_literal(E/'guidelines.log')},'nativeProofPassed':all(checks[k] for k in ['candidate-native','native-source-control','negative-assertions','unchanged-native-tests','lint','changed-literals','impact','boundary','whitespace']),'allRunGatesPassed':all(checks.values()) and guidelines['exit']==0,'independentApproval':False,'mergeReady':False,'scope':'Real native operation ports and WASM service initialization; separate-process reopen and process-kill boundary witnesses. Not whole-file-loss, snapshot receiver validation, full SQL/CDC startup or multi-host certification.'}
(E/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
# Keep the seal unresolved until its complete requirements are actually proved.
receipt_path=R/f'solve/quests/{Q}/evidence/receipt.json'; receipt=json.loads(receipt_path.read_text())
for item in receipt['receipts']:item['passed']=summary['nativeProofPassed'] and item['id']!='current-impact-and-regression-proof'
receipt['status']='FAIL';receipt['measuredCandidate']=candidate_sha;receipt_path.write_text(json.dumps(receipt,indent=2)+'\n')
command('result-note',['node','scripts/solve.js','note','--id',Q,'--finding',f"Candidate {candidate_sha}: native history proof {summary['nativeProofPassed']}; selected regression {summary['regressions']}. Inherited failed fixtures and 311 literal violations remain. No independent approval or complete release proof.",'--json'])
print(json.dumps(summary,indent=2))
