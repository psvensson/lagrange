# C0 review response: recovery direction and crash reconstruction

Status: LOCAL DRAFT, NOT PUBLISHED OR INDEPENDENTLY APPROVED.
Base review: PR #104 at `0219a7fee95bdd744e52b8fa2eb5c5978e661964`.
Runtime: unchanged `82b54ef9b7c8d6be9f2d6450cbc5e6713ade00af`.
No C0 receipt is promoted, no sealed statement is edited and no source-repair
Quest is declared by this packet. The review's REJECT remains in force.

## 1. Review received and its consequence

Independent review `5452918820` / `PRR_kwDOThZ5hs8AAAABRQTwJA`, submitted by
`copilot-pull-request-reviewer[bot]` at 2026-10-08T07:05:06Z, explicitly rejects
C0 closure. It supports the earlier narrow conclusions while leaving J1,
workflow crash/replay, intact snapshot catch-up and production FreshMG work
unresolved. This is NOT acceptance hidden behind the review's zero inline
findings. Source review:
https://github.com/psvensson/lagrange/pull/104#pullrequestreview-5452918820

## 2. J1 recommendation: choose and fence the removal direction once

This is a proposed protocol-owner decision for independent review, not an
implemented rule or unilateral change to FreshMG acceptance.

Keep operation O's admitted old source S and fresh target T immutable. After T
is promoted but S is still retained, neither “always remove the target on
failure” nor “promotion always makes rollback safe” is a valid default.
The decisive boundary is whether retiring S has been durably authorized or
may already be in flight, not merely whether S appears in one configuration.

| Durable owner state | Proposed behavior | Required refusal |
| --- | --- | --- |
| No removal direction selected; S-retirement authorization definitively never issued; exact S retained and existing safety policy permits abandoning T | Existing operation owner may select target abandonment and bind REMOVE T before issuing it | No consumer-selected recovery mode; no selection from stale cache or timeout alone |
| No direction selected; target voter, handoff and existing source-retention prerequisites satisfied | Existing operation owner may select successful source retirement and bind REMOVE S before issuing it | Never infer permission from “promoted” alone |
| REMOVE S selected, submitted, or submission outcome uncertain | Preserve T and reconcile S removal; continue forward under the same obligation | Do not issue REMOVE T as compensation even if a fresh read still lists S |
| REMOVE T selected for abandonment | Retain S and reconcile exact T removal; do not later switch this O into successful source retirement | No source-removal permit under the abandoned direction |
| S is committed absent | Preserve T and finish S's exact cleanup/recovery | Ordinary failure cannot authorize removal of the surviving replacement |
| Required authority is unavailable or target cannot currently recover | Hold the existing obligation/lane; name its retry trigger or operator-recovery requirement; preserve useful surviving replicas | Do not fabricate an admission, count a timeout as absence, or declare terminal membership success |

The choice must be durable and exclusive BEFORE the first subject-specific
removal request, including under cancellation, lease takeover and lost CAS
answers. This is a semantic fact to encode through the existing repository's
operation/permit state, not a new journal, coordinator or observer-owned flag.
C0 does not choose a column layout or modify the immutable membership identity.
If the current fields cannot carry this fact, the next owner-reviewed scope
must say so explicitly before changing them.

### Late commands are part of the choice

Selecting abandonment must also prove that earlier admission/promotion work
cannot later authorize source retirement. Releasing either branch requires
resolving outstanding proposals, not just sampling absence. A conflicting or
unknown CAS result grants neither direction; adopt the exact durable winner
or retain the unresolved obligation. Old source and fresh target identities,
physical generations, group identity and command subject must agree in the
request, native configuration context and the returned proof.

Do not mint a new transitionIdentity merely to escape an older fence. Current
`transitionFenceKey` keys by operationId plus transitionIdentity;
`staleTransitionFence` retains one same-key/current-generation high-water
observation. This local runtime check is NOT a durable cancellation or branch
selection authority. Prefer the current operation-level transition lineage;
make the exact subject and branch consistent through the existing permit.
Prove same-sequence/different-subject and old-owner reentry refusal at the
actual operation admission/runtime interaction before accepting any encoding.

### Safety and availability tradeoff

Target abandonment before source-retirement authorization can restore the
original group when a promoted T fails, instead of leaving an otherwise useful
S indefinitely blocked. Once S retirement may be in flight, preserving T avoids
a delayed REMOVE S racing a compensating REMOVE T. The cost is that unrecoverable
post-retirement target failure needs an explicit existing-owner repair policy;
it cannot be solved by weakening absence or identity proofs. No unbounded
silent retry is accepted as recovery.

### Existing independent lifetimes remain independent

Ordinary terminal settlement, the per-group membership obligation, reservation
accounting and physical cleanup keep their sealed owners. Leader/quorum absence
resolves the applicable membership obligation; source-own applied absence
continues to gate stopping S. Failed-target cleanup must use its existing
lifecycle/CREATE authority and exact-generation rules, not an invented source
proof or blanket terminal-row permission. This proposal does not pick a new
universal storage-reservation release point.

## 3. New process-crash measurements

Harness: `scripts/quest-evidence/cutover-workflow-crash-baseline.js`.
Evidence: [local matrix](evidence/local-workflow-crash-matrix.json) and
[source provenance](evidence/local-source-provenance.json).

The original Actions source archive was hash-verified; all 1,851 extracted src
blobs match its git-tree manifest. GitHub's base-to-review comparison contains
no src changes. The diagnostic was executed LOCALLY in this chat environment,
not on Actions/GCP. It imports unchanged DurableWorkflowCoordinator, transition
callback and operation-row recovery code. Its storage port is an explicitly
separate node:sqlite file-backed fixture; it does not instantiate the production
ReplicaOperationRepository, better-sqlite3 binding, Raft group or physical CREATE.

| Cut / control | Fresh-process result |
| --- | --- |
| Acknowledged fixture commit | Committed SENDING state and replay idempotency reconstructed |
| SIGKILL after mirror transition, before SQL | Old PENDING row recovered; SENDING not marked committed |
| SIGKILL after UPDATE, before COMMIT | Transaction rolls back on reopen; old row and permission boundary retained |
| SIGKILL after COMMIT, before local committed mark | Committed row recovered; SENDING replay rejected without invoking persistence again |
| SIGKILL after local committed mark | Same committed reconstruction; local mark is not needed for restart truth |
| Real fixture CAS affected zero rows | Durable winner retained; losing mirror cannot become recovered permission |
| SQLite write refused by query-only mode | Durable old row retained; uncommitted mark not reconstructed |
| Different durable writer already advanced the row | Actual committed winner recovered despite this worker's failed CAS |
| Durable terminal row with opaque membership obligation | Loader skips active workflow recreation; row retains its obligation bytes |

All nine cases passed. Seven writer processes were actually SIGKILLed at named
IPC cuts; every case used a fresh reader process. The test also refused execution
under LAGRANGE_PROBE=1 before creating an output file. No timer-based race fishing
was used. Its timeout only bounds a missing cut/exit, and only this harness's
own child processes and temporary directory are touched.

### What is still NOT proved

The harness manually drives mirror -> fixture persistence -> local mark in the
order found in the current orchestration; that orchestration is not executed.
It therefore does not establish production CAS predicates, lease takeover,
uncertain network-write settlement, target/source effects, cleanup, raft-rs
apply ordering, power-loss safety or multi-host recovery. Its opaque obligation
retention is not proof that the actual membership/cleanup owners recover work.

`ensureOperationWorkflow` also contains a fallback after the row loader declines
a terminal record. The full caller/terminal guard chain must still be tested;
the isolated terminal-loader result must not become a no-resurrection claim for
that whole chain. This packet does not authorize a speculative fallback repair.

The useful conclusion is narrower: these existing reconstruction components can
recover committed row truth without durable storage for the volatile progress
Map. No new progress store is justified by the measured restart cuts.

## 4. Review scope must not create a circular implementation gate

C0's sealed work is classification and independent contract review; it expressly
forbids runtime repairs. The subsequent FreshMG/snapshot Quests own implementation
and physical acceptance. Request separate judgments: whether a transition is
classified precisely enough to open its next bounded repair, and whether that
repair has been implemented/certified. Do not call either judgment the other.

This is not a request to waive C0's rejection. It requires resolving J1 and the
remaining production commit/recovery classification, then requesting a newer
review. Known missing runtime wiring may remain a named red predecessor for a
product Quest, but an UNKNOWN authority may not be hidden as a mere TODO.

## 5. Next bounded proof and publication status

Next production-level evidence must cover the actual repository's refused and
unknown durable-write outcomes, fresh-owner adoption and terminal guards. Reuse
its current harness/ports with real persistence where possible; do not graft a
second workflow engine onto this test. Snapshot classification still requires
the native Ready/application-image interaction; no CREATE grant may be forged
for an intact existing member.

The patch extends the EXISTING cutover-owner-entry Action with one diagnostic
step and path trigger. It retains existing keyless GCP startup, permissions,
source check, lock, archive and failure behavior. This was YAML/shell checked
locally but has NOT been uploaded or executed on GCP. A future GCP invocation
of this component test is still not a distributed acceptance run.

Current session exposes GitHub reads only; write/dispatch actions were not
available and the CLI network route could not resolve github.com. Therefore
this packet is unpublished, the remote head remains 0219a7fe, and no source
changes, release approval, C0 closure or A1-v13 certification is claimed.
