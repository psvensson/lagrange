# Scenario Triage Summary

- Scenario: rolling-restart
- Phase: unknown
- Root Cause Class: startup
- Dominant Reason: admin_reachability_refused
- Failure Class: startup_recovery_blocked
- Readiness Failure: unknown
- Failure Class Signals: failureBarrier=restart_recovery|failureBarrierReason=admin_reachability_refused|startupMode=durable_rejoin
- Failure Action: unknown
- Operator Recommendation: unknown
- Bottleneck: unknown

## Stability Gates

- failover: status=closed, pendingAckCount=0, blockedNodeCount=0
- convergence: status=closed, pendingAckCount=0, blockedNodeCount=0
- restart_recovery: status=open, blockers=admin_reachability_refused, restartBoundaryCount=1, pendingAckCount=0, blockedNodeCount=0

## Publication Convergence

- Publication Epoch: 4
- Publication Status: PUBLISHED
- Recovery Protocol State: steady_published
- Pending Ack Count: 0
- Pending Ack Nodes: none
- Publication Gate Reasons: none
- Blocked Partition Count: 0
- Blocked Partitions: none
- Unresolved Partition Count: 0
- Unresolved Partitions: none
- Closure Record Id: unknown
- Closure Witness Class: unknown
- Projection Diagnostics: mode=cluster_member_healthy_only, dimensions=clusterMemberHealthy, recoveryEligibleProjectionEnabled=false, recoveryEligibleIncluded=none, readinessExcluded=none, clusterMemberUnhealthyExcluded=none
- Failing Invariants: none
- Progress Summary: partitionCount=2, partition=replica_operations-p1, owner=operation_workflow_owner, actuation=persisted_not_dispatched, boundary=workflow_progress, waitMode=event_driven, nextAction=wait_for_operation_progress, contractState=pending, pressure=none, lastProgressAtMs=1785491961091

## Artifact Paths

- Report: test-output/reports/stat-gate-20260731T095858Z-run1.report.json
- Failure Bundle JSON: test-output/reports/.playback/stat-gate-20260731T095858Z-run1/rolling-restart/failure-bundle.json
- Failure Bundle Markdown: test-output/reports/.playback/stat-gate-20260731T095858Z-run1/rolling-restart/failure-bundle.md
- Playback Events: test-output/reports/.playback/stat-gate-20260731T095858Z-run1/rolling-restart/events.ndjson
- Timeline: test-output/reports/.playback/stat-gate-20260731T095858Z-run1/rolling-restart/_timeline.log
- Analysis: unknown

## Top Reasons

- nodeSlotUnavailable: 104492
- nodeAdmissionBlocked: 9652
- timeoutWaits: 99
- hardLoadFailures: 73
- retryableControlPlanePressure: 13

## Playback

- Load Started: 2026-07-31T10:01:02.063Z
- Load Completed: 2026-07-31T10:04:01.252Z
- Load Progress Events: 180
- Partition Created Events: 7
- Replica Created Events: 55
- Replica Removed Events: 23

## Routing Diagnostics

- none
