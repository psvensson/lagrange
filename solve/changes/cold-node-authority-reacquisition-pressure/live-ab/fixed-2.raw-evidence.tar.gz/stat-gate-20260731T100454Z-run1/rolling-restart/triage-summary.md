# Scenario Triage Summary

- Scenario: rolling-restart
- Phase: unknown
- Root Cause Class: load
- Dominant Reason: nodeAdmissionBlocked
- Failure Class: load_pressure
- Readiness Failure: unknown
- Failure Class Signals: dominantReason=nodeAdmissionBlocked|priorityRecoveryPartition=sql_transactions-p1|priorityRecoverySemanticState=spread_satisfied_in_flight|priorityRecoveryOwner=operation_workflow_owner|priorityRecoveryBoundary=workflow_progress|priorityRecoveryWaitMode=event_driven|priorityRecoveryNextAction=wait_for_operation_progress|priorityRecoveryLatestStep=PENDING|priorityRecoveryLatestStatus=pending
- Failure Action: Load traffic is admission-blocked while control-plane recovery or readiness pressure remains active.
- Operator Recommendation: Inspect load-lane admission errors, control-plane write pressure, and priority recovery operation visibility before rerun.
- Bottleneck: unknown

## Stability Gates

- failover: status=closed, pendingAckCount=0, blockedNodeCount=0
- convergence: status=closed, pendingAckCount=0, blockedNodeCount=0
- restart_recovery: status=closed, restartBoundaryCount=6, pendingAckCount=0, blockedNodeCount=0

## Publication Convergence

- Publication Epoch: 4
- Publication Status: PUBLISHED
- Recovery Protocol State: steady_published
- Pending Ack Count: 0
- Pending Ack Nodes: none
- Publication Gate Reasons: none
- Blocked Partition Count: 0
- Blocked Partitions: none
- Unresolved Partition Count: 0
- Unresolved Partitions: none
- Closure Record Id: unknown
- Closure Witness Class: unknown
- Projection Diagnostics: mode=cluster_member_healthy_only, dimensions=clusterMemberHealthy, recoveryEligibleProjectionEnabled=false, recoveryEligibleIncluded=none, readinessExcluded=none, clusterMemberUnhealthyExcluded=none
- Failing Invariants: none
- Progress Summary: partitionCount=2, partition=sql_transactions-p1, owner=operation_workflow_owner, actuation=persisted_not_dispatched, boundary=workflow_progress, waitMode=event_driven, nextAction=wait_for_operation_progress, contractState=pending, pressure=write_backlog, lastProgressAtMs=1785492341925

## Artifact Paths

- Report: test-output/reports/stat-gate-20260731T100454Z-run1.report.json
- Failure Bundle JSON: test-output/reports/.playback/stat-gate-20260731T100454Z-run1/rolling-restart/failure-bundle.json
- Failure Bundle Markdown: test-output/reports/.playback/stat-gate-20260731T100454Z-run1/rolling-restart/failure-bundle.md
- Playback Events: test-output/reports/.playback/stat-gate-20260731T100454Z-run1/rolling-restart/events.ndjson
- Timeline: test-output/reports/.playback/stat-gate-20260731T100454Z-run1/rolling-restart/_timeline.log
- Analysis: unknown

## Top Reasons

- nodeSlotUnavailable: 107293
- nodeAdmissionBlocked: 17702
- retryableControlPlanePressure: 669
- timeoutWaits: 270
- hardLoadFailures: 153

## Playback

- Load Started: 2026-07-31T10:07:01.372Z
- Load Completed: 2026-07-31T10:11:26.145Z
- Load Progress Events: 265
- Partition Created Events: 7
- Replica Created Events: 40
- Replica Removed Events: 18

## Routing Diagnostics

- none
