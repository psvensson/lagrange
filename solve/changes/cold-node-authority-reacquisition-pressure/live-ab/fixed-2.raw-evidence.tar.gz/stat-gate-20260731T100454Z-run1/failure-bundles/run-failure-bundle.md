# Run Failure Bundle

- Report: test-output/reports/stat-gate-20260731T100454Z-run1.report.json

- Failed Scenarios: 1

## Scenarios
- rolling-restart: unknown [load_pressure] (test-output/reports/.playback/stat-gate-20260731T100454Z-run1/rolling-restart/failure-bundle.md)
