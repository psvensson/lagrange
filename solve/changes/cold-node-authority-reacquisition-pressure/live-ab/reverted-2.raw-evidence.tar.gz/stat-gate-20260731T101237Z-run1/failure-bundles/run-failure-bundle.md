# Run Failure Bundle

- Report: test-output/reports/stat-gate-20260731T101237Z-run1.report.json

- Failed Scenarios: 1

## Scenarios
- rolling-restart: unknown [startup_recovery_blocked] (test-output/reports/.playback/stat-gate-20260731T101237Z-run1/rolling-restart/failure-bundle.md)
