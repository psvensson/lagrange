# Scenario Triage Summary

- Scenario: rolling-restart
- Phase: unknown
- Root Cause Class: load
- Dominant Reason: nodeAdmissionBlocked
- Failure Class: load_pressure
- Readiness Failure: unknown
- Failure Class Signals: dominantReason=nodeAdmissionBlocked
- Failure Action: Load traffic is admission-blocked while control-plane recovery or readiness pressure remains active.
- Operator Recommendation: Inspect load-lane admission errors, control-plane write pressure, and priority recovery operation visibility before rerun.
- Bottleneck: unknown

## Stability Gates

- failover: status=closed, pendingAckCount=0, blockedNodeCount=0
- convergence: status=closed, pendingAckCount=0, blockedNodeCount=0
- restart_recovery: status=closed, restartBoundaryCount=5, pendingAckCount=0, blockedNodeCount=0

## Publication Convergence

- Publication Epoch: 6
- Publication Status: PUBLISHED
- Recovery Protocol State: steady_published
- Pending Ack Count: 0
- Pending Ack Nodes: none
- Publication Gate Reasons: none
- Blocked Partition Count: 0
- Blocked Partitions: none
- Unresolved Partition Count: 0
- Unresolved Partitions: none
- Closure Record Id: unknown
- Closure Witness Class: unknown
- Projection Diagnostics: mode=cluster_member_healthy_only, dimensions=clusterMemberHealthy, recoveryEligibleProjectionEnabled=false, recoveryEligibleIncluded=none, readinessExcluded=none, clusterMemberUnhealthyExcluded=none
- Failing Invariants: none
- Progress Summary: unknown

## Artifact Paths

- Report: test-output/reports/stat-gate-20260731T094947Z-run1.report.json
- Failure Bundle JSON: test-output/reports/.playback/stat-gate-20260731T094947Z-run1/rolling-restart/failure-bundle.json
- Failure Bundle Markdown: test-output/reports/.playback/stat-gate-20260731T094947Z-run1/rolling-restart/failure-bundle.md
- Playback Events: test-output/reports/.playback/stat-gate-20260731T094947Z-run1/rolling-restart/events.ndjson
- Timeline: test-output/reports/.playback/stat-gate-20260731T094947Z-run1/rolling-restart/_timeline.log
- Analysis: unknown

## Top Reasons

- nodeSlotUnavailable: 156174
- nodeAdmissionBlocked: 18489
- retryableControlPlanePressure: 859
- timeoutWaits: 76
- hardLoadFailures: 74

## Playback

- Load Started: 2026-07-31T09:51:17.193Z
- Load Completed: 2026-07-31T09:56:17.131Z
- Load Progress Events: 300
- Partition Created Events: 9
- Replica Created Events: 71
- Replica Removed Events: 23

## Routing Diagnostics

- none
